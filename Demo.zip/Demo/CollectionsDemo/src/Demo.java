import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Demo1> list=new ArrayList<Demo1>();
		
		System.out.println(CollectionUtils.isNotEmpty(list));
		Demo1 d=new Demo1();
		Demo2 d2=new Demo2();
		System.out.println("============"+d2.getListd2());
		System.out.println(CollectionUtils.isNotEmpty(d2.getListd2()));
		System.out.println("===========");
		list.add(d);
		System.out.println(CollectionUtils.isNotEmpty(list));
		d2.setListd2(list);
		System.out.println(CollectionUtils.isNotEmpty(d2.getListd2()));
		System.out.println(d);
		//d=null;
		System.out.println(d);
		System.out.println(CollectionUtils.isNotEmpty(list));
		list.add(d);
		System.out.println(list);
		System.out.println(CollectionUtils.isNotEmpty(list));
		System.out.println("==================");
		Demo1 d1=null;
		list.clear();
		list.add(d1);
		d2.setListd2(list);
		System.out.println(d2.getListd2());
		System.out.println(CollectionUtils.isNotEmpty(d2.getListd2()));
		d2=null;
		System.out.println(d2);
		System.out.println(CollectionUtils.isNotEmpty(d2.getListd2()));
	}

}
