import java.util.ArrayList;
import java.util.List;

public class Demo2 {

	private String name;
	private int age;
	private List<Demo1> listd2=new ArrayList<Demo1>();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<Demo1> getListd2() {
		return listd2;
	}
	public void setListd2(List<Demo1> listd2) {
		this.listd2 = listd2;
	}
	public Demo2() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Demo2(String name, int age, List<Demo1> listd2) {
		super();
		this.name = name;
		this.age = age;
		this.listd2 = listd2;
	}
	
	
}
