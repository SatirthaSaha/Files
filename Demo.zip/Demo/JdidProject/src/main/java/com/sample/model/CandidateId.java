package com.sample.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CandidateId {

	private int id;
	private List<LevelofInterview> levelOfInterview;
	
	@XmlAttribute
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@XmlElement
	public List<LevelofInterview> getLevelOfInterview() {
		return levelOfInterview;
	}
	public void setLevelOfInterview(List<LevelofInterview> levelOfInterview) {
		this.levelOfInterview = levelOfInterview;
	}
	@Override
	public String toString() {
		return "CandidateId [id=" + id + ", levelOfInterview=" + levelOfInterview + "]";
	}
	
	
	
}
