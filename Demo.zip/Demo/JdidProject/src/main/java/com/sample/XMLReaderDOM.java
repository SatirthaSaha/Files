package com.sample;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sample.model.CandidateId;
import com.sample.model.Jdid;
import com.sample.model.LevelofInterview;


public class XMLReaderDOM {

    public static List<Jdid> employeeList() {
        String filePath = "D:\\Satirtha_Workspace\\Demo\\JdidProject\\XmlFile.xml";
        File xmlFile = new File(filePath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        List<Jdid> jdidList = new ArrayList<Jdid>();
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("jdid");
            //now XML is loaded as Document in memory, lets convert it to Object List
            
            for (int i = 0; i < nodeList.getLength(); i++) {
                jdidList.add(getJdid(nodeList.item(i), doc));
            }
            //lets print Employee list information
            for (Jdid jdid : jdidList) {
                System.out.println(jdid.toString());
            }
        } catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }
		return jdidList;

    }


    private static Jdid getJdid(Node node,Document doc) {
        //XMLReaderDOM domReader = new XMLReaderDOM();
    	Jdid jdid = new Jdid();
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            jdid.setId(Integer.parseInt(element.getAttribute("id")));
            NodeList nodeList1 = doc.getElementsByTagName("candidateID");
            List<CandidateId> candidateList=new ArrayList<>();
            for (int i = 0; i < nodeList1.getLength(); i++) {
            	candidateList.add(getCandidates(nodeList1.item(i), doc));
            }
            jdid.setCandidate(candidateList);
        }

        return jdid;
    }


    private static CandidateId getCandidates(Node node, Document doc) {
		// TODO Auto-generated method stub
    	CandidateId candidateId=new CandidateId();
    	if (node.getNodeType() == Node.ELEMENT_NODE) {
    		Element element = (Element) node;
    		candidateId.setId(Integer.parseInt(element.getAttribute("id")));
    		NodeList nodeList2 = doc.getElementsByTagName("levelOfInterview");
    		List<LevelofInterview> levelOfInterviewList=new ArrayList<>();
    		for (int i = 0; i < nodeList2.getLength(); i++) {
    			levelOfInterviewList.add(getLevels(nodeList2.item(i), doc));
            }
    		candidateId.setLevelOfInterview(levelOfInterviewList);
    	}
		return candidateId;
	}


	private static LevelofInterview getLevels(Node node, Document doc) {
		// TODO Auto-generated method stub
		LevelofInterview levelofInterview = new LevelofInterview();
		if (node.getNodeType() == Node.ELEMENT_NODE) {
    		Element element = (Element) node;
    		levelofInterview.setLevel(Integer.parseInt(element.getAttribute("level")));
    		levelofInterview.setScheduledTime(getTagValue("scheduledTime", element));
    		levelofInterview.setStatus(Integer.parseInt(getTagValue("status", element)));
		}
		return levelofInterview;
	}


	private static String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = (Node) nodeList.item(0);
        return node.getNodeValue();
    }

}