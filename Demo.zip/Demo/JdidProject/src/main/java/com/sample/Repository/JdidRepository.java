package com.sample.Repository;

import java.util.List;

import com.sample.model.Jdid;

public interface JdidRepository {

	public List<Jdid> findAllJdids();
}