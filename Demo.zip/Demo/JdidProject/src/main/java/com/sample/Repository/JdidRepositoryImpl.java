package com.sample.Repository;

import java.util.List;

import com.sample.XMLReaderDOM;
import com.sample.model.Jdid;

public class JdidRepositoryImpl implements JdidRepository {

	@Override
	public List<Jdid> findAllJdids() {
		// TODO Auto-generated method stub
		List<Jdid> JDIDs=XMLReaderDOM.employeeList();
		return JDIDs;
	}

}
