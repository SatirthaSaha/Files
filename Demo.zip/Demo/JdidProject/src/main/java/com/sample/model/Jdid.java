package com.sample.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Jdid {

	private int id;
	private List<CandidateId> candidate;
	
	@XmlAttribute
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@XmlElement
	public List<CandidateId> getCandidate() {
		return candidate;
	}
	public void setCandidate(List<CandidateId> candidate) {
		this.candidate = candidate;
	}
	@Override
	public String toString() {
		return "Jdid [id=" + id + ", candidate=" + candidate + "]";
	}
	
	
}
