package com.sample;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sample.Repository.JdidRepository;
import com.sample.Repository.JdidRepositoryImpl;
import com.sample.model.Jdid;

@Path("jdids")
public class JdidResource {

	private JdidRepository jdidRepository=new JdidRepositoryImpl();
	
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Jdid> getAllEmployees(){
		return jdidRepository.findAllJdids();
	}
}
