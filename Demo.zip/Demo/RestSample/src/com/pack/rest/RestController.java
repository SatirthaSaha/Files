package com.pack.rest;


import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/rest")
public class RestController {

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String displayHtml()
	{
		return "<html>"+"<body>"+"<p>"+"Hi! Welcome to HTML rest page"+"</p>"+"</body>"+"</html>";
		
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String displayPlainText()
	{
		return "Hi! Welcome to plain text rest page !";
	}
	
	@PUT
	@Path("{studentRollNo}")
	@Produces(MediaType.TEXT_PLAIN)
	public String update(@PathParam("studentRollNo")String roll)
	{
		return "Done Successfully!";
	}
	
	
}
