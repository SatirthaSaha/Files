import java.util.ArrayList;
import java.util.List;

public class main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list=new ArrayList<String>();
		System.out.println(list.isEmpty());

	}

}
