package com.sample.repository;

import java.util.List;

import com.sample.model.Employee;

public interface EmployeeRepository {

	List<Employee> findAllEmployee();

	Employee findEmployee(int empId);

	void regEmployee(Employee employee);

	List<Employee> updateEmployee(int empId, Employee employee, List<Employee> employees);

	List<Employee> deleteEmployee(int empId,List<Employee> employees);

}