package com.sample.repository;

import java.util.List;

import com.sample.XMLReaderDOM;
import com.sample.model.Employee;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	@Override
	public List<Employee> findAllEmployee(){

		/*List<Employee> employees=new ArrayList<Employee>();

		Employee employee1=new Employee();

		employee1.setEmpId(1000);
		employee1.setEmpName("Satirtha");
		Department department1=new Department();
		department1.setDeptId(1);
		department1.setDeptName("Developer");
		employee1.setDepartment(department1);
		Address address1=new Address();
		address1.setHouseNo(84);
		address1.setLocation("Baruipur");
		address1.setPinNo(700144);
		employee1.setAddress(address1);

		employees.add(employee1);

		Employee employee2=new Employee();

		employee2.setEmpId(1001);
		employee2.setEmpName("Shounak");
		Department department2=new Department();
		department2.setDeptId(1);
		department2.setDeptName("Analyst");
		employee2.setDepartment(department2);
		Address address2=new Address();
		address2.setHouseNo(841);
		address2.setLocation("Laketown");
		address2.setPinNo(700029);
		employee2.setAddress(address2);

		employees.add(employee2);*/

		//XMLReaderDOM xmlReader=new XMLReaderDOM();
		
		
		List<Employee> employees=XMLReaderDOM.employeeList();
		return employees;
	}

	@Override
	public Employee findEmployee(int empId) {
		// TODO Auto-generated method stub
		
		List<Employee> employees=findAllEmployee();
		
		for(Employee e:employees)
		{
			if(e.getEmpId()==empId)
				return e;
		}
		/*Employee employee1=new Employee();

		employee1.setEmpId(1000);
		employee1.setEmpName("Satirtha");
		Department department1=new Department();
		department1.setDeptId(1);
		department1.setDeptName("Developer");
		employee1.setDepartment(department1);
		Address address1=new Address();
		address1.setHouseNo(84);
		address1.setLocation("Baruipur");
		address1.setPinNo(700144);
		employee1.setAddress(address1);*/
		
		return null;
	}

	@Override
	public void regEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Employee> updateEmployee(int empId, Employee employee, List<Employee> employees) {
		// TODO Auto-generated method stub
		for(Employee emp:employees)
		{
			if(emp.getEmpId()==empId)
			{
				emp.setEmpName(employee.getEmpName());
			}
		}
		
		return employees;
	}

	@Override
	public List<Employee> deleteEmployee(int empId, List<Employee> employees) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		for(Employee emp:employees)
		{
			if(emp.getEmpId()==empId)
			{
				e=emp;
			}
		}
		employees.remove(e);
		return employees;
	}
}
