package com.sample;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sample.model.Employee;
import com.sample.repository.EmployeeRepository;
import com.sample.repository.EmployeeRepositoryImpl;

@Path("employees")
public class EmployeeResource {

	private EmployeeRepository employeeRepository=new EmployeeRepositoryImpl();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAllEmployee();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("{empId}")
	public Employee getEmployee(@PathParam("empId") int empId){
		return employeeRepository.findEmployee(empId);
	}
	
	@POST
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Consumes(MediaType.APPLICATION_XML)
	@Path("employee")
	public Employee registerEmployee(Employee employee) {
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		
		employeeRepository.regEmployee(employee);
		
		return employee;
		
	}
	
	@PUT
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Consumes(MediaType.APPLICATION_XML)
	@Path("{empId}")
	public List<Employee> updateEmployee(@PathParam("empId") int empId,Employee employee) {
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		
		List<Employee> employees=employeeRepository.findAllEmployee();
		System.out.println(employees);
		employees=employeeRepository.updateEmployee(empId,employee,employees);
		System.out.println();
		System.out.println(employees);
		return employees;
		
	}
	
	@DELETE
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Consumes(MediaType.APPLICATION_XML)
	@Path("{empId}")
	public List<Employee> deleteEmployee(@PathParam("empId") int empId) {
		
		List<Employee> employees=employeeRepository.findAllEmployee();
		System.out.println(employees);
		employees=employeeRepository.deleteEmployee(empId,employees);
		System.out.println("========================");
		System.out.println(employees);
		return employees;
		
	}
	
}
