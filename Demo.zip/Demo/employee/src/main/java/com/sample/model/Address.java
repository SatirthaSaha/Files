package com.sample.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Address {

	private int houseNo;
	private String location;
	private int pinNo;
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPinNo() {
		return pinNo;
	}
	public void setPinNo(int pinNo) {
		this.pinNo = pinNo;
	}
	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", location=" + location + ", pinNo=" + pinNo + "]";
	}
	
	
}
