package com.travelport.refdata.carriers.qf;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.xml.sax.SAXException;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

@Ignore
public class LoadQantasReferenceDataFilesTest {

	
	 	private static final String QANTAS_CABIN_CLASS_DATA_KEY = "QANTAS_CABIN_CLASS_DATA_KEY";
	    private static final String QANTAS_CABIN_CLASS_DATA_FILE = "carriers/qf/Qantas_CabinClassMapping.xml";
	    private static final String QANTAS_CABIN_CLASS_DATA_VERSION_KEY = "QANTAS_CABIN_CLASS_DATA_VERSION_KEY";
	    private static final Integer QANTAS_CABIN_CLASS_DATA_VERSION = 2;


	    @Test
	    public void testLoadCabinClassMapping () throws ParserConfigurationException, SAXException, IOException {

	        final InputStream fileToRead = LoadQantasReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (QANTAS_CABIN_CLASS_DATA_FILE);

	        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

	        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

	        assertTrue ("Qantas Cabin Class Data Saved in Redis Cache.", connectorStream.save (QANTAS_CABIN_CLASS_DATA_KEY, allBytes));

	        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

	        assertTrue ("Qanats Cabin Class Data Supported Version is Saved in Redis Cache.", connectorInteger.save (QANTAS_CABIN_CLASS_DATA_VERSION_KEY, QANTAS_CABIN_CLASS_DATA_VERSION));

	        final byte[] fileBytes = connectorStream.getValue (QANTAS_CABIN_CLASS_DATA_KEY);

	        OutputStream fileToWrite = new FileOutputStream ("Qantas_CabinClassMapping_Read.xlsx");

	        fileToWrite.write (fileBytes);
	        fileToWrite.flush ();
	        fileToWrite.close ();

	        assertEquals (QANTAS_CABIN_CLASS_DATA_VERSION, connectorInteger.getValue (QANTAS_CABIN_CLASS_DATA_VERSION_KEY));
	    }
}
