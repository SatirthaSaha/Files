package com.travelport.refdata.carriers.dl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.xml.sax.SAXException;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;


/**
 * 
 * @author dhrubajyoti.dawn
 *
 *  Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
 *
 */
@Ignore
public class LoadDeltaReferenceDataFilesTest {

    private static final String DELTA_CABIN_CLASS_DATA_KEY = "DELTA_CABIN_CLASS_DATA_KEY";
    private static final String DELTA_CABIN_CLASS_DATA_FILE = "carriers/dl/Delta_CabinClassMapping.xml";
    private static final String DELTA_CABIN_CLASS_DATA_VERSION_KEY = "DELTA_CABIN_CLASS_DATA_VERSION_KEY";
    private static final Integer DELTA_CABIN_CLASS_DATA_VERSION = 1;
	private static final String DELTA_OPTIONAL_SERVICES_DATA_FILE = "carriers/dl/DeltaOptionalServiceAndFees.xlsx";
	private static final String DELTA_OPTIONAL_SERVICES_DATA_KEY = "DELTA_OPTIONAL_SERVICES_DATA_KEY";
	private static final Integer DELTA_OPTIONAL_SERVICES_DATA_VERSION = 1;
	private static final String DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY = "DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY";

    @Test
    public void testLoadCabinClassMapping () throws ParserConfigurationException, SAXException, IOException {

        final InputStream fileToRead = LoadDeltaReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (DELTA_CABIN_CLASS_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Delta Cabin Class Data Saved in Redis Cache.", connectorStream.save (DELTA_CABIN_CLASS_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Delta Cabin Class Data Supported Version is Saved in Redis Cache.", connectorInteger.save (DELTA_CABIN_CLASS_DATA_VERSION_KEY, DELTA_CABIN_CLASS_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (DELTA_CABIN_CLASS_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("Delta_CabinClassMapping_Read.xml");

        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();

        assertEquals (DELTA_CABIN_CLASS_DATA_VERSION, connectorInteger.getValue (DELTA_CABIN_CLASS_DATA_VERSION_KEY));
    }
    
    
    
    @Test
	public void connectorLiveTest_Delta_OptionalServices() throws ParserConfigurationException, SAXException, IOException {

		InputStream fileToRead = (InputStream) LoadDeltaReferenceDataFilesTest.class.getClassLoader()
				.getResourceAsStream(DELTA_OPTIONAL_SERVICES_DATA_FILE);

		
		final byte[] allBytes = IOUtils.toByteArray (fileToRead);
		
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
		
		assertTrue ("Delta Optional Services Data Saved in Redis Cache.", connectorStream.save (DELTA_OPTIONAL_SERVICES_DATA_KEY, allBytes));
		
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Delta Optional Services Version Saved in Redis Cache.",
                connectorInteger.save (DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY, DELTA_OPTIONAL_SERVICES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (DELTA_OPTIONAL_SERVICES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("DeltaOptionalServiceAndFees_Read.xlsx");
		
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (DELTA_OPTIONAL_SERVICES_DATA_VERSION, connectorInteger.getValue (DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY));
		
	}
    
}
