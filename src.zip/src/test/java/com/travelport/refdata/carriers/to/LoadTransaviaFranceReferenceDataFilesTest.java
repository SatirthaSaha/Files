/*
 * Copyright (c) 2017, Travelport.
 * All Rights Reserved.
 * Use is subject to license agreement.
 */
package com.travelport.refdata.carriers.to;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

//Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
@Ignore
public class LoadTransaviaFranceReferenceDataFilesTest {

    private static final String TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY = "TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_TRANSLATION_DATA_FILE = "carriers/to/TO_TranslationData.xml";
    private static final String TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY";
    private static final Integer TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION = 1;

    private static final String TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE = "carriers/to/TransaviaAirOptionalServiceAndFees.xlsx";
    private static final String TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";
    private static final Integer TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION = 1;
    
    private static final String TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY = "TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_FILE = "carriers/to/Transavia_ProductClassMapping.xml";
    private static final String TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY";
    private static final Integer TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION = 1;
    
    @Test
    public void testLoadTranslationReferenceData () throws IOException {
        final InputStream fileToRead = LoadTransaviaFranceReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (TRANSAVIA_FRANCE_TRANSLATION_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Transavia France Translation Data Not Saved in Redis Cache.",
                connectorStream.save (TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Card Carrier Currency Unsupported Version Not Saved in Redis Cache.",
                connectorInteger.save (TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY, TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("TO_TranslationData_Read.xml");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION, connectorInteger.getValue (TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY));
    }

    @Test
    public void testLoadAirOptionalServieAndFeesReferenceData () throws IOException {
        final InputStream fileToRead = LoadTransaviaFranceReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Transavia France Translation Data Not Saved in Redis Cache.",
                connectorStream.save (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Card Carrier Currency Unsupported Version Not Saved in Redis Cache.",
                connectorInteger.save (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY, TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("TransaviaAirOptionalServiceAndFees_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION, connectorInteger.getValue (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY));
    }
    
    @Test
    public void testLoadProductClassMappingData () throws IOException {
        final InputStream fileToRead = LoadTransaviaFranceReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Transavia France Product Class Mapping Not Saved in Redis Cache.", connectorStream.save (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Transavia France Product Class Unsupported Version Not Saved in Redis Cache.", connectorInteger.save (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY, TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("Transavia_ProductClassMapping_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION, connectorInteger.getValue (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY));
    }
}
