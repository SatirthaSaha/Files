/*
 * Copyright (c) 2017, Travelport.
 * All Rights Reserved.
 * Use is subject to license agreement.
 */
package com.travelport.refdata.carriers.ua;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.xml.sax.SAXException;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

//Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
@Ignore
public class LoadUnitedReferenceDataFilesTest {

    private static final String UNITED_AIR_SSR_DATA_KEY = "UNITED_AIR_SSR_DATA_KEY";
    private static final String UNITED_AIR_SSR_DATA_FILE = "carriers/united/UnitedAir_SSR.xlsx";
    private static final String UNITED_AIR_SSR_DATA_VERSION_KEY = "UNITED_AIR_SSR_DATA_VERSION_KEY";
    private static final Integer UNITED_AIR_SSR_DATA_VERSION = 1;
    
    @Test
	public void connectorLiveTest_UnitedAir_SSR() throws ParserConfigurationException, SAXException, IOException {

		InputStream fileToRead = (InputStream) LoadUnitedReferenceDataFilesTest.class.getClassLoader()
				.getResourceAsStream(UNITED_AIR_SSR_DATA_FILE);

		
		final byte[] allBytes = IOUtils.toByteArray (fileToRead);
		
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
		
		assertTrue ("Transavia France Translation Data Not Saved in Redis Cache.", connectorStream.save (UNITED_AIR_SSR_DATA_KEY, allBytes));
		
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Card Carrier Currency Unsupported Version Not Saved in Redis Cache.",
                connectorInteger.save (UNITED_AIR_SSR_DATA_VERSION_KEY, UNITED_AIR_SSR_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (UNITED_AIR_SSR_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("UnitedAir_SSR_Read.xlsx");
		
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (UNITED_AIR_SSR_DATA_VERSION, connectorInteger.getValue (UNITED_AIR_SSR_DATA_VERSION_KEY));
		
	}
	
}
