package com.travelport.refdata.carriers.jambojet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

@Ignore
public class LoadJambojetReferenceDataFilesTest {
	
	private static final String JAMBOJET_TRANSLATION_DATA_KEY = "JAMBOJET_TRANSLATION_DATA_KEY";
    private static final String JAMBOJET_TRANSLATION_DATA_FILE = "carriers/jambojet/JM_TranslationData.xml";
    private static final String JAMBOJET_TRANSLATION_DATA_VERSION_KEY = "JAMBOJET_TRANSLATION_DATA_VERSION_KEY";
    private static final Integer JAMBOJET_TRANSLATION_DATA_VERSION = 1;
    
    private static final String JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE = "carriers/jambojet/JamboJetAirOptionalServiceAndFees.xlsx";
    private static final String JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";
    private static final Integer JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION = 1;
    
    private static final String JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY = "JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY";
    private static final String JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_FILE = "carriers/jambojet/JambojetSeatAvailabilityRulesMapping.xlsx";
    private static final String JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY = "JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY";
    private static final Integer JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION = 1;
    
    private static final String JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY = "JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY";
    private static final String JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_FILE = "carriers/jambojet/JambojetSeatCharacteristicsMapping.xlsx";
    private static final String JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY = "JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY";
    private static final Integer JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION = 1;

    @Test
    public void testLoadTranslationReferenceData () throws IOException {
        final InputStream fileToRead = LoadJambojetReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (JAMBOJET_TRANSLATION_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jambojet_TranslationData Key and saved_version saved in Redis Cache.",
                connectorStream.save (JAMBOJET_TRANSLATION_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jambojet_TranslationData Key and saved_version saved in Redis Cache.",
                connectorInteger.save (JAMBOJET_TRANSLATION_DATA_VERSION_KEY, JAMBOJET_TRANSLATION_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JAMBOJET_TRANSLATION_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("JM_TranslationData.xml");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JAMBOJET_TRANSLATION_DATA_VERSION, connectorInteger.getValue (JAMBOJET_TRANSLATION_DATA_VERSION_KEY));
    }

    
    @Test
    public void testLoadAirOptionalServieAndFeesReferenceData () throws IOException {
        final InputStream fileToRead = LoadJambojetReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jambojet_SSR saved in Redis Cache.",
                connectorStream.save (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jambojet_SSR Key and saved_version saved in Redis Cache.",
                connectorInteger.save (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY, JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("JamboJetAirOptionalServiceAndFees.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION, connectorInteger.getValue (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY));
    }
    
    
    @Test
    public void testLoadSeatAvailabilityRulesMappingReferenceData () throws IOException {
        final InputStream fileToRead = LoadJambojetReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jambojet Seat Availability Rules saved in Redis Cache.", connectorStream.save (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jambojet Seat Availability Rules version is saved in Redis Cache.", connectorInteger.save (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY, JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("JambojetSeatAvailabilityRulesMapping.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION, connectorInteger.getValue (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY));
    }
    
    
    @Test
    public void testLoadSeatCharacteristicsMappingReferenceData () throws IOException {
        final InputStream fileToRead = LoadJambojetReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jambojet Seat Characteristics saved in Redis Cache.", connectorStream.save (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jambojet Seat Characteristics version is saved in Redis Cache.", connectorInteger.save (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY, JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("JambojetSeatCharacteristicsMapping.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION, connectorInteger.getValue (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY));
    }

}
