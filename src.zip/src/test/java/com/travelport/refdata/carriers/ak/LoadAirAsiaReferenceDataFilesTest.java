package com.travelport.refdata.carriers.ak;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.xml.sax.SAXException;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

/**
 * 
 * @author debanjan.banerjee
 *
 *  Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
 *
 */
@Ignore
public class LoadAirAsiaReferenceDataFilesTest {

    private static final String AIR_ASIA_CABIN_CLASS_DATA_KEY = "AIR_ASIA_CABIN_CLASS_DATA_KEY";
    private static final String AIR_ASIA_CABIN_CLASS_DATA_FILE = "carriers/ak/AirAsia_CabinClassMapping.xml";
    private static final String AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY = "AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY";
    private static final Integer AIR_ASIA_CABIN_CLASS_DATA_VERSION = 2;

    private static final String AIR_ASIA_SSR_DATA_KEY = "AIR_ASIA_SSR_DATA_KEY";
    private static final String AIR_ASIA_SSR_DATA_FILE = "carriers/ak/AirAsia_SSR.xlsx";
    private static final String AIR_ASIA_SSR_DATA_VERSION_KEY = "AIR_ASIA_SSR_DATA_VERSION_KEY";
    private static final Integer AIR_ASIA_SSR_DATA_VERSION = 11;

    private static final String AIR_ASIA_PRODUCT_CLASS_DATA_KEY = "AIR_ASIA_PRODUCT_CLASS_DATA_KEY";
    private static final String AIR_ASIA_PRODUCT_CLASS_DATA_FILE = "carriers/ak/AirAsia_ProductClassMapping.xml";
    private static final String AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY = "AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY";
    private static final Integer AIR_ASIA_PRODUCT_CLASS_DATA_VERSION = 3;
    
    private static final String AIR_ASIA_APIS_DATA_KEY = "AIR_ASIA_APIS_DATA_KEY";
    private static final String AIR_ASIA_APIS_DATA_FILE = "carriers/ak/AirAsia_APIS.xml";
    private static final String AIR_ASIA_APIS_DATA_VERSION_KEY = "AIR_ASIA_APIS_DATA_VERSION_KEY";
    private static final Integer AIR_ASIA_APIS_DATA_VERSION = 1;

    @Test
    public void testLoadCabinClassMapping () throws ParserConfigurationException, SAXException, IOException {

        final InputStream fileToRead = LoadAirAsiaReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (AIR_ASIA_CABIN_CLASS_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Air Asia Cabin Class Data Saved in Redis Cache.", connectorStream.save (AIR_ASIA_CABIN_CLASS_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Air Asia Cabin Class Data Supported Version is Saved in Redis Cache.", connectorInteger.save (AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY, AIR_ASIA_CABIN_CLASS_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (AIR_ASIA_CABIN_CLASS_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("AirAsia_CabinClassMapping_Read.xlsx");

        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();

        assertEquals (AIR_ASIA_CABIN_CLASS_DATA_VERSION, connectorInteger.getValue (AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY));
    }

    @Test
    public void testLoadSSR () throws ParserConfigurationException, SAXException, IOException {

        final InputStream fileToRead = LoadAirAsiaReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (AIR_ASIA_SSR_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Air Asia SSR Data is Saved in Redis Cache.", connectorStream.save (AIR_ASIA_SSR_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Air Asia SSR Data Supported Version is Saved in Redis Cache.", connectorInteger.save (AIR_ASIA_SSR_DATA_VERSION_KEY, AIR_ASIA_SSR_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (AIR_ASIA_SSR_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("AirAsia_SSR_Read.xlsx");

        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();

        assertEquals (AIR_ASIA_SSR_DATA_VERSION, connectorInteger.getValue (AIR_ASIA_SSR_DATA_VERSION_KEY));
    }

    @Test
    public void testLoadProductClassMapping () throws ParserConfigurationException, SAXException, IOException {

        final InputStream fileToRead = LoadAirAsiaReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (AIR_ASIA_PRODUCT_CLASS_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Air Asia Product Class Data is Saved in Redis Cache.", connectorStream.save (AIR_ASIA_PRODUCT_CLASS_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Air Asia Product Class Supported Version is Saved in Redis Cache.", connectorInteger.save (AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY, AIR_ASIA_PRODUCT_CLASS_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (AIR_ASIA_PRODUCT_CLASS_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("AirAsia_ProductClassMapping_Read.xlsx");

        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();

        assertEquals (AIR_ASIA_PRODUCT_CLASS_DATA_VERSION, connectorInteger.getValue (AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY));
    }
    
    @Test
    public void testLoadAPISData () throws ParserConfigurationException, SAXException, IOException {

        final InputStream fileToRead = LoadAirAsiaReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (AIR_ASIA_APIS_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Air Asia APIS Data is Saved in Redis Cache.", connectorStream.save (AIR_ASIA_APIS_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Air Asia APIS Data Supported Version is Saved in Redis Cache.", connectorInteger.save (AIR_ASIA_APIS_DATA_VERSION_KEY, AIR_ASIA_APIS_DATA_VERSION));

        final byte[] fileBytes = connectorStream.getValue (AIR_ASIA_APIS_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("AirAsia_APIS_Read.xml");

        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();

        assertEquals (AIR_ASIA_APIS_DATA_VERSION, connectorInteger.getValue (AIR_ASIA_APIS_DATA_VERSION_KEY));
    }

}
