package com.travelport.refdata.carriers.ls;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

//Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
@Ignore
public class LoadJet2ReferenceDataFilesTest {

    private static final String JET2_TRANSLATION_DATA_KEY = "JET2_TRANSLATION_DATA_KEY";
    private static final String JET2_TRANSLATION_DATA_FILE = "carriers/ls/LS_TranslationData.xml";
    private static final String JET2_TRANSLATION_DATA_VERSION_KEY = "JET2_TRANSLATION_DATA_VERSION_KEY";
    private static final Integer JET2_TRANSLATION_DATA_VERSION = 1;
    
    private static final String JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE = "carriers/ls/JET2AirOptionalServiceAndFees.xlsx";
    private static final String JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";
    private static final Integer JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION = 1;
    
    private static final String JET2_SUPPORTED_CURRENCY_LIST_KEY = "JET2_SUPPORTED_CURRENCY_LIST_KEY";
    private static final String JET2_SUPPORTED_CURRENCY_LIST_FILE = "carriers/ls/LS_Supported_Currency_List.xlsx";
    private static final String JET2_SUPPORTED_CURRENCY_LIST_VERSION_KEY = "JET2_SUPPORTED_CURRENCY_LIST_VERSION_KEY";
    private static final Integer JET2_SUPPORTED_CURRENCY_LIST_VERSION = 1;
    
    private static final String JET2_COUNTRY_CONVERSION_DATA_KEY = "JET2_COUNTRY_CONVERSION_DATA_KEY";
    private static final String JET2_COUNTRY_CONVERSION_DATA_FILE = "carriers/ls/LS_CountryCodes.xml";
    private static final String JET2_COUNTRY_CONVERSION_DATA_VERSION_KEY = "JET2_COUNTRY_CONVERSION_DATA_VERSION_KEY";
    private static final Integer JET2_COUNTRY_CONVERSION_DATA_VERSION = 1;

    @Test
    public void testLoadTranslationReferenceData () throws IOException {
        final InputStream fileToRead = LoadJet2ReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (JET2_TRANSLATION_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jet2_TranslationData Key and saved_version saved in Redis Cache.",
                connectorStream.save (JET2_TRANSLATION_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jet2_TranslationData Key and saved_version saved in Redis Cache.",
                connectorInteger.save (JET2_TRANSLATION_DATA_VERSION_KEY, JET2_TRANSLATION_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JET2_TRANSLATION_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("LS_TranslationData_Read.xml");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JET2_TRANSLATION_DATA_VERSION, connectorInteger.getValue (JET2_TRANSLATION_DATA_VERSION_KEY));
    }

    @Test
    public void testLoadCountryConversionReferenceData () throws IOException {
        final InputStream fileToRead = LoadJet2ReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (JET2_COUNTRY_CONVERSION_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jet2_CountryConversion Key and saved_version saved in Redis Cache.",
                connectorStream.save (JET2_COUNTRY_CONVERSION_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jet2_CountryConversion Key and saved_version saved in Redis Cache.",
                connectorInteger.save (JET2_COUNTRY_CONVERSION_DATA_VERSION_KEY, JET2_COUNTRY_CONVERSION_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JET2_COUNTRY_CONVERSION_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("LS_CountryCodes_Read.xml");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JET2_COUNTRY_CONVERSION_DATA_VERSION, connectorInteger.getValue (JET2_COUNTRY_CONVERSION_DATA_VERSION_KEY));
    }
    
    @Test
    public void testLoadAirOptionalServieAndFeesReferenceData () throws IOException {
        final InputStream fileToRead = LoadJet2ReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Jet2_SSR saved in Redis Cache.",
                connectorStream.save (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Jet2_SSR Key and saved_version saved in Redis Cache.",
                connectorInteger.save (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY, JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("JET2AirOptionalServiceAndFees_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION, connectorInteger.getValue (JET2_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY));
    }
    
    @Test
    public void testLoadSupportedCurrencyList () throws IOException {
		final InputStream fileToRead = LoadJet2ReferenceDataFilesTest.class.getClassLoader()
				.getResourceAsStream(JET2_SUPPORTED_CURRENCY_LIST_FILE);

		final byte[] allBytes = IOUtils.toByteArray(fileToRead);

		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig
				.prepareInputStreamRedisCacheConnector();

		assertTrue("Jet2_Supported_Currency saved in Redis Cache.",
				connectorStream.save(JET2_SUPPORTED_CURRENCY_LIST_KEY, allBytes));

		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig
				.prepareIntegerRedisCacheConnector();

		assertTrue("Jet2_Supported_Currency and saved_version saved in Redis Cache.",
				connectorInteger.save(JET2_SUPPORTED_CURRENCY_LIST_VERSION_KEY, JET2_SUPPORTED_CURRENCY_LIST_VERSION));

		final byte[] fileBytes = connectorStream.getValue(JET2_SUPPORTED_CURRENCY_LIST_KEY);

		OutputStream fileToWrite = new FileOutputStream("LS_Supported_Currency_List_Read.xlsx");

		fileToWrite.write(fileBytes);
		fileToWrite.flush();
		fileToWrite.close();

		assertEquals(JET2_SUPPORTED_CURRENCY_LIST_VERSION,
				connectorInteger.getValue(JET2_SUPPORTED_CURRENCY_LIST_VERSION_KEY));
    }
}
