package com.travelport.refdata.carriers.indigo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

//Should Not Run Live in Unit Test Cases (Implementation using Live Connect to Redis for Test)
//@Ignore
public class LoadIndigoReferenceDataFilesTest {

    private static final String INDIGO_TRANSLATION_DATA_KEY = "INDIGO_TRANSLATION_DATA_KEY";
    private static final String INDIGO_TRANSLATION_DATA_FILE = "carriers/indigo/6E_TranslationData.xml";
    private static final String INDIGO_TRANSLATION_DATA_VERSION_KEY = "INDIGO_TRANSLATION_DATA_VERSION_KEY";
    private static final Integer INDIGO_TRANSLATION_DATA_VERSION = 2;
    
    private static final String INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE = "carriers/indigo/IndigoAirOptionalServiceAndFees.xlsx";
    private static final String INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";
    private static final Integer INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION = 3;
    
    private static final String INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY = "INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY";
    private static final String INDIGO_PRODUCT_CLASS_MAPPING_DATA_FILE = "carriers/indigo/Indigo_ProductClassMapping.xml";
    private static final String INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY = "INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY";
    private static final Integer INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION = 3;
    
    
    private static final String INDIGO_CABIN_CLASS_DATA_KEY = "INDIGO_CABIN_CLASS_DATA_KEY";
    private static final String INDIGO_CABIN_CLASS_MAPPING_DATA_FILE = "carriers/indigo/Indigo_CabinClassMapping.xml";
    private static final String INDIGO_CABIN_CLASS_DATA_VERSION_KEY = "INDIGO_CABIN_CLASS_DATA_VERSION_KEY";
    private static final Integer INDIGO_CABIN_CLASS_DATA_VERSION = 1;
    
    private static final String INDIGO_ROLE_CODES_DATA_KEY = "INDIGO_ROLE_CODES_DATA_KEY";
    private static final String INDIGO_ROLE_CODES_DATA_FILE = "carriers/indigo/RoleCode_Indigo_Credentails.xlsx";
    private static final String INDIGO_ROLE_CODES_DATA_VERSION_KEY = "INDIGO_ROLE_CODES_DATA_VERSION_KEY";
    private static final Integer INDIGO_ROLE_CODES_DATA_VERSION = 1;
    
    private static final String INDIGO_FARERULE_DATA_KEY = "INDIGO_FARERULE_DATA_KEY";
    private static final String INDIGO_FARERULE_DATA_FILE = "carriers/indigo/IndigoFareRules.xlsx";
    private static final String INDIGO_FARERULE_DATA_VERSION_KEY = "INDIGO_FARERULE_DATA_VERSION_KEY";
    private static final Integer INDIGO_FARERULE_DATA_VERSION = 2;

    @Test
    public void testLoadTranslationReferenceData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (INDIGO_TRANSLATION_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo_TranslationData Key and saved_version saved in Redis Cache.",
                connectorStream.save (INDIGO_TRANSLATION_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo_TranslationData Key and saved_version saved in Redis Cache.",
                connectorInteger.save (INDIGO_TRANSLATION_DATA_VERSION_KEY, INDIGO_TRANSLATION_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_TRANSLATION_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("6E_TranslationData_Read.xml");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_TRANSLATION_DATA_VERSION, connectorInteger.getValue (INDIGO_TRANSLATION_DATA_VERSION_KEY));
    }

    
    @Test
    public void testLoadAirOptionalServieAndFeesReferenceData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo_SSR saved in Redis Cache.",
                connectorStream.save (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo_SSR Key and saved_version saved in Redis Cache.",
                connectorInteger.save (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY, INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("IndigoAirOptionalServiceAndFees_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION, connectorInteger.getValue (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY));
    }
    
    
    @Test
    public void testLoadProductClassMappingReferenceData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (INDIGO_PRODUCT_CLASS_MAPPING_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo Product Class saved in Redis Cache.", connectorStream.save (INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo Product Class version is saved in Redis Cache.", connectorInteger.save (INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY, INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("Indigo_ProductClassMapping_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION, connectorInteger.getValue (INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY));
    }
    
    
    
    @Test
    public void testLoadCabinClassMappingReferenceData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ().getResourceAsStream (INDIGO_CABIN_CLASS_MAPPING_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo Cabin Class saved in Redis Cache.", connectorStream.save (INDIGO_CABIN_CLASS_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo Cabin Class version is saved in Redis Cache.", connectorInteger.save (INDIGO_CABIN_CLASS_DATA_VERSION_KEY, INDIGO_CABIN_CLASS_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_CABIN_CLASS_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("Indigo_CabinClassMapping_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_CABIN_CLASS_DATA_VERSION, connectorInteger.getValue (INDIGO_CABIN_CLASS_DATA_VERSION_KEY));
    }
    
    
    @Test
    public void testLoadRoleCodesData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (INDIGO_ROLE_CODES_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo_role_codes data saved in Redis Cache.",
                connectorStream.save (INDIGO_ROLE_CODES_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo_role_codes and saved_version saved in Redis Cache.",
                connectorInteger.save (INDIGO_ROLE_CODES_DATA_VERSION_KEY, INDIGO_ROLE_CODES_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_ROLE_CODES_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("RoleCode_Indigo_Credentails_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_ROLE_CODES_DATA_VERSION, connectorInteger.getValue (INDIGO_ROLE_CODES_DATA_VERSION_KEY));
    }
    
    
    @Test
    public void testLoadFareRuleData () throws IOException {
        final InputStream fileToRead = LoadIndigoReferenceDataFilesTest.class.getClassLoader ()
                .getResourceAsStream (INDIGO_FARERULE_DATA_FILE);

        final byte[] allBytes = IOUtils.toByteArray (fileToRead);

        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        assertTrue ("Indigo_FARERULE data saved in Redis Cache.",
                connectorStream.save (INDIGO_FARERULE_DATA_KEY, allBytes));

        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        assertTrue ("Indigo_role_codes and saved_version saved in Redis Cache.",
                connectorInteger.save (INDIGO_FARERULE_DATA_VERSION_KEY, INDIGO_FARERULE_DATA_VERSION));

        
        final byte[] fileBytes = connectorStream.getValue (INDIGO_FARERULE_DATA_KEY);

        OutputStream fileToWrite = new FileOutputStream ("IndigoFareRules_Read.xlsx");
        
        fileToWrite.write (fileBytes);
        fileToWrite.flush ();
        fileToWrite.close ();
        
        assertEquals (INDIGO_FARERULE_DATA_VERSION, connectorInteger.getValue (INDIGO_FARERULE_DATA_VERSION_KEY));
    }
}
