package com.travelport.refdata.apis;

import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import com.travelport.model.catalog.Offer;
import com.travelport.model.catalog.OfferID;
import com.travelport.model.catalog.Product;
import com.travelport.model.catalog.ProductID;
import com.travelport.model.catalog.air.Arrival;
import com.travelport.model.catalog.air.Departure;
import com.travelport.model.catalog.air.Flight;
import com.travelport.model.catalog.air.FlightSegment;
import com.travelport.model.catalog.air.ProductAir;
import com.travelport.model.catalog.air.TermsAndConditionsFullAir;
import com.travelport.model.catalog.ancillary.ProductAncillary;
import com.travelport.model.catalog.ancillary.TermsAndConditionsFullAncillary;
import com.travelport.model.common.Identifier;
import com.travelport.model.common.StatusDetail;
import com.travelport.model.common.StatusTravelport;
import com.travelport.model.common.TextBlock;
import com.travelport.model.reservation.Reservation;
import com.travelport.model.traveler.TravelerSummary;
import com.travelport.refdata.apis.APISInfo.DefaultRespAPISDocTypes;
import com.tvp.model.catalog.air.FlightStatus;


public class APISDataProcessorTest {
	
	@Test
	public void testAPISDataPopulationInOffer() {
		Reservation reservation = createActiveOrder();
		APISDataProcessor.getInstance().processAPIS(reservation);
		Offer segmentOffer = (Offer)reservation.getOffer().get(0);
		Assert.assertTrue(segmentOffer.getTermsAndConditionsFull().size() == 1);
		Assert.assertTrue(segmentOffer.getTermsAndConditionsFull().get(0) instanceof TermsAndConditionsFullAir);
		TermsAndConditionsFullAir termsAndConditionsAirDetail = (TermsAndConditionsFullAir) segmentOffer.getTermsAndConditionsFull().get(0);
		Assert.assertTrue(!CollectionUtils.isEmpty(termsAndConditionsAirDetail.getTextBlock()));
		Assert.assertTrue(termsAndConditionsAirDetail.getTextBlock().size() == 5);
		
		TextBlock textBlock1 = termsAndConditionsAirDetail.getTextBlock().get(0);
		Assert.assertEquals("PRODUCT_IDENTIFIER", textBlock1.getTitle());
		Assert.assertTrue(textBlock1.getTextFormatted().size() == 1);
		Assert.assertEquals("1234", textBlock1.getTextFormatted().get(0).getValue());
		
		TextBlock textBlock2 = termsAndConditionsAirDetail.getTextBlock().get(1);
		Assert.assertEquals("APIS_Info", textBlock2.getTitle());
		Assert.assertTrue(textBlock2.getTextFormatted().size() == 1);
		Assert.assertEquals("Supported", textBlock2.getTextFormatted().get(0).getValue());
		
		TextBlock textBlock3 = termsAndConditionsAirDetail.getTextBlock().get(2);
		Assert.assertEquals("GenderDOB_Req", textBlock3.getTitle());
		Assert.assertTrue(textBlock3.getTextFormatted().size() == 1);
		Assert.assertEquals("Required", textBlock3.getTextFormatted().get(0).getValue());
		
		TextBlock textBlock4 = termsAndConditionsAirDetail.getTextBlock().get(3);
		Assert.assertEquals("NationalityRequired", textBlock4.getTitle());
		Assert.assertTrue(textBlock4.getTextFormatted().size() == 1);
		Assert.assertEquals("Required", textBlock4.getTextFormatted().get(0).getValue());
		
		TextBlock textBlock5 = termsAndConditionsAirDetail.getTextBlock().get(4);
		Assert.assertEquals("OtherDocTypes", textBlock5.getTitle());
		Assert.assertTrue(textBlock5.getTextFormatted().size() == 1);
		Assert.assertEquals("2.DOC", textBlock5.getTextFormatted().get(0).getValue());
		
		Offer ancillaryOffer = (Offer)reservation.getOffer().get(1);
		Assert.assertTrue(ancillaryOffer.getTermsAndConditionsFull().size() == 1);
		Assert.assertTrue(ancillaryOffer.getTermsAndConditionsFull().get(0) instanceof TermsAndConditionsFullAncillary);
		TermsAndConditionsFullAncillary termsAndConditionsAncillary = (TermsAndConditionsFullAncillary) ancillaryOffer.getTermsAndConditionsFull().get(0);
		Assert.assertNotNull(termsAndConditionsAncillary.getTraveler());
		Assert.assertTrue(termsAndConditionsAncillary.getTextBlock().size() == 0);
	}
	
	@Test
	public void testAPISDataPopulationInPassiveOffer() {
		Reservation reservation = createPassiveOrder();
		APISDataProcessor.getInstance().processAPIS(reservation);
		Offer offer = (Offer)reservation.getOffer().get(0);
		Assert.assertTrue(offer.getTermsAndConditionsFull().size() == 0);
	}
	
	
	private Reservation createActiveOrder() {
		Reservation order = new Reservation();
		Identifier orderIdentifier = new Identifier();
		orderIdentifier.setValue(UUID.randomUUID().toString());
		order.setIdentifier(orderIdentifier);
		
		Offer offer = new Offer();
		Identifier offerIdentifier = new Identifier();
		offerIdentifier.setValue(UUID.randomUUID().toString());
		offer.setIdentifier(offerIdentifier);
		
		//Product products = new Product();
		ProductID productID = new ProductID ();
        productID.setId ("0af56276-9f6b-480b-8e93-c68edf8047d7-ORD1");
        ProductAir productAir = new ProductAir();
        productAir.setProductRef (productID);
		Identifier productIdentifier = new Identifier();
		productIdentifier.setValue("1234");
		productAir.setIdentifier(productIdentifier);
		
		offer.getProduct().add(0,productAir);
		
		FlightSegment segmentDetail = new FlightSegment();
		//Identifier segmentIdentifier = new Identifier();
		//segmentIdentifier.setValue(UUID.randomUUID().toString());
		//segmentDetail.setId(segmentIdentifier);
		segmentDetail.setId("Seg1");
		
		FlightStatus flightStatus = new FlightStatus();
		flightStatus.setCarrier("AK");
		flightStatus.setNumber("800");
		Arrival arrival = new Arrival();
		arrival.setLocation("ARR");
		flightStatus.setArrival(arrival);
		
		Departure departure = new Departure();
		departure.setLocation("DEP");
		flightStatus.setDeparture(departure);
		
		Flight flight = new Flight();
		flight.setCarrier("I5");
		flight.setNumber("1000");
		segmentDetail.setFlight(flight);
		
		StatusDetail status = new StatusDetail();
		StatusTravelport tvlStaus = new StatusTravelport();
		tvlStaus.setValue("Hold");
		status.setTravelportStatus(tvlStaus);
		flightStatus.setStatus(status);
		segmentDetail.setFlight(flightStatus);
		
		/*CabinClass cabinClass = new CabinClass();
		cabinClass.getSegmentRef().add(segmentDetail);
		cabinClass.setClassOfService("X");
		cabinClass.setValue(CabinAirEnum.ECONOMY);
		productAir.getCabinClass().add(cabinClass);*/
		productAir.getFlightSegment().add(0,segmentDetail);
		order.getOffer().add(offer);
		
		//Ancillary offer
		
		//To-Do ModelUPgrade as there is no element in reservation to set Ancillary
		
		Offer offerAnc = new Offer();
		Identifier ancOfferIdentifier = new Identifier();
		ancOfferIdentifier.setValue(UUID.randomUUID().toString());
		offerAnc.setIdentifier(ancOfferIdentifier);
		
		Product ancProducts = new Product();
		ProductAncillary productAncillary = new ProductAncillary();
		Identifier ancProductIdentifier = new Identifier();
		ancProductIdentifier.setValue("1234");
		productAncillary.setIdentifier(ancProductIdentifier);
		ancProducts.setProductRef(productAncillary);
		offerAnc.getProduct().add(ancProducts);
		
		TermsAndConditionsFullAncillary termsAndConditionsAncillary = new TermsAndConditionsFullAncillary();
		TravelerSummary travelerSummary = new TravelerSummary();
		Identifier travalerIdentifier = new Identifier();
		travalerIdentifier.setValue(UUID.randomUUID().toString());
		travelerSummary.setIdentifier(travalerIdentifier);
		termsAndConditionsAncillary.setTraveler(travelerSummary);
		offerAnc.getTermsAndConditionsFull().add(termsAndConditionsAncillary);
		
		order.getOffer().add(offerAnc);
		
		return order;
	}
	
	private Reservation createPassiveOrder() {
		Reservation reservation = new Reservation();
		Identifier orderIdentifier = new Identifier();
		orderIdentifier.setValue(UUID.randomUUID().toString());
		reservation.setIdentifier(orderIdentifier);
		
		Offer offer = new Offer();
		Identifier offerIdentifier = new Identifier();
		offerIdentifier.setValue(UUID.randomUUID().toString());
		offer.setIdentifier(offerIdentifier);
		
		//Product products = new Product();
		ProductID productID = new ProductID ();
        productID.setId ("0af56276-9f6b-480b-8e93-c68edf8047d7-ORD1");
        ProductAir productAir = new ProductAir();
        productAir.setProductRef (productID);
		
		FlightSegment segmentDetail = new FlightSegment();
		/*Identifier segmentIdentifier = new Identifier();
		segmentIdentifier.setValue(UUID.randomUUID().toString());
		segmentDetail.setIdentifier(segmentIdentifier);*/
		segmentDetail.setId("Seg1");
		
		FlightStatus flightStatus = new FlightStatus();
		flightStatus.setCarrier("AK");
		flightStatus.setNumber("800");
		Arrival arrival = new Arrival();
		arrival.setLocation("ARR");
		flightStatus.setArrival(arrival);
		
		Departure departure = new Departure();
		departure.setLocation("DEP");
		flightStatus.setDeparture(departure);
		
		Flight flight = new Flight();
		flight.setCarrier("I5");
		flight.setNumber("1000");
		segmentDetail.setFlight(flight);
		
		StatusDetail status = new StatusDetail();
		StatusTravelport tvlStaus = new StatusTravelport();
		tvlStaus.setValue("Passive");
		status.setTravelportStatus(tvlStaus);
		flightStatus.setStatus(status);
		productAir.getFlightSegment().add(segmentDetail);
		
		/*CabinClass cabinClass = new CabinClass();
		cabinClass.getSegmentRef().add(segmentDetail);
		cabinClass.setClassOfService("X");
		cabinClass.setValue(CabinAirEnum.ECONOMY);
		productAir.getCabinClass().add(cabinClass);*/
		
		reservation.getOffer().add(offer);
		return reservation;
	}
	
	@Test 
	public void testCheckFlightStatus() {
		APISDataProcessor aPISDataProcessor = new APISDataProcessor();
		FlightSegment firstFlightSegment = new FlightSegment();
		firstFlightSegment.setFlight(null);
		boolean status = aPISDataProcessor.checkFlightStatus(firstFlightSegment);
		
		assertNotNull(status);
	}
	
	@Test
	public void testParseAPISData() {
		try {
		APISDataProcessor.parseAPISData(null);
		} catch (Exception e) {
			assertNotNull(e.getMessage());
		}
	}
	@Test
	public void testClose() {
		
		Method methodToInvoke = null;
		for (Method method : APISDataProcessor.class.getDeclaredMethods()) {
			if (method.getName().equalsIgnoreCase("close")) {
				methodToInvoke = method;
				break;
			}
		}
		methodToInvoke.setAccessible(true);
		try {
			InputStream apiData = null;
			methodToInvoke.invoke(APISDataProcessor.class, apiData);
			Assert.fail("Expected an Exception");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void testGetPrimaryCarrierCodeForOrder() {
		Reservation reservation = new Reservation();
		APISDataProcessor aPISDataProcessor = Mockito.spy(new APISDataProcessor());
		Mockito.when(aPISDataProcessor.isActiveOrder(reservation)).thenReturn(true);
		Mockito.when(aPISDataProcessor.getPrimaryCarrierCodeForOrder(reservation)).thenReturn(null);
		aPISDataProcessor.processAPIS(reservation);
		assertNotNull(reservation);
		
	}
	
	@Test
	public void testProcessAPISInfo() {
		APISDataProcessor aPISDataProcessor = new APISDataProcessor();
		Reservation reservation = new Reservation();
		APISInfo apisInfo = new APISInfo();
		apisInfo.setSource("ConfigNotFixed");
		aPISDataProcessor.processAPISInfo(reservation, "AK", apisInfo);
		assertNotNull(apisInfo);
	}
	
	@Test
	public void testApplyAPISInOffer() {
		APISDataProcessor aPISDataProcessor = new APISDataProcessor();
		APISInfo apisInfo = new APISInfo();
		List<OfferID> offerIDList = new ArrayList<>();
		aPISDataProcessor.applyAPISInOffer(offerIDList, apisInfo);
		assertNotNull(apisInfo);
	}
	
	@Test
	public void testCreateTermsAndConditionsAirDetail() {
		Offer offer = new Offer();
		String productIdentifier = "1234";
		APISInfo apisInfo = new APISInfo();
		apisInfo.setFixedAPISInfo("");
		APISDataProcessor.createTermsAndConditionsAirDetail(offer, productIdentifier, apisInfo);
		assertNotNull(apisInfo);
	}
	
	@Test
	public void testCreateTermsAndConditionsAirDetailSub() {
		Offer offer = new Offer();
		String productIdentifier = "1234";
		APISInfo apisInfo = new APISInfo();
		DefaultRespAPISDocTypes defaultRespAPISDocTypes = new DefaultRespAPISDocTypes();
		defaultRespAPISDocTypes.setGenderDOBReq("");
		apisInfo.setDefaultRespAPISDocTypes(defaultRespAPISDocTypes);
		APISDataProcessor.createTermsAndConditionsAirDetail(offer, productIdentifier, apisInfo);
		assertNotNull(apisInfo);
	}

}
