package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

public class CarrierLookupTest {
	
	@Test
	public void testCarrierLookup_AK(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("AK");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_D7(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("D7");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_FD(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("FD");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_QZ(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("QZ");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_Z2(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("Z2");
		assertEquals("AK",carrierCode);		
	}
	
	
	@Test
	public void testCarrierLookup_DJ(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("DJ");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_XJ(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("XJ");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_I5(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("I5");
		assertEquals("AK",carrierCode);		
	}
	
	@Test
	public void testCarrierLookup_XT(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		String carrierCode = carrierLookup.getCarrierCodeBySecondaryCode("XT");
		assertEquals("AK",carrierCode);		
	}
	
	
	@Test
    public void testCarrierLookup_AirlineName_AK(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("AK");
        assertEquals("Air Asia",name);
    }
	
	@Test
    public void testCarrierLookup_AirlineName_JM(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("JM");
        assertEquals("Jambojet",name);
    }
	
	@Test
    public void testCarrierLookup_AirlineName_HV(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("HV");
        assertEquals("Transavia",name);
    }
	
	@Test
    public void testCarrierLookup_AirlineName_HV_TO(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("TO");
        assertEquals("Transavia France",name);
    }
	
	@Test
    public void testCarrierLookup_AirlineName_6E(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("6E");
        assertEquals("Indigo",name);
    }
	//@Test
    public void testCarrierLookup_AirlineName_Cache() throws InterruptedException{
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("6E");
        assertEquals("Indigo",name);
    }
    @Test
    public void testCarrierLookup_AirlineName_UA(){
        CarrierLookup carrierLookup = CarrierLookup.getInstance();
        String name = carrierLookup.getAirLineNameByPrimaryCarrierCode("UA");
        assertEquals("UnitedAir",name);
    }
    
    @Test
	public void testSecondaryCarrierLookup(){
		CarrierLookup carrierLookup = CarrierLookup.getInstance();
		List<String> carrierCode = carrierLookup.getSecondaryCarrierCodeByPrimaryCarrierCode("AK");
		assertNotNull(carrierCode);
	}
}
