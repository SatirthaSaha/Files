package com.travelport.refdata.lookup;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class OriginApplicationIDLookupTest {

    @Test
    public void testOriginApplicationIDLookup_96C65610_TASapp () {

        String originApplicationID = "96C65610-TASapp";
        OriginApplicationIDLookup originApplicationIDLookUp = OriginApplicationIDLookup.getInstance ();
        assertTrue (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID));
    }

    @Test
    public void testOriginApplicationIDLookup_EB8DBD6D_SMRT71 () {

        String originApplicationID = "EB8DBD6D-SMRT71";
        OriginApplicationIDLookup originApplicationIDLookUp = OriginApplicationIDLookup.getInstance ();
        assertTrue (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID));
    }

    @Test
    public void testOriginApplicationIDLookup_CE1A2A96_SMRT72 () {

        String originApplicationID = "CE1A2A96-SMRT72";
        OriginApplicationIDLookup originApplicationIDLookUp = OriginApplicationIDLookup.getInstance ();
        assertTrue (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID));
    }

    @Test
    public void testOriginApplicationIDLookup_False () {

        String originApplicationID = "1234567-TASapp";
        OriginApplicationIDLookup originApplicationIDLookUp = OriginApplicationIDLookup.getInstance ();
        assertFalse (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID));
    }
    
   
    //@Test
    public void testOriginApplicationIDLookup_Cache () throws InterruptedException {

        String originApplicationID = "EB8DBD6D-SMRT71";
        OriginApplicationIDLookup originApplicationIDLookUp = OriginApplicationIDLookup.getInstance ();
        assertTrue (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID));
        
        String originApplicationID1 = "1234567-TASapp";
        assertFalse (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID1));
        
      
        String originApplicationID2 = "CE1A2A96-SMRT72";
        assertTrue (originApplicationIDLookUp.isSmartPointOrTASOriginApplicationId (originApplicationID2));
        
        
        
    }

}
