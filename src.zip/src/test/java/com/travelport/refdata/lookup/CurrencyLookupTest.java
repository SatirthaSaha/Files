package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.Currency;

public class CurrencyLookupTest {
	
	@Test
	public void testCurrrency_DRW(){
		CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
		Currency currency = currencyTranslator.getCurrencyByAirportCode("DRW");
		assertEquals("DRW",currency.getAirportCode());
		assertEquals("AUD",currency.getCurrencyCode());
		assertEquals(2,currency.getCurrencyDecimal());
		assertEquals(0.1,currency.getCurrencyRoundUnit(),0);
		assertEquals("U",currency.getCurrencyRoundAction());
	}
	
	@Test
	public void testCurrrency_HND(){
		CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
		Currency currency = currencyTranslator.getCurrencyByAirportCode("HND");
		assertEquals("HND",currency.getAirportCode());
		assertEquals("JPY",currency.getCurrencyCode());
		assertEquals(0,currency.getCurrencyDecimal());
		assertEquals(1.0,currency.getCurrencyRoundUnit(),0);
		assertEquals("U",currency.getCurrencyRoundAction());
	}
	
	@Test
	public void testCurrrency_CNY(){
		CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
		Currency currency = currencyTranslator.getCurrencyByAirportCode("AAT");
		assertEquals("AAT",currency.getAirportCode());
		assertEquals("CNY",currency.getCurrencyCode());
		assertEquals(2,currency.getCurrencyDecimal());
		assertEquals(1,currency.getCurrencyRoundUnit(),0);
		assertEquals("U",currency.getCurrencyRoundAction());
	}
	
	@Test
    public void testGetCurrencyByCurencyCode() throws InterruptedException{
        CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
        Currency currency = currencyTranslator.getCurrencyByCurencyCode ("USD");
        assertNotNull(currency);
    }
	
	@Test
    public void testGetDeltaCurrencyByCurencyCode() throws InterruptedException{
        CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
        Currency currency = currencyTranslator.getDeltaCurrencyByCurencyCode ("GBP");
        assertNotNull(currency);
    } 
	
	@Test
    public void testGetAllCurrency() throws InterruptedException{
        CurrencyLookup currencyTranslator = CurrencyLookup.getInstance();
        Map<String, Currency> currency = currencyTranslator.getAllCurrency ();
        assertNotNull(currency);
    }
		
	@Test
	public void testGetCellDataForCellTypeError() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		CurrencyLookup.getCellData(row.getCell(0));
		
		row.getCell(0).setCellType(1);
		CurrencyLookup.getCellData(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
	
	@Test
	public void testGetCellDataForNotRead() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(1);
		CurrencyLookup.getCellData(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
}
