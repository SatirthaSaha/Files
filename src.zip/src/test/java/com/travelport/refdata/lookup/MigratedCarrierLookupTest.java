package com.travelport.refdata.lookup;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

public class MigratedCarrierLookupTest {

    @Test
    public void testMigratedCarrierLookup () {

        List<String> migratedCarrier = MigratedCarrierLookup.getMigratedCarriers ();
        assertNotNull (migratedCarrier);

    }

    @Test
    public void testNonMigratedCarrierLookup () {

        List<String> nonMigratedCarrier = MigratedCarrierLookup.getNonMigratedCarriers ();
        String nonMigratedCarrier_U2 = "U2";
        assertTrue (nonMigratedCarrier.contains (nonMigratedCarrier_U2));
    }
    
    @Test
	public void testGetCellValueForBoolean() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(MigratedCarrierLookup.MIGRATED_CARRIER_MAP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_BOOLEAN);
		MigratedCarrierLookup.getCellValue(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellValueForNumeric() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(MigratedCarrierLookup.MIGRATED_CARRIER_MAP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		MigratedCarrierLookup.getCellValue(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1ForError() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(MigratedCarrierLookup.MIGRATED_CARRIER_MAP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		MigratedCarrierLookup.getCellData1(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1Default() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(MigratedCarrierLookup.MIGRATED_CARRIER_MAP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
		MigratedCarrierLookup.getCellData1(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
    public void testConstructor () throws Exception {
    	Constructor constructor = MigratedCarrierLookup.class.getDeclaredConstructor();
    	constructor.setAccessible(true); 
    	constructor.newInstance();
	    assertNotNull(constructor);
    }
}
