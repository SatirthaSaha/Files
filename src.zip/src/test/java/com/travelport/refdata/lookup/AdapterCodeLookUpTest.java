package com.travelport.refdata.lookup;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdapterCodeLookUpTest {

    @Test
    public void testGetpaymentTypevalue () {

        String adptCode = AdapterCodeLookUp.getInstance ().getAdaptorCodeByCarrierCode ("6E");
        assertEquals (adptCode,"NNS6E");

    }
    
    @Test
    public void testGetNullInstance () {
    	AdapterCodeLookUp.adapterCodeLookUp.getAdaptorCodeByCarrierCode("AK");
        AdapterCodeLookUp.getInstance ();
        assertNotNull(AdapterCodeLookUp.adapterCodeLookUp);
    }
}
