package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;

import com.travelport.refdata.models.ODTInvocationBuilder;

public class AtomicCarrierLookupTest {
	private final String qName= "http://www.tvp.com/model/catalog/v4";
	private final String localName= "NDCSegmentShopResource";
	private final String action= "RETRIEVE" ;
	private final String systemId= "ATOMIC_SHOP";
	private final String version= "4";

	@Test
	public void testGetPrimaryCarrierODTInvocationMap(){
		AtomicCarrierLookup atomicCarrierLookup = AtomicCarrierLookup.getInstance();
		Map<String, ODTInvocationBuilder> primaryCarrierODTInvocationMap = atomicCarrierLookup.getPrimaryCarrierODTInvocationMap();
		assertEquals("Return number of on boarded carrier with ODTInvocation", 3, primaryCarrierODTInvocationMap.size());	
	}
	
	@Test
	public void testAtomicCarrierLookup(){
		AtomicCarrierLookup atomicCarrierLookup = AtomicCarrierLookup.getInstance();
		ODTInvocationBuilder odtInvocationByPrimaryCarrier = atomicCarrierLookup.getODTInvocationByPrimaryCarrier("QF");
		assertEquals("Return ODTInvocation qName", qName, odtInvocationByPrimaryCarrier.getqName());	
		assertEquals("Return ODTInvocation localName", localName, odtInvocationByPrimaryCarrier.getLocalName());	
		assertEquals("Return ODTInvocation action", action, odtInvocationByPrimaryCarrier.getAction());	
		assertEquals("Return ODTInvocation systemId", systemId, odtInvocationByPrimaryCarrier.getSystemId());
		assertEquals("Return ODTInvocation systemId", version, odtInvocationByPrimaryCarrier.getVersion());
	}
}
