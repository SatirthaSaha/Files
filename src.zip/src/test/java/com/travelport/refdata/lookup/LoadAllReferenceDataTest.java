package com.travelport.refdata.lookup;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

@Ignore
public class LoadAllReferenceDataTest {
	
	private static final String CARD_CARRIER_CURRENCY_UNSUPPORTED_KEY = "Card_Carrier_Currency_Unsupported";
	private static final String CARD_CARRIER_CURRENCY_UNSUPPORTED_VERSION = "Card_Carrier_Currency_Unsupported_Version";
	private static final Integer CARD_CARRIER_CURRENCY_UNSUPPORTED_ACTUAL_VERSION = 1;
	
	private static final String CARRIER_MAPPING_KEY = "CarrierMapping";
	private static final String CARRIER_MAPPING_VERSION_KEY = "CarrierMapping_Version";
	private static final Integer CARRIER_MAPPING_ACTUAL_VERSION = 8;
	
	private static final String AIRPORT_GEO_HIERARCHY_KEY = "Airport_Geo_Hierarchy";
	private static final String AIRPORT_GEO_HIERARCHY_VERSION = "Airport_Geo_Hierarchy_Version";
	private static final Integer AIRPORT_GEO_HIERARCHY_ACTUAL_VERSION = 1;
	
	private static final String CURRENCY_LOOKUP_KEY = "CurrencyLookup";
	private static final String CURRENCY_LOOKUP_VERSION_KEY = "CurrencyLookup_Version";
	private static final Integer CURRENCY_LOOKUP_ACTUAL_VERSION = 2;
	
	
	private static final String DELTA_CURRENCY_LOOKUP_KEY = "DeltaCurrencyLookup";
	private static final String DELTA_CURRENCY_LOOKUP_VERSION_KEY = "Delta_CurrencyLookup_Version";
	private static final Integer DELTA_CURRENCY_LOOKUP_ACTUAL_VERSION = 1;
	
	private static final String AIRPORT_SUPPORTED_CURRENCY_MAP_KEY = "AirportSupportedCurrencyMap";
	private static final String AIRPORT_SUPPORTED_CURRENCY_MAP_VERSION_KEY = "AirportSupportedCurrencyMap_Version";
	private static final Integer AIRPORT_SUPPORTED_CURRENCY_MAP_ACTUAL_VERSION = 5;
	
    private static final String MIGRATED_CARRIER_MAP_KEY = "MigratedCarriersMapping";
    private static final String MIGRATED_CARRIER_MAP_VERSION_KEY = "MigratedCarriersMap_Version";
    private static final Integer MIGRATED_CARRIER_MAP_ACTUAL_VERSION = 11;
    
    private static final String ACO_MIGRATED_CARRIER_MAP_KEY = "ACOMigratedCarriersMapping";
    private static final String ACO_MIGRATED_CARRIER_MAP_VERSION_KEY = "ACOMigratedCarriersMap_Version";
    private static final Integer ACO_MIGRATED_CARRIER_MAP_ACTUAL_VERSION = 1;
    
    
    private static final String ORIGIN_APPLICATION_ID_MAPPING_KEY = "OriginApplicationIDMapping";
    private static final String ORIGIN_APPLICATION_ID_MAPPING_VERSION_KEY = "OriginApplicationIDMapping_Version";
    private static final Integer ORIGIN_APPLICATION_ID_MAPPING_ACTUAL_VERSION = 1;
    
    private static final String NDC_CABIN_TYPE_MAPPING_KEY = "NDCCabinTypeMapping";
	private static final String NDC_CABIN_TYPE_MAPPING_VERSION_KEY = "NDCCabinTypeMapping_Version";
	private static final Integer NDC_CABIN_TYPE_MAPPING_ACTUAL_VERSION = 3;
	
	private static final String SHOP_ATOMIC_MAPPING_KEY = "ShopAtomicMapping";
	private static final String SHOP_ATOMIC_MAPPING_VERSION_KEY = "ShopAtomicMapping_Version";
	private static final Integer SHOP_ATOMIC_MAPPING_ACTUAL_VERSION = 1;
	
	private static final String CARRIER_MODIFIER_LOOKUP_KEY = "ShopAirModifierMapping";
	private static final String CARRIER_MODIFIER_LOOKUP_VERSION_KEY = "ShopAirModifierMapping_Version";
	private static final Integer CARRIER_MODIFIER_MAPPING_ACTUAL_VERSION = 1;
	
	
	
	
	@Test
	public void test_LoadCarrierCurrencyLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierCurrencyLookup.class.getClassLoader().getResourceAsStream("Card_Carrier_Currency_UnSupported_list.xlsx");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Card Carrier Currency Unsupported XL Not Saved in Redis Cache." , connectorStream.save(CARD_CARRIER_CURRENCY_UNSUPPORTED_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Card Carrier Currency Unsupported Version Not Saved in Redis Cache." , connectorInteger.save(CARD_CARRIER_CURRENCY_UNSUPPORTED_VERSION, CARD_CARRIER_CURRENCY_UNSUPPORTED_ACTUAL_VERSION));
	}
	
	@Test
	public void test_LoadCarrierLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierLookup.class.getClassLoader().getResourceAsStream("CarrierMapping.xml");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(CARRIER_MAPPING_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(CARRIER_MAPPING_VERSION_KEY, CARRIER_MAPPING_ACTUAL_VERSION));
	}
	
	@Test
	public void test_CityOrAirportLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierLookup.class.getClassLoader().getResourceAsStream("Airport_Geo_Hierarchy.xlsx");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(AIRPORT_GEO_HIERARCHY_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(AIRPORT_GEO_HIERARCHY_VERSION, AIRPORT_GEO_HIERARCHY_ACTUAL_VERSION));
	}
	
	@Test
	public void test_CurrencytLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierLookup.class.getClassLoader().getResourceAsStream("Airport_Currency_Decimal_list.xlsx");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(CURRENCY_LOOKUP_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(CURRENCY_LOOKUP_VERSION_KEY, CURRENCY_LOOKUP_ACTUAL_VERSION));
	}
	
	@Test
	public void test_DeltaCurrencytLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierLookup.class.getClassLoader().getResourceAsStream("Delta_Currency_list.xlsx");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Delta Carrier Lookup excel Not Saved in Redis Cache." , connectorStream.save(DELTA_CURRENCY_LOOKUP_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Delta Carrier Lookup excel Version Not Saved in Redis Cache." , connectorInteger.save(DELTA_CURRENCY_LOOKUP_VERSION_KEY, DELTA_CURRENCY_LOOKUP_ACTUAL_VERSION));
	}
	
	@Test
	public void test_SupportedCurrencyLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = CarrierLookup.class.getClassLoader().getResourceAsStream("Currency_Support_and_Override_Currency_Final.xlsx");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(AIRPORT_SUPPORTED_CURRENCY_MAP_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(AIRPORT_SUPPORTED_CURRENCY_MAP_VERSION_KEY, AIRPORT_SUPPORTED_CURRENCY_MAP_ACTUAL_VERSION));
	}
	
    @Test
    public void test_ACOMigratedCarrierLookupReferenceData () throws IOException {
        final InputStream migratedCarriers = MigratedCarrierLookup.class.getClassLoader().getResourceAsStream("Migrated_NonMigrated_ACO.xlsx");
        final byte[] allBytes = IOUtils.toByteArray(migratedCarriers);
        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
        assertTrue("Migrated Carriers Lookup Xml Not Saved in Redis Cache." , connectorStream.save(ACO_MIGRATED_CARRIER_MAP_KEY, allBytes));
        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
        assertTrue("Migrated Carriers Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(ACO_MIGRATED_CARRIER_MAP_VERSION_KEY, ACO_MIGRATED_CARRIER_MAP_ACTUAL_VERSION));
    }
    
    @Test
    public void test_MigratedCarrierLookupReferenceData () throws IOException {
        final InputStream migratedCarriers = MigratedCarrierLookup.class.getClassLoader().getResourceAsStream("Migrated_NonMigrated_Carrier.xlsx");
        final byte[] allBytes = IOUtils.toByteArray(migratedCarriers);
        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
        assertTrue("Migrated Carriers Lookup Xml Not Saved in Redis Cache." , connectorStream.save(MIGRATED_CARRIER_MAP_KEY, allBytes));
        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
        assertTrue("Migrated Carriers Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(MIGRATED_CARRIER_MAP_VERSION_KEY, MIGRATED_CARRIER_MAP_ACTUAL_VERSION));
    }
    
    @Test
    public void test_OriginApplicationIDLookupReferenceData() throws IOException{
        final InputStream xmlFileToRead = OriginApplicationIDLookup.class.getClassLoader().getResourceAsStream("SmartPoint_TAS_OriginApplicationID_List.xml");
        final byte[] allBytes = IOUtils.toByteArray(xmlFileToRead);
        final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
        assertTrue("OriginApplicationID Lookup Xml Not Saved in Redis Cache." , connectorStream.save(ORIGIN_APPLICATION_ID_MAPPING_KEY, allBytes));
        final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
        assertTrue("OriginApplicationID Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(ORIGIN_APPLICATION_ID_MAPPING_VERSION_KEY, ORIGIN_APPLICATION_ID_MAPPING_ACTUAL_VERSION));
    }
    
    @Test
	public void test_NDCCabinTypeLookupReferenceData() throws IOException{
		final InputStream xmlFileToRead = NDCCabinTypeLookup.class.getClassLoader().getResourceAsStream("CabinTypeMapping.xml");
		final byte[] allBytes = IOUtils.toByteArray(xmlFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("NDC CabinType Lookup Xml Not Saved in Redis Cache." , connectorStream.save(NDC_CABIN_TYPE_MAPPING_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(NDC_CABIN_TYPE_MAPPING_VERSION_KEY, NDC_CABIN_TYPE_MAPPING_ACTUAL_VERSION));
	}
    
	@Test
	public void test_AtomicHealthLogServiceReferenceData() throws IOException {
		final InputStream xmlFileToRead = AtomicHealthLogServiceLookup.class.getClassLoader()
				.getResourceAsStream("ref_data_atomic_health_log_service.xml");
		final byte[] allBytes = IOUtils.toByteArray(xmlFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig
				.prepareInputStreamRedisCacheConnector();

		assertTrue("ref_data_atomic_health_log_service.xml Not Saved in Redis Cache.",
				connectorStream.save(AtomicHealthLogServiceLookup.REF_DATA_MAPPING_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig
				.prepareIntegerRedisCacheConnector();
		assertTrue("ref_data_atomic_health_log_service.xml Version Not Saved in Redis Cache.",
				connectorInteger.save(AtomicHealthLogServiceLookup.REF_DATA_ACTUAL_VERSION, 1));
	}
    @Test
	public void test_LoadAtomicCarrierLookupReferenceData() throws IOException{
		final InputStream excelFileToRead = AtomicCarrierLookup.class.getClassLoader().getResourceAsStream("ShopAtomicMapping.xml");
		final byte[] allBytes = IOUtils.toByteArray(excelFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Atomic Carrier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(SHOP_ATOMIC_MAPPING_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Atomic Carrier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(SHOP_ATOMIC_MAPPING_VERSION_KEY, SHOP_ATOMIC_MAPPING_ACTUAL_VERSION));
	}
    
    @Test
	public void testLoadCarrierModifierLookupReferenceData() throws IOException{
    	final InputStream xmlFileToRead = CarrierModifierLookup.class.getClassLoader().getResourceAsStream("ShopAirModifierMapping.xml");
		final byte[] allBytes = IOUtils.toByteArray(xmlFileToRead);
		final InputStreamRedisCacheConnectorImpl connectorStream = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		assertTrue("Carrier Modifier Lookup Xml Not Saved in Redis Cache." , connectorStream.save(CARRIER_MODIFIER_LOOKUP_KEY, allBytes));
		final IntegerRedisCacheConnectorImpl connectorInteger = RedisConnectorConfig.prepareIntegerRedisCacheConnector();
		assertTrue("Carrier Modifier Lookup Xml Version Not Saved in Redis Cache." , connectorInteger.save(CARRIER_MODIFIER_LOOKUP_VERSION_KEY, CARRIER_MODIFIER_MAPPING_ACTUAL_VERSION));
	
	}
}
