package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

public class AtomicHealthServiceLookupTest {

	@Test
	public void testSupportedOperationList() {
		AtomicHealthLogServiceLookup atomicHealthServiceLookup = AtomicHealthLogServiceLookup.getInstance();
		List<String> supportedOperationList = atomicHealthServiceLookup.getSupportedOperationList();
		assertEquals("Return number of on boarded operation with Health Log Service", 3, supportedOperationList.size());
	}

	@Test
	public void testSupportedCarrierList() {
		AtomicHealthLogServiceLookup atomicHealthServiceLookup = AtomicHealthLogServiceLookup.getInstance();
		List<String> supportedCarrierList = atomicHealthServiceLookup.getSupportedCarrierList();
		assertEquals("Return number of on boarded carrier with Health Log Service", 3, supportedCarrierList.size());
	}
}
