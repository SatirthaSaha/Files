package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PaymentTypeLookUpTest {

    @Test
    public void testgetpaymentTypevalue () {

        String paymentType = PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("11");
        assertEquals (paymentType,"Coupon");
        
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("3 "),"Voucher");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("4 "),"Pre-pay");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("5 "),"Credit card");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("6 "),"Debit card");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("7 "),"Check");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("8 "),"Deposit");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("9 "),"Business account");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("10"),"Central bill");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("12"),"Business check");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("13"),"Personal check");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("14"),"Money order");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("15"),"Redemption");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("16"),"Barter");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("17"),"Miscellaneous charge order");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("18"),"Travel agency name/address");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("19"),"Travel agency IATA number");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("20"),"Certified check");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("21"),"Club membership ID");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("22"),"Frequent guest number");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("23"),"Frequent traveler number");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("24"),"Guest name/address");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("25"),"Special industry program");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("26"),"Tour order");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("27"),"Traveler's check");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("28"),"Wire payment");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("29"),"Company name/address");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("30"),"Corporate ID/CD number");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("31"),"Guarantee");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("32"),"Other information");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("33"),"Override guarantee information");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("34"),"Corporate");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("35"),"Airline payment card");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("36"),"Air travel card");
        assertEquals (PaymentTypeLookUp.getInstance ().getpaymentTypevalue ("99"),"BSP Payment");
        

    }
}
