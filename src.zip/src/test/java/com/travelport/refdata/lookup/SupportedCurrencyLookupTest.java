package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

public class SupportedCurrencyLookupTest {

	@Test
	public void testcarrierCurrency_AAF_AK() throws IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAF", "AK");
		assertEquals("USD", currency);
	}

	@Test
	public void testcarrierCurrency_AAL_FR() throws IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAL", "FR");
		assertEquals("DKK", currency);
	}

	@Test
	public void testcarrierCurrency_AAR_HV() throws IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAR", "HV");
		assertEquals("EUR", currency);
	}

	@Test
	public void testcarrierCurrency_AAW_6E() throws IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAW", "6E");
		assertEquals("INR", currency);
	}

	@Test
	public void testcarrierCurrency_ABC_LS() throws IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("ABC", "LS");
		assertEquals("EUR", currency);
	}

	// @Test
	public void testcarrierCurrency_CacheUpdate_ABC_LS() throws InterruptedException, IOException {

		SupportedCurrencyLookup supportedCurrencyLookup = SupportedCurrencyLookup.getInstance();
		String currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("ABC", "LS");
		assertEquals("EUR", currency);

		currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAW", "6E");
		assertEquals("INR", currency);

		currency = supportedCurrencyLookup.getSupportedAndOverriddenCurrency("AAL", "FR");
		assertEquals("DKK", currency);
	}
	
	@Test
	public void testGetCellData1WithNull() {
		try {
		SupportedCurrencyLookup.getCellData1(null);
		} catch(Exception e) {
			assertNotNull(e);
		}
	}
	
	@Test
	public void testGetCellValueBoolean() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("CurrencyLookup");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BOOLEAN);
		SupportedCurrencyLookup.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
	
	@Test
	public void testGetCellValueNumeric() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("CurrencyLookup");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		SupportedCurrencyLookup.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
	
	@Test
	public void testGetCellData1Error() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("CurrencyLookup");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		SupportedCurrencyLookup.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
	
	@Test
	public void testGetCellData1Default() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("CurrencyLookup");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		SupportedCurrencyLookup.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
}
