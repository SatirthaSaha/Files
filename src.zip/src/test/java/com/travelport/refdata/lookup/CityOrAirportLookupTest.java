package com.travelport.refdata.lookup;

import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.CityOrAirport;


public class CityOrAirportLookupTest {

	// fetch airport code from city code 
	@Test
	public void testAirportCodeUsingCityCode(){		
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		List<CityOrAirport> airportsByCityCode = cityLookup.getAirportsByCityCode("AAB");
		Assert.assertEquals(1,airportsByCityCode.size());
	}
	
	@Test
	public void testMultiAirportCodeUsingCityCode(){		
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		List<CityOrAirport> airportsByCityCode = cityLookup.getAirportsByCityCode("TYO");
		Assert.assertEquals(4,airportsByCityCode.size());
		Assert.assertEquals("HND", airportsByCityCode.get(0).getAirportCode());
		Assert.assertEquals("LMJ", airportsByCityCode.get(1).getAirportCode());
		Assert.assertEquals("NRT", airportsByCityCode.get(2).getAirportCode());
		Assert.assertEquals("OKO", airportsByCityCode.get(3).getAirportCode());
	}

	// fetch city code from airport code
	@Test
	public void testCityCodeUsingAirportCode(){	
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		CityOrAirport cityCodeByAirport = cityLookup.getCityCodeByAirport("AAE");
		Assert.assertEquals("AAE",cityCodeByAirport.getCityCode());
	}	

	//  input airport code
	@Test
	public void testCheckAirportCode(){		
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		Assert.assertTrue(cityLookup.isAirportCode("AAE"));
	}

	//  input city code
	@Test
	public void testCheckCityCode(){		
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		Assert.assertTrue(cityLookup.isCityCode("TYO"));
	}
	
	@Test
	public void testCheckAirportCode_invalid(){		
		CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
		Assert.assertFalse(cityLookup.isAirportCode("TYO"));
	}
	
	//@Test
    public void testCheckAirportCode_invalid_CacheFrequency() throws InterruptedException{
        CityOrAirportLookup cityLookup = CityOrAirportLookup.getInstance();
        Assert.assertFalse(cityLookup.isAirportCode("TYO"));
    }
    
    @Test
	public void testGetCellData1WithDefault() throws IOException {
    	final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		CityOrAirportLookup.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1Blank() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BLANK);
		CityOrAirportLookup.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1Error() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		CityOrAirportLookup.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellValueBoolean() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BOOLEAN);
		CityOrAirportLookup.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellValueNumeric() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		CityOrAirportLookup.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellValueDefault() throws IOException {
    	final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BLANK);
		CityOrAirportLookup.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
}
