package com.travelport.refdata.lookup;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

public class ACOMigratedCarrierLookupTest {

	
	 @Test
	    public void testConstructor () throws Exception {
	    	Constructor constructor = ACOMigratedCarrierLookup.class.getDeclaredConstructor();
	    	constructor.setAccessible(true); 
	    	constructor.newInstance();
		    assertNotNull(constructor);
	    }
    @Test
    public void testACOMigratedCarrierLookup () {

        List<String> migratedCarrier = ACOMigratedCarrierLookup.getMigratedCarriers ();
        assertNotNull (migratedCarrier);

    }

    @Test
    public void testACOMigratedCarrierLookup_1 () throws IOException {
        List<String> migratedCarrier = ACOMigratedCarrierLookup.getMigratedCarriers ();
        assertNotNull (migratedCarrier);

    }

    @Test
    public void testACONonMigratedCarrierLookup () {

        List<String> nonMigratedCarrier = ACOMigratedCarrierLookup.getNonMigratedCarriers ();
        String nonMigratedCarrier_U2 = "U2";
        assertTrue (nonMigratedCarrier.contains (nonMigratedCarrier_U2));
    }
    
    @Test
	public void testGetCellValueForDefault() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue("ACOMigratedCarriersMapping");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		ACOMigratedCarrierLookup.getCellValue(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}

}
