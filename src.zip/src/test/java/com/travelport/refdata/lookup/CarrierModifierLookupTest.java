package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import com.travelport.refdata.models.ShopModifierData;

public class CarrierModifierLookupTest {

	@Test
	public void testGetShopModifierObjectFromCarrierCodeForLXCarrier() {
		String carrier = "LH";
		String nonStopDirect="T1";
		String stopDirect = "T1";
		String singleConnection = "T1";
		String doubleConnection = "T1";
		String noAdvancePurchase = "T2";
		String noMinimumStay = "T2";
		String noMaximumStay = "T2";
		String noPenalty = "T2";
		String equivalentCurrency = "T1";
		String publicFares = "T1";
		String privateFares = "T1";
		String publicAndPrivateFares="T1" ;
		String netFares = "T2";
		String cabinPreferencePermitted = "T1";
		String cabinPreferencePreferred = "T4";
		String airlinePreferencePermitted = "T1";
		String airlinePreferenceProhibited = "T5";
		String airlinePreferencePreferred = "T5";
		CarrierModifierLookup carrierModifierLookup = CarrierModifierLookup.getInstance();
		ShopModifierData shopModifierData = carrierModifierLookup.getShopModifierObjectFromCarrierCode(carrier);
		assertEquals("Test Non Stop Direct modifier ", nonStopDirect, shopModifierData.getNonStopDirect());
		assertEquals("Test Stop Direct modifier ", stopDirect, shopModifierData.getStopDirect());
		assertEquals("Test single Connection modifier", singleConnection, shopModifierData.getSingleConnection());
		assertEquals("Test doubleConnection modifier", doubleConnection, shopModifierData.getDoubleConnection());
		assertEquals("Test noAdvancePurchase modifier", noAdvancePurchase, shopModifierData.getNoAdvancePurchase());
		assertEquals("Test noMinimumStay modifier", noMinimumStay, shopModifierData.getNoMinimumStay());
		assertEquals("Test noMaximumStay modifier", noMaximumStay, shopModifierData.getNoMaximumStay());
		assertEquals("Test noPenalty modifier", noPenalty, shopModifierData.getNoPenalty());
		assertEquals("Test equivalentCurrency modifier", equivalentCurrency, shopModifierData.getEquivalentCurrency());
		assertEquals("Test publicFares modifier", publicFares, shopModifierData.getPublicFares());
		assertEquals("Test privateFares modifier", privateFares, shopModifierData.getPrivateFares());
		assertEquals("Test netFares modifier", netFares, shopModifierData.getNetFares());
		assertEquals("Test cabinPreferencePreferred modifier", cabinPreferencePermitted,
				shopModifierData.getCabinPreferencePermitted());
		assertEquals("Test cabinPreferencePreferred modifier", cabinPreferencePreferred,
				shopModifierData.getCabinPreferencePreferred());
		assertEquals("Test airlinePreferencePermitted modifier", airlinePreferencePermitted,
				shopModifierData.getAirlinePreferencePermitted());
		assertEquals("Test airlinePreferenceProhibited modifier", airlinePreferenceProhibited,
				shopModifierData.getAirlinePreferenceProhibited());
		assertEquals("Test airlinePreferencePreferred modifier", airlinePreferencePreferred,
				shopModifierData.getAirlinePreferencePreferred());
		assertEquals("Test publicAndPrivateFares modifier", publicAndPrivateFares,
				shopModifierData.getPublicAndPrivateFares());
	}

	@Test
	public void testGetShopModifierObjectFromCarrierCodeForSNCarrier() {
		String carrier = "SN";
		String ptcType = "T3";
		String excludeGround = "T2";
		String prohibitChangeOfAirport = "T3";
		String maxConnectionDuration = "T3";
		String maxOvernightDuration = "T3";
		String excludeInterlineConnections = "T3";
		String accountCode = "T5";
		CarrierModifierLookup carrierModifierLookup = CarrierModifierLookup.getInstance();
		ShopModifierData shopModifierData = carrierModifierLookup.getShopModifierObjectFromCarrierCode(carrier);
		assertEquals("Test ptcType modifier ", ptcType, shopModifierData.getPtcType());
		assertEquals("Test excludeGround modifier ", excludeGround, shopModifierData.getExcludeGround());
		assertEquals("Test prohibitChangeOfAirport modifier ", prohibitChangeOfAirport,
				shopModifierData.getProhibitChangeOfAirport());
		assertEquals("Test maxConnectionDuration modifier ", maxConnectionDuration,
				shopModifierData.getMaxConnectionDuration());
		assertEquals("Test maxOvernightDuration modifier ", maxOvernightDuration,
				shopModifierData.getMaxOvernightDuration());
		assertEquals("Test excludeInterlineConnections modifier ", excludeInterlineConnections,
				shopModifierData.getExcludeInterlineConnections());
		assertEquals("Test accountCode modifier ", accountCode, shopModifierData.getAccountCode());
	}

	@Test
	public void testGetShopModifierObjectFromCarrierCodeInvalidCarrier() {
		String carrier = "ABCD";
		CarrierModifierLookup carrierModifierLookup = CarrierModifierLookup.getInstance();
		ShopModifierData shopModifierData = carrierModifierLookup.getShopModifierObjectFromCarrierCode(carrier);
		assertNull(shopModifierData);
	}
	


}
