package com.travelport.refdata.lookup;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.CarrierCurrency;

public class CarrierCurrencyLookupTest {

	@Test
	public void testcarrierCurrency_AX_AK() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("AUD", "INR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("AK")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_AX_D7() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("HKD","SGD","THB","USD", "INR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("D7")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_AX_FD() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("AUD", "INR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("FD")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_AX_QZ() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("HKD", "INR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("QZ")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_AX_I5() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("HKD", "AUD","SGD","MYR","THB","USD");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("I5")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
		
	@Test
	public void testcarrierCurrency_AX_XJ() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("HKD", "AUD", "SGD", "MYR", "USD", "INR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("AX");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if (carrierCurrency.getCarrier().equalsIgnoreCase("XJ")) {
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_AK() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("IDR", "THB");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("AK")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_D7() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("IDR","THB");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("D7")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_FD() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("IDR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("FD")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_PQ() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("THB", "IDR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("PQ")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_I5() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("JPY", "IDR","THB");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if(carrierCurrency.getCarrier().equalsIgnoreCase("I5")){
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));				
			}
		}
	}
		
	@Test
	public void testcarrierCurrency_JC_Z2() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("IDR","THB");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if (carrierCurrency.getCarrier().equalsIgnoreCase("Z2")) {
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_XJ() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("IDR");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if (carrierCurrency.getCarrier().equalsIgnoreCase("XJ")) {
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
			}
		}
	}
	
	@Test
	public void testcarrierCurrency_JC_XT() {

		CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
		List<String> expectedCurrencyList = Arrays.asList("THB");
		List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
		for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
			if (carrierCurrency.getCarrier().equalsIgnoreCase("XT")) {
				assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
			}
		}
	}
	
	//@Test
    public void testcarrierCurrency_JC_XT_Cache() throws InterruptedException {
	    CarrierCurrencyLookup carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
        List<String> expectedCurrencyList = Arrays.asList("IDR");
        List<CarrierCurrency> carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
        for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
            if (carrierCurrency.getCarrier().equalsIgnoreCase("XJ")) {
                assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
            }
        }
        carrierCurrencyLookup = CarrierCurrencyLookup.getInstance();
        expectedCurrencyList = Arrays.asList("THB");
        carrierCurrencyPerCardType = carrierCurrencyLookup.getCarrierCurrencyPerCardType("JC");
        for (CarrierCurrency carrierCurrency : carrierCurrencyPerCardType) {
            if (carrierCurrency.getCarrier().equalsIgnoreCase("XT")) {
                assertTrue(expectedCurrencyList.contains(carrierCurrency.getCurrency()));
            }
        }
    }
    
    @Test
	public void testGetCellDataForBoolean() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_BOOLEAN);
		CarrierCurrencyLookup.getCellValue(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
	
    @Test
	public void testGetCellDataForNumeric() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		CarrierCurrencyLookup.getCellValue(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1ForBlankCell() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_BLANK);
		CarrierCurrencyLookup.getCellData1(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1ForErrorCell() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		CarrierCurrencyLookup.getCellData1(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1ForDefault() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_FORMULA);
		CarrierCurrencyLookup.getCellData1(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellDataForBlankCell() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		
		final byte[] fileBytes = connector.getValue(CurrencyLookup.CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
		workbook = new XSSFWorkbook(excelFileToRead);
		XSSFSheet sheet = workbook.getSheetAt(0);
		   
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		
		row.getCell(0).setCellType(Cell.CELL_TYPE_BLANK);
		CarrierCurrencyLookup.getCellData(row.getCell(0));
		
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testPopulateCarrierCurrencyMap(){
    	CarrierCurrency carrierCurrency = new CarrierCurrency();
    	carrierCurrency.setCardType("AA");
    	List<CarrierCurrency> carrierCurrencyAXList = new ArrayList<>();
        List<CarrierCurrency> carrierCurrencyJCList = new ArrayList<>();
        Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp = new HashMap<>();
    	CarrierCurrencyLookup.populateCarrierCurrencyMap(carrierCurrency, carrierCurrencyAXList, carrierCurrencyJCList, carrierCurrencyMapPerCardTypeTemp);
    	assertNotNull(carrierCurrency);
    }
	
    
}
