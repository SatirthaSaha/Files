package com.travelport.refdata.lookup;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.Test;
import org.junit.Assert;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

public class ReferenceDataRetrieveVerificationTest {
    private static final String MIGRATED_CARRIER_MAP_KEY = "MigratedCarriersMapping";
    private static final String MIGRATED_CARRIER_MAP_VERSION_KEY = "MigratedCarriersMap_Version";

    // For AK Cabin Class
    private static final String AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY = "AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY";
    private static final String AIR_ASIA_CABIN_CLASS_DATA_KEY = "AIR_ASIA_CABIN_CLASS_DATA_KEY";

    // For AK SSR
    private static final String AIR_ASIA_SSR_DATA_KEY = "AIR_ASIA_SSR_DATA_KEY";
    private static final String AIR_ASIA_SSR_DATA_VERSION_KEY = "AIR_ASIA_SSR_DATA_VERSION_KEY";

    // For AK Product Class Mapping
    private static final String AIR_ASIA_PRODUCT_CLASS_DATA_KEY = "AIR_ASIA_PRODUCT_CLASS_DATA_KEY";
    private static final String AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY = "AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY";

    // For AK APIS data
    private static final String AIR_ASIA_APIS_DATA_KEY = "AIR_ASIA_APIS_DATA_KEY";
    private static final String AIR_ASIA_APIS_DATA_VERSION_KEY = "AIR_ASIA_APIS_DATA_VERSION_KEY";

    // for 6E Translation Reference Data
    private static final String INDIGO_TRANSLATION_DATA_KEY = "INDIGO_TRANSLATION_DATA_KEY";
    private static final String INDIGO_TRANSLATION_DATA_VERSION_KEY = "INDIGO_TRANSLATION_DATA_VERSION_KEY";

    // for 6E Air Optional Service And Fees
    private static final String INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";

    // for 6E Product Class Mapping Data
    private static final String INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY = "INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY";
    private static final String INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY = "INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY";

    // for 6E Cabin Class Mapping Data
    private static final String INDIGO_CABIN_CLASS_DATA_KEY = "INDIGO_CABIN_CLASS_DATA_KEY";
    private static final String INDIGO_CABIN_CLASS_DATA_VERSION_KEY = "INDIGO_CABIN_CLASS_DATA_VERSION_KEY";

    // for 6E Fare Rules Mapping Data
    private static final String INDIGO_FARERULE_DATA_KEY = "INDIGO_FARERULE_DATA_KEY";
    private static final String INDIGO_FARERULE_DATA_VERSION_KEY = "INDIGO_FARERULE_DATA_VERSION_KEY";

    // for TO Translation Reference Data
    private static final String TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY = "TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY";

    // for TO Air Optional Service And Fees Reference Data
    private static final String TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";

    // for TO Product Class Mapping Data
    private static final String TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY = "TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY";
    private static final String TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY = "TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY";

    // for HV Translation Reference Data
    private static final String TRANSAVIA_TRANSLATION_DATA_KEY = "TRANSAVIA_TRANSLATION_DATA_KEY";
    private static final String TRANSAVIA_TRANSLATION_DATA_VERSION_KEY = "TRANSAVIA_TRANSLATION_DATA_VERSION_KEY";

    // for HV Air Optional Service And Fees Reference Data
    private static final String TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";

    // for HV Product Class Mapping Data
    private static final String TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_KEY = "TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_KEY";
    private static final String TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY = "TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY";

    // for Jambojet Translation Reference Data
    private static final String JAMBOJET_TRANSLATION_DATA_KEY = "JAMBOJET_TRANSLATION_DATA_KEY";
    private static final String JAMBOJET_TRANSLATION_DATA_VERSION_KEY = "JAMBOJET_TRANSLATION_DATA_VERSION_KEY";

    // for Jambojet Air Optional Service And Fees Reference Data
    private static final String JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY = "JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY";
    private static final String JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY = "JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY";

    // for Jambojet Seat Availability Rules Mapping Data
    private static final String JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY = "JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY";
    private static final String JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY = "JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY";

    // for Jambojet Seat Characteristics Mapping Data
    private static final String JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY = "JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY";
    private static final String JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY = "JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY";

    // for Delta Cabin Class Mapping Data
    private static final String DELTA_CABIN_CLASS_DATA_KEY = "DELTA_CABIN_CLASS_DATA_KEY";
    private static final String DELTA_CABIN_CLASS_DATA_VERSION_KEY = "DELTA_CABIN_CLASS_DATA_VERSION_KEY";

    // for Delta Optional Services Data
    private static final String DELTA_OPTIONAL_SERVICES_DATA_KEY = "DELTA_OPTIONAL_SERVICES_DATA_KEY";
    private static final String DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY = "DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY";

    // for United Air SSR Mapping Data
    private static final String UNITED_AIR_SSR_DATA_KEY = "UNITED_AIR_SSR_DATA_KEY";
    private static final String UNITED_AIR_SSR_DATA_FILE = "carriers/united/UnitedAir_SSR.xlsx";
    private static final String UNITED_AIR_SSR_DATA_VERSION_KEY = "UNITED_AIR_SSR_DATA_VERSION_KEY";
    private static final Integer UNITED_AIR_SSR_DATA_VERSION = 1;

    // for Qantas Cabin Class Mapping Data
    private static final String QANTAS_CABIN_CLASS_DATA_KEY = "QANTAS_CABIN_CLASS_DATA_KEY";
    private static final String QANTAS_CABIN_CLASS_DATA_VERSION_KEY = "QANTAS_CABIN_CLASS_DATA_VERSION_KEY";

    @Test
    public void testMigratedCarrierReferenceDataRetrieve () {
        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
        final Integer cachedVersion = versionConnector.getValue (MIGRATED_CARRIER_MAP_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Migrated Carrier Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
        final byte[] fileBytes = connector.getValue (MIGRATED_CARRIER_MAP_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Migrated Carrier Reference Stored In: Migrated_NonMigrated_Carrier_Read.xlsx");

        saveInFile ("Migrated_NonMigrated_Carrier_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    // ak test cases
    @Test
    public void testReadAKCabinClassMapping () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (AIR_ASIA_CABIN_CLASS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia Cabin Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (AIR_ASIA_CABIN_CLASS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia Cabin Class Data Stored In: AirAsia_CabinClassMapping_Read.xlsx");

        saveInFile ("AirAsia_CabinClassMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadAKSSR () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (AIR_ASIA_SSR_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia SSR Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (AIR_ASIA_SSR_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia SSR Data Stored In: AirAsia_SSR_Read.xlsx");

        saveInFile ("AirAsia_SSR_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadAKProductClassMapping () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (AIR_ASIA_PRODUCT_CLASS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia Product Class Mapping Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (AIR_ASIA_PRODUCT_CLASS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia Product Class Mapping Data Stored In: AirAsia_ProductClassMapping_Read.xlsx");

        saveInFile ("AirAsia_ProductClassMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadAKAPISData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (AIR_ASIA_APIS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia APIS data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (AIR_ASIA_APIS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Air Asia APIS Data Stored In: AirAsia_APIS_Read.xml");

        saveInFile ("AirAsia_APIS_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    // 6E test cases
    @Test
    public void testRead6ETranslationReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (INDIGO_TRANSLATION_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Trnaslation Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
        final byte[] fileBytes = connector.getValue (INDIGO_TRANSLATION_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Trnaslation Reference Data Stored In : 6E_TranslationData_Read.xml");

        saveInFile ("6E_TranslationData_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testRead6EAirOptionalServieAndFeesReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Air Optional Service And Fees Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (INDIGO_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Air Optional Service And Fees Data Stored In : IndigoAirOptionalServiceAndFees_Read.xlsx");

        saveInFile ("IndigoAirOptionalServiceAndFees_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testRead6EProductClassMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (INDIGO_PRODUCT_CLASS_MAPPING_DATA_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Product Class Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (INDIGO_PRODUCT_CLASS_MAPPING_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Product Class Mapping Data Stored In : Indigo_ProductClassMapping_Read.xlsx");

        saveInFile ("Indigo_ProductClassMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testRead6ECabinClassMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (INDIGO_CABIN_CLASS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Cabin Class Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (INDIGO_CABIN_CLASS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Cabin Class Mapping Data Stored In : Indigo_CabinClassMapping_Read.xlsx");

        saveInFile ("Indigo_CabinClassMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testRead6EFareRulesMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (INDIGO_FARERULE_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Fare Rule Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (INDIGO_FARERULE_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Indigo Fare Rule Mapping Data Stored In : IndigoFareRules_Read.xlsx");

        saveInFile ("IndigoFareRules_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    // HV test cases
    @Test
    public void testReadHVTranslationReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_TRANSLATION_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Translation Reference Data Product Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_TRANSLATION_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Translation Reference Data Product Class Data Stored In : HV_TranslationData_Read.xml");

        saveInFile ("HV_TranslationData_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadHVAirOptionalServieAndFeesReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Air Optional Service And Fees Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Air Optional Service And Fees Reference Data Stored In : TransaviaAirOptionalServiceAndFees_Read.xlsx");

        saveInFile ("TransaviaAirOptionalServiceAndFees_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadHVProductClassMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Product Class Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_PRODUCT_CLASS_MAPPING_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia Product Class Mapping Data Stored In : Transavia_ProductClassMapping_Read.xml");

        saveInFile ("Transavia_ProductClassMapping_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    // TO test cases
    @Test
    public void testReadTOTranslationReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_FRANCE_TRANSLATION_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Translation Reference Data Product Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_FRANCE_TRANSLATION_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Translation Reference Data Product Class Data Stored In : TO_TranslationData_Read.xml");

        saveInFile ("TO_TranslationData_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadTOAirOptionalServieAndFeesReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Air Optional Service And Fees Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_FRANCE_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Air Optional Service And Fees Reference Data Stored In : TransaviaAirOptionalServiceAndFees_Read.xlsx");

        saveInFile ("TransaviaAirOptionalServiceAndFees_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadTOProductClassMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Product Class Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (TRANSAVIA_FRANCE_PRODUCT_CLASS_MAPPING_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Transavia France Product Class Mapping Data Stored In : Transavia_ProductClassMapping_Read.xml");

        saveInFile ("Transavia_ProductClassMapping_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadJambojetTranslationReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (JAMBOJET_TRANSLATION_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Translation Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (JAMBOJET_TRANSLATION_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Translation Reference Data Stored In : JM_TranslationData.xml");

        saveInFile ("JM_TranslationData_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadJambojetAirOptionalServieAndFeesReferenceData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Air Optional Service And Fees Reference Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (JAMBOJET_AIR_OPTIONALSERVICE_AND_FEES_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Air Optional Service And Fees Reference Data Stored In : JamboJetAirOptionalServiceAndFees.xlsx");

        saveInFile ("JamboJetAirOptionalServiceAndFees_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadJambojetSeatAvailabilityRulesMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Seat Availability Rules Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (JAMBOJET_SEAT_AVAILABILITY_RULES_MAPPING_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Seat Availability Rules Mapping Data Stored In : JambojetSeatAvailabilityRulesMapping.xlsx");

        saveInFile ("JambojetSeatAvailabilityRulesMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadJambojetSeatCharacteristicsMappingData () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Seat Characteristics Mapping Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (JAMBOJET_SEAT_CHARACTERISTICS_MAPPING_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Jambojet Seat Characteristics Mapping Data Stored In : JambojetSeatCharacteristicsMapping.xlsx");

        saveInFile ("JambojetSeatCharacteristicsMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadDLCabinClassMapping () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (DELTA_CABIN_CLASS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Delta Cabin Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (DELTA_CABIN_CLASS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Delta Cabin Class Data Stored In: Delta_CabinClassMapping_Read.xml");

        saveInFile ("Delta_CabinClassMapping_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadDLOptionalServicesMapping () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (DELTA_OPTIONAL_SERVICES_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Delta Optional Services Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (DELTA_OPTIONAL_SERVICES_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Delta Optional Services Data Stored In: DeltaOptionalServiceAndFees_Read.xml");

        saveInFile ("DeltaOptionalServiceAndFees_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    @Test
    public void testReadUnitedAirSSR () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (UNITED_AIR_SSR_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> United Air Cabin Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (UNITED_AIR_SSR_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> United Air Data Stored In: UnitedAir_SSR.xlsx");

        saveInFile ("UnitedAir_SSR_Read.xml", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    // QF test cases
    @Test
    public void testReadQFCabinClassMapping () {

        final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();

        final Integer cachedVersion = versionConnector.getValue (QANTAS_CABIN_CLASS_DATA_VERSION_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Qantas Cabin Class Data Version: " + cachedVersion);

        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();

        final byte[] fileBytes = connector.getValue (QANTAS_CABIN_CLASS_DATA_KEY);

        System.out.println (">>>>>>>>>>>>>>>>>>> Qantas Cabin Class Data Stored In: Qantas_CabinClassMapping_Read.xlsx");

        saveInFile ("Qantas_CabinClassMapping_Read.xlsx", fileBytes);
        Assert.assertNotNull(fileBytes);
    }

    private void saveInFile (String fileName, byte[] bytes) {
        File folder = new File ("Read");
        folder.mkdirs ();
        File targetFile = new File ("Read/" + fileName);
        FileOutputStream outStream = null;

        try {
            outStream = new FileOutputStream (targetFile);

            outStream.write (bytes);
        } catch (IOException ex) {
            ex.printStackTrace ();
        } finally {
            if (outStream != null) {
                try {
                    outStream.flush ();

                    outStream.close ();
                } catch (IOException e) {
                    e.printStackTrace ();
                }
            }
        }
    }
}
