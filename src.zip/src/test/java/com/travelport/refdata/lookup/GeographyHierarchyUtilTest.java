package com.travelport.refdata.lookup;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Test;

import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.AirportGeoHierarchy;
import com.travelport.refdata.models.CityOrAirport;
import com.travelport.refdata.models.Currency;


public class GeographyHierarchyUtilTest {

	// fetch airport code from city code 
	@Test
	public void testAirportCodeUsingCityCode(){		
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		List<String> airportsByCityCode = cityLookup.getAirportsByCityCode("AAB");
		Assert.assertEquals(1,airportsByCityCode.size());
	}
	
	@Test
	public void testGetAirportsByCityCodeNull() {
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		List<String> airportsByCityCode = cityLookup.getAirportsByCityCode(null);
		Assert.assertEquals(0,airportsByCityCode.size());
	}
	
	@Test
	public void testMultiAirportCodeUsingCityCode(){		
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		List<String> airportsByCityCode = cityLookup.getAirportsByCityCode("TYO");
		Assert.assertEquals(4,airportsByCityCode.size());
		Assert.assertEquals("HND", airportsByCityCode.get(0));
		Assert.assertEquals("LMJ", airportsByCityCode.get(1));
		Assert.assertEquals("NRT", airportsByCityCode.get(2));
		Assert.assertEquals("OKO", airportsByCityCode.get(3));
	}

	// fetch city code from airport code
	@Test
	public void testCityCodeUsingAirportCode(){	
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		AirportGeoHierarchy cityCodeByAirport = cityLookup.getCityCodeByAirport("AAE");
		Assert.assertEquals("AAE",cityCodeByAirport.getCityCode());
	}
	
	//  input airport code
	@Test
	public void testCheckAirportCode(){		
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		Assert.assertTrue(cityLookup.isAirportCode("AAE"));
	}

	//  input city code
	@Test
	public void testCheckCityCode(){		
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		Assert.assertTrue(cityLookup.isCityCode("TYO"));
	}
	
	@Test
	public void testCheckAirportCodeInvalid(){		
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		Assert.assertFalse(cityLookup.isAirportCode("TYO"));
	}
	
	//@Test
    public void testCheckAirportCode_invalid_CacheFrequency() throws InterruptedException{
        GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
        Assert.assertFalse(cityLookup.isAirportCode("TYO"));
    }
    
    @Test
    public void testGetGeoDataByAirport(){     
        GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
        Assert.assertNotNull(cityLookup.getGeoDataByAirport("BBF"));
    }
    
    /*@Test
	public void testCityCodeUsingAirportCodeNull(){	
		try {
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		GeographyHierarchyUtil.airportGeoHierarchyMap = null;
		AirportGeoHierarchy cityCodeByAirport = cityLookup.getCityCodeByAirport(null);
		} catch(Exception e) {
			assertNull(e);
		}
	}*/
    
    @Test
	public void testIsCityCode() {
		GeographyHierarchyUtil cityLookup = GeographyHierarchyUtil.getInstance();
		GeographyHierarchyUtil.cityAirportMap = null;
		cityLookup.isCityCode("TYO");
		Assert.assertFalse(cityLookup.isCityCode("TYO"));
	}
    
    @Test
	public void testProcessCellDataAirportCodeEmpty() throws IOException {
    	Map<String, List<String>> cityAirportMapTemp = new HashMap<>();
    	Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp = new HashMap<>();
    	final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellValue("");
    	GeographyHierarchyUtil.processCellData(cityAirportMapTemp, airportGeoHierarchyMapTemp, row);
    	assertNotNull(row.getCell(0));
    }
    
    @Test
	public void testProcessCellDataCityCodeEmpty() throws IOException {
    	Map<String, List<String>> cityAirportMapTemp = new HashMap<>();
    	Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp = new HashMap<>();
    	final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(1).setCellValue("");
    	GeographyHierarchyUtil.processCellData(cityAirportMapTemp, airportGeoHierarchyMapTemp, row);
    	assertNotNull(row.getCell(1));
    }
    
    @Test
	public void testGetCellValueBoolean() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BOOLEAN);
		GeographyHierarchyUtil.getCellValue(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
    public void testAirportGeo() {
    	AirportGeoHierarchy airportGeoHierarchy = new AirportGeoHierarchy();
    	airportGeoHierarchy.getStateCode();
    	airportGeoHierarchy.getZoneId();
    	airportGeoHierarchy.getCountryCode();
    	airportGeoHierarchy.getAreaCode();
    	CityOrAirport cityOrAirport = new CityOrAirport();
    	cityOrAirport.getCountryCode();
    	Currency currency = new Currency();
    	currency.getAirportName();
    	assertNotNull(airportGeoHierarchy);
    }
    
    @Test
	public void testGetCellDataDefault() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_NUMERIC);
		GeographyHierarchyUtil.getCellData(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1Blank() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_BLANK);
		GeographyHierarchyUtil.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
    
    @Test
	public void testGetCellData1Error() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue("Airport_Geo_Hierarchy");
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		XSSFWorkbook workbook = null;
        workbook = new XSSFWorkbook (excelFileToRead);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
		Row row = rowIterator.next();
		row.getCell(0).setCellType(Cell.CELL_TYPE_ERROR);
		GeographyHierarchyUtil.getCellData1(row.getCell(0));
		assertNotNull(row.getCell(0));
	}
}
