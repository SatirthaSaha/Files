package com.travelport.refdata.lookup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
@Ignore
public class NDCCabinTypeLookupTest {
	
	NDCCabinTypeLookup ndcCabinTypeLookup = NDCCabinTypeLookup.getInstance();
	@Test
	public void testCarrierLookup_QFPremiumFirst(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","PremiumFirst");
		assertEquals("R",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_QFFirst(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","First");
		assertEquals("F",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_QFPremiumBusiness(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","PremiumBusiness");
		assertEquals("J",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_QFBusiness(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","Business");
		assertEquals("C",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_QFPremiumEconomy(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","PremiumEconomy");
		assertEquals("W",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_QFEconomy(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("QF","Economy");
		assertEquals("Y",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHPremiumFirst(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","PremiumFirst");
		assertEquals("R",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHFirst(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","First");
		assertEquals("F",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHPremiumBusiness(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","PremiumBusiness");
		assertEquals("J",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHBusiness(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","Business");
		assertEquals("C",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHPremiumEconomy(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","PremiumEconomy");
		assertEquals("W",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_LHEconomy(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("LH","Economy");
		assertEquals("Y",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_AAFirst(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("AA","First");
		assertEquals("F",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_AABusiness(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("AA","Business");
		assertEquals("C",cabinCode);		
	}
	
	@Test
	public void testCarrierLookup_AAPremiumEconomy(){
		String cabinCode = ndcCabinTypeLookup.getCabinCodeFromCabinType("AA","PremiumEconomy");
		assertEquals("W",cabinCode);		
	}
	
	@Test
    public void testGetAllCabinCodeFromCarrierCode(){
        List<String> cabinCodeList = ndcCabinTypeLookup.getAllCabinCodeFromCarrierCode ("QF");
        assertEquals(6,cabinCodeList.size ());
        assertEquals("R",cabinCodeList.get (0));
        assertEquals("Y",cabinCodeList.get (1));
        assertEquals("W",cabinCodeList.get (2));
        assertEquals("F",cabinCodeList.get (3));
        assertEquals("J",cabinCodeList.get (4));
        assertEquals("C",cabinCodeList.get (5));
    }
}
