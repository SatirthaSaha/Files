/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.apis;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="APISInfo")
public class APISInfo implements Serializable {

	private String source;
	private String fixedAPISInfo;
	private transient DefaultRespAPISDocTypes defaultRespAPISDocTypes;
	
	protected APISInfo(){
		/* Constructor to clear 
		sonar issues*/
	}
	
	/**
	 * getSource
	 * @param
	 * @return
	 */
	@XmlAttribute
	public String getSource() {
		return source;
	}

	/**
	 * setSource
	 * @param source
	 * @return
	 */
	public void setSource(String source) {
		this.source = source;
	}

	@XmlElement(name="FixedAPISInfo")
	public String getFixedAPISInfo() {
		return fixedAPISInfo;
	}

	/**setFixedAPISInfo
	 * @param fixedAPISInfo
	 * @return
	 */
	public void setFixedAPISInfo(String fixedAPISInfo) {
		this.fixedAPISInfo = fixedAPISInfo;
	}

	@XmlElement(name="DefaultRespAPIS_DocTypes")
	public DefaultRespAPISDocTypes getDefaultRespAPISDocTypes() {
		return defaultRespAPISDocTypes;
	}

	/**
	 * setDefaultRespAPISDocTypes
	 * @param defaultRespAPISDocTypes
	 * @return
	 */
	public void setDefaultRespAPISDocTypes(DefaultRespAPISDocTypes defaultRespAPISDocTypes) {
		this.defaultRespAPISDocTypes = defaultRespAPISDocTypes;
	}
	
	/**
	 * @author ankit.kumar
	 *
	 */
	public static class DefaultRespAPISDocTypes {

		private String nationalityRequired;
	    private String genderDOBReq;
	    private String otherDocTypes;
	    
	    protected DefaultRespAPISDocTypes(){
	    	/*Constrctor to clear 
	    	 * sonar issues*/
	    }
	    
	    @XmlAttribute(name="NationalityRequired")
		public String getNationalityRequired() {
			return nationalityRequired;
		}
		/**
		 * setNationalityRequired
		 * @param nationalityRequired
		 * @return
		 */
		public void setNationalityRequired(String nationalityRequired) {
			this.nationalityRequired = nationalityRequired;
		}
		
		@XmlAttribute(name="GenderDOB_Req")
		public String getGenderDOBReq() {
			return genderDOBReq;
		}
		/**
		 * setGenderDOBReq
		 * @param genderDOBReq
		 * @return
		 */
		public void setGenderDOBReq(String genderDOBReq) {
			this.genderDOBReq = genderDOBReq;
		}
		
		@XmlAttribute(name="OtherDocTypes")
		public String getOtherDocTypes() {
			return otherDocTypes;
		}
		/**
		 * setOtherDocTypes
		 * @param otherDocTypes
		 * @return
		 */
		public void setOtherDocTypes(String otherDocTypes) {
			this.otherDocTypes = otherDocTypes;
		}
	    
	    
	}

}
