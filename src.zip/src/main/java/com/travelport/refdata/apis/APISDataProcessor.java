/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.apis;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.model.catalog.Offer;
import com.travelport.model.catalog.OfferID;
import com.travelport.model.catalog.air.Flight;
import com.travelport.model.catalog.air.FlightSegment;
import com.travelport.model.catalog.air.ProductAir;
import com.travelport.model.catalog.air.TermsAndConditionsFullAir;
import com.travelport.model.common.TextBlock;
import com.travelport.model.common.TextFormatted;
import com.travelport.model.reservation.Reservation;
import com.travelport.refdata.lookup.CarrierLookup;
import com.tvp.model.catalog.air.FlightStatus;

public class APISDataProcessor {
	
	private static final String AIR_ASIA_APIS_DATA_VERSION_KEY = "AIR_ASIA_APIS_DATA_VERSION_KEY";
    private static final String AIR_ASIA_APIS_DATA_KEY = "AIR_ASIA_APIS_DATA_KEY";	
    private Integer cachedAirAsiaAPISVersion = 0;
    private Map<String, APISInfo> apisMap = new HashMap<> ();
    private static APISDataProcessor apisDataProcessor ;
    
    private static volatile JAXBContext jaxbContext ;
    private static volatile Unmarshaller jaxbUnmarshaller ;
    
    private static long lastUpdateTimeStamp ;  
    private static final long SIXTY_THOUSAND = 60000;
    private static long dEFAULT_CACHE_UPDATE_FREQUENCY = SIXTY_THOUSAND; // Update frequency can be modulated.
    
    private static final String APIS_SOURCE_TYPE_CONFIG_FIXED = "ConfigFixed";
    
    private static final String APIS_INFO = "APIS_Info";
    private static final String GENDERDOB_REQ = "GenderDOB_Req";
    private static final String NATIONALITY_REQUIRED = "NationalityRequired";
    private static final String OTHER_DOC_TYPES = "OtherDocTypes";
    
    private static final ACSLogger LOGGER = ACSLogger.getLogger(APISDataProcessor.class);
    
    /**
     * 
     * @return
     */
    public static synchronized APISDataProcessor getInstance() {

        if (apisDataProcessor == null) {
        	apisDataProcessor = new APISDataProcessor();
        	
                try {
                    final String cacheUpdateFrequencyStr = System.getenv ("RedisCacheUpdateFrequency");

                    LOGGER.debug ("RedisCacheUpdateFrequency value is : " + cacheUpdateFrequencyStr);

                    long cacheUpdateFrequency = Long.parseLong (cacheUpdateFrequencyStr);

                    if (cacheUpdateFrequency > 0) {
                        dEFAULT_CACHE_UPDATE_FREQUENCY = cacheUpdateFrequency;
                    }
                } catch (NumberFormatException nfe) {
                    LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
                }

                LOGGER.debug ("cacheUpdateFrequency value is : " + dEFAULT_CACHE_UPDATE_FREQUENCY);
        }
        return apisDataProcessor;

    }
	
    /**
     * 
     * @param reservation
     */
    public void processAPIS(Reservation reservation) {
    	if(isActiveOrder(reservation)) {
    		String carrierCode = getPrimaryCarrierCodeForOrder(reservation);
    		if(!StringUtils.isBlank(carrierCode)) {
    			checkForLatestAPISInfoForCarrier(carrierCode);
    			APISInfo apisInfo = apisMap.get(carrierCode.trim().toUpperCase(Locale.ENGLISH));

    			if(apisInfo != null) {
    				processAPISInfo(reservation, carrierCode, apisInfo);
    			} else {
    				LOGGER.info("No APIS info found in redis for carrier : " + carrierCode);
    			}
    		}
    	}
    }

    
    /**
     * 
     * @param reservation
     * @param carrierCode
     * @param apisInfo
     */
	protected void processAPISInfo(Reservation reservation, String carrierCode, APISInfo apisInfo) {
		if(StringUtils.equals(APIS_SOURCE_TYPE_CONFIG_FIXED, apisInfo.getSource())) {
			applyAPISInOffer(reservation.getOffer(), apisInfo);
		} else {
			//do nothing for now. Add related code when other source type will be needed
			//for different carriers
			LOGGER.info("Source type " + apisInfo.getSource() + " is not supported for carrier : " + carrierCode);
		}
	}
	
	/**
	 * 
	 * @param offerIDList
	 * @param apisInfo
	 */
	protected void applyAPISInOffer(List<OfferID> offerIDList, APISInfo apisInfo) {
		if (!CollectionUtils.isEmpty(offerIDList)) {
			for (OfferID offerID : offerIDList) {
				processOfferID(apisInfo, offerID);
			}
		}
	}

	
	/**
	 * 
	 * @param apisInfo
	 * @param offerID
	 */
	private static void processOfferID(APISInfo apisInfo, OfferID offerID) {
		if (offerID instanceof Offer) {
			Offer offer = (Offer) offerID;
			if (!CollectionUtils.isEmpty(offer.getProduct()) && offer.getProduct().get(0) instanceof ProductAir) {
				ProductAir productAir = (ProductAir) offer.getProduct().get(0);
				String productIdentifier = productAir.getIdentifier().getValue();
				createTermsAndConditionsAirDetail(offer, productIdentifier, apisInfo);
			}

		}
	}
	
	/**
	 * 
	 * @param reservation
	 * @return
	 */
	protected boolean isActiveOrder(Reservation reservation) {
		if (reservation != null && !CollectionUtils.isEmpty(reservation.getOffer()) && reservation.getOffer().get(0) instanceof Offer) {
			final Offer firstOffer = (Offer) reservation.getOffer().get(0);
			if (!CollectionUtils.isEmpty(firstOffer.getProduct()) && firstOffer.getProduct().get(0) != null) {
				final ProductAir firstroductTransport = (ProductAir) firstOffer.getProduct().get(0);
				if (!CollectionUtils.isEmpty(firstroductTransport.getFlightSegment())
						&& firstroductTransport.getFlightSegment().get(0) != null) {
					final FlightSegment firstFlightSegment = firstroductTransport.getFlightSegment().get(0);
 					return checkFlightStatus(firstFlightSegment);
				}
			}
		}
		return false;
	}

	
	/**
	 * 
	 * @param firstFlightSegment
	 * @return
	 */
	protected boolean checkFlightStatus(final FlightSegment firstFlightSegment) {
				return firstFlightSegment.getFlight() != null
					&& ((FlightStatus) firstFlightSegment.getFlight()).getStatus() != null
					&& !StringUtils.equalsIgnoreCase("Passive",
							(((FlightStatus) firstFlightSegment.getFlight()).getStatus()).getTravelportStatus().getValue());
	
	}
	
	
	/**
	 * 
	 * @param offer
	 * @param productIdentifier
	 * @param apisInfo
	 */
	protected static void createTermsAndConditionsAirDetail(Offer offer, String productIdentifier, APISInfo apisInfo) {
		List<TextBlock> textBlockList = new ArrayList<> ();
		if(!StringUtils.isBlank(apisInfo.getFixedAPISInfo())) {
			TextBlock textBlock = new TextBlock();
			textBlock.setTitle(APIS_INFO);
			TextFormatted textFormatted = new TextFormatted();
			textFormatted.setValue(apisInfo.getFixedAPISInfo());
			textBlock.getTextFormatted().add(textFormatted);
			textBlockList.add(textBlock);
		}
		
		if(apisInfo.getDefaultRespAPISDocTypes() != null) {
			if(!StringUtils.isBlank(apisInfo.getDefaultRespAPISDocTypes().getGenderDOBReq())) {
				TextBlock textBlock = new TextBlock();
				textBlock.setTitle(GENDERDOB_REQ);
				TextFormatted textFormatted = new TextFormatted();
				textFormatted.setValue(apisInfo.getDefaultRespAPISDocTypes().getGenderDOBReq());
				textBlock.getTextFormatted().add(textFormatted);
				textBlockList.add(textBlock);
			}
			
			if(!StringUtils.isBlank(apisInfo.getDefaultRespAPISDocTypes().getNationalityRequired())) {
				TextBlock textBlock = new TextBlock();
				textBlock.setTitle(NATIONALITY_REQUIRED);
				TextFormatted textFormatted = new TextFormatted();
				textFormatted.setValue(apisInfo.getDefaultRespAPISDocTypes().getNationalityRequired());
				textBlock.getTextFormatted().add(textFormatted);
				textBlockList.add(textBlock);
			}
			
			if(!StringUtils.isBlank(apisInfo.getDefaultRespAPISDocTypes().getOtherDocTypes())) {
				TextBlock textBlock = new TextBlock();
				textBlock.setTitle(OTHER_DOC_TYPES);
				TextFormatted textFormatted = new TextFormatted();
				textFormatted.setValue(apisInfo.getDefaultRespAPISDocTypes().getOtherDocTypes());
				textBlock.getTextFormatted().add(textFormatted);
				textBlockList.add(textBlock);
			}
		}
		if(!CollectionUtils.isEmpty(textBlockList)) {
			TermsAndConditionsFullAir termsAndConditionsAirDetail = new TermsAndConditionsFullAir();
			//Set product identifier to indicate TermsAndConditionsAirDetail for particular OD
			//this may have to set to Segment identifier is any carrier supports 
			//strictly segment level apis data
			TextBlock textBlock = new TextBlock();
			textBlock.setTitle("PRODUCT_IDENTIFIER");
			TextFormatted textFormatted = new TextFormatted();
			textFormatted.setValue(productIdentifier);
			textBlock.getTextFormatted().add(textFormatted);
			textBlockList.add(0, textBlock);
			
			termsAndConditionsAirDetail.getTextBlock().addAll(textBlockList);
			offer.getTermsAndConditionsFull().add(termsAndConditionsAirDetail);
		}
	}
	
	
	/**
	 * 
	 * @param reservation
	 * @return
	 */
	protected String getPrimaryCarrierCodeForOrder(Reservation reservation) {
		String primaryCarrierCode = "";
        if (reservation != null && !CollectionUtils.isEmpty (reservation.getOffer ()) && reservation.getOffer().get (0) instanceof Offer) {
            Offer offer = (Offer) reservation.getOffer ().get (0);
			if (!CollectionUtils.isEmpty(offer.getProduct()) && (offer.getProduct().get(0) instanceof ProductAir
					&& !CollectionUtils.isEmpty(((ProductAir) offer.getProduct().get(0)).getFlightSegment())
					&& null != ((ProductAir) offer.getProduct().get(0)).getFlightSegment().get(0).getFlight())) {

                String flightCarrierCode = null;
                
                FlightSegment flightSegment = ((ProductAir) ((Offer) reservation.getOffer ().get (0)).getProduct ().get (0)).getFlightSegment ()
                        .get (0);


                if (flightSegment.getFlight () != null) {
                	flightCarrierCode = ((Flight) flightSegment.getFlight()).getCarrier().trim();
                }

                if (flightCarrierCode != null) {
                    primaryCarrierCode = fetchPrimaryCarrierCode(flightCarrierCode);
                }
            }

        }
	        return primaryCarrierCode;
	}

	
	/**
	 * 
	 * @param flightCarrierCode
	 * @return
	 */
	private static String fetchPrimaryCarrierCode(String flightCarrierCode) {
		String primaryCarrierCode;
		String codeFromLookup = CarrierLookup.getInstance().getCarrierCodeBySecondaryCode(flightCarrierCode);
		if (null != codeFromLookup) {
			primaryCarrierCode = codeFromLookup;
		} else {
			primaryCarrierCode = flightCarrierCode;
		}
		return primaryCarrierCode;
	}
	
	/**
	 * 
	 * @param carrierCode
	 */
	private synchronized void checkForLatestAPISInfoForCarrier(String carrierCode) {
		
			long currentTimestamp = System.currentTimeMillis ();

			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > dEFAULT_CACHE_UPDATE_FREQUENCY) {

				final IntegerRedisCacheConnectorImpl integerRedisCacheConnectorImpl = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer returnedAirAsiaProductClassDataVersion = integerRedisCacheConnectorImpl.getValue (AIR_ASIA_APIS_DATA_VERSION_KEY);

				if (cachedAirAsiaAPISVersion < returnedAirAsiaProductClassDataVersion) {

					final InputStreamRedisCacheConnectorImpl inputStreamRedisCacheConnectorImpl = RedisConnectorConfig
							.prepareInputStreamRedisCacheConnector ();

					byte[] readBuffer = inputStreamRedisCacheConnectorImpl.getValue (AIR_ASIA_APIS_DATA_KEY);

					InputStream apisData = new ByteArrayInputStream (readBuffer);

					APISInfo apisInfo = parseAPISData(apisData);

					LOGGER.info ("APIS related data is loaded.");
					cachedAirAsiaAPISVersion = returnedAirAsiaProductClassDataVersion;
					apisMap.put(carrierCode.trim().toUpperCase(Locale.ENGLISH), apisInfo);

					lastUpdateTimeStamp = currentTimestamp;

					LOGGER.info ("Redis Cache data for APIS is checked at : " + System.currentTimeMillis ());
				}

			}

	
	}
	
	/**
	 * 
	 * @param apisData
	 * @return
	 */
	protected static APISInfo parseAPISData(InputStream apisData)   {
		try {
			getNewInstance();
			createUnmarshaller(apisData);
			APISInfo apisInfo = null;
			if (jaxbUnmarshaller != null) {
				apisInfo = (APISInfo) jaxbUnmarshaller.unmarshal(apisData);
				LOGGER.debug("APIS data parsed from Redis.");
				close(apisData);
				return apisInfo;
			} else {
				close(apisData);
				throw new JAXBException("Error occurred while unmarshalling apisData.");
			}
		} catch (JAXBException exp) {
			LOGGER.error("Error occurred while loading APIS data from Redis.", exp);
		}
		return null;
	}

	/**
	 * 
	 * @param apisData
	 */
	private static void close(InputStream apisData) {
		try {
			apisData.close();
		} catch (IOException e2) {
			LOGGER.error("Error occurred while closing apisData inputStream.", e2);
		}
		
	}

	
	private static void getNewInstance(){
		try {
			jaxbContext = JAXBContext.newInstance(APISInfo.class);
		} catch (JAXBException e1) {
			LOGGER.error("Error occurred while creating jaxbContext.", e1);
			}
	}
	
	/**
	 * 
	 * Method for create unmarshaller
	 * @param apisData
	 */
	private static void createUnmarshaller(InputStream apisData) {
		try {
			if (jaxbContext != null) {
				jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			}
		} catch (JAXBException e1) {
			LOGGER.error("Error occurred while creating jaxbUnmarshaller.", e1);
			try {
				apisData.close();
			} catch (IOException e2) {
				LOGGER.error("Error in apisData.close() during jaxbUnmarshaller creation.", e2);
			}
		}
	}
	
	
	

}
