/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.util;

import java.io.ByteArrayInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

/**
 * 1. RedisCacheUtil for interaction with RedisCache to retrieve the data based on cacheObjectKey

 * @author Ankit Kumar
 *
 */
public class RedisCacheUtil {

	private static final ACSLogger LOGGER = ACSLogger.getLogger(RedisCacheUtil.class);
	private static RedisCacheUtil redisCacheUtil = null;

	/*
	 * To get Single instance of RedisCacheUtil
	 */
	private RedisCacheUtil() {
	}
	public static synchronized RedisCacheUtil getInstance() {
		if (redisCacheUtil == null) {
			redisCacheUtil = new RedisCacheUtil();
		}
		return redisCacheUtil;
	}

	public NodeList loadRedisCacheData(String cacheObjectKey, String rootNode) {
		NodeList nList = null;
		try {
				final InputStreamRedisCacheConnectorImpl inputStreamRedisCacheConnectorImpl = RedisConnectorConfig
						.prepareInputStreamRedisCacheConnector();
				byte[] read_buffer = inputStreamRedisCacheConnectorImpl.getValue(cacheObjectKey);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = dbFactory.newDocumentBuilder();
				Document doc = builder.parse(new ByteArrayInputStream(read_buffer));
				doc.getDocumentElement().normalize();
				nList = doc.getElementsByTagName(rootNode);
			
		} catch (Exception e) {
			LOGGER.error("Error loading " + cacheObjectKey + " from redis", e);
		}
		return nList;
	}
}
