/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;
 
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
 
/**
 * Supported Currency Lookup
 * 
 * Based on a mapping sheet which contains Airport Code and corresponding currency related data
 * this lookup class will return currency related to an airport.
 * 
 * @author Sayanta.Ghosh
 *
 */
public class SupportedCurrencyLookup {
	
	private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
	private static final String ERROR = "ERROR";
	private static final String BLANK = "";
	private static SupportedCurrencyLookup currencyLookup = null;
	private static volatile Map<String,String> supportedCurrencyMapAirportBased = new HashMap<>();
	private static final String AIRPORT_SUPPORTED_CURRENCY_MAP_KEY = "AirportSupportedCurrencyMap";
	private static final String AIRPORT_SUPPORTED_CURRENCY_MAP_VERSION_KEY = "AirportSupportedCurrencyMap_Version";
	private static long SUPPORTED_CURRENCY_CACHE_UPDATE_FREQUENCY = 60000; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp = 0;    
	private static int supportedCurrencyMapVersion = 0;
	private static final ACSLogger LOGGER = ACSLogger.getLogger(SupportedCurrencyLookup.class);
	
	
    static {
        try {
            final String rcUpdateFr = System.getenv ("SupportedCurrencyRedisCacheUpdateFrequency");

            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

            if (cacheUpdateFrequency > 0) {
                SUPPORTED_CURRENCY_CACHE_UPDATE_FREQUENCY = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
        }

        LOGGER.debug ("SUPPORTED_CURRENCY_CACHE_UPDATE_FREQUENCY value is : " + SUPPORTED_CURRENCY_CACHE_UPDATE_FREQUENCY);
    }
	
	
	
	/*
	 * Get supported and overridden currency Data using airport code
	 */
	public String getSupportedAndOverriddenCurrency(final String airportCode, final String carrier) throws IOException {
		updateMapIfRequired ();
		String currency = null;
		if (supportedCurrencyMapAirportBased != null) {
			currency = supportedCurrencyMapAirportBased.get(new StringBuilder(airportCode).append(carrier).toString());
		}
		return currency;}
 
	
	/*
	 * Load support and override currency Spread sheet and update the same references as loaded from XML Mapping
	 * This method actually load the airport code and corresponding currency code from excel sheet 
	 */
	private static void loadSupportedAndOverridenCurrencyMappingFromCache() throws IOException {
		LOGGER.info("Loading Currency_Support_and_Override_Currency_Final.xlsx from Redis Cache.");
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(AIRPORT_SUPPORTED_CURRENCY_MAP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		Map<String,String> supportedCurrencyMapAirportBasedTemp = new HashMap<>();
		Row row = null ;
		// Get the workbook instance for XLS file
		XSSFWorkbook workbook = null;
        try {
        	
            workbook = new XSSFWorkbook (excelFileToRead);
            excelFileToRead.mark(1);
        	final int bytesRead = excelFileToRead.read(new byte[1]);
        	excelFileToRead.reset();
        if(bytesRead!=-1){
                processWorkbookData(supportedCurrencyMapAirportBasedTemp, workbook);
        }
        
        } catch (IOException e) {
            LOGGER.error ("Error reading Currency_Support_and_Override_Currency_Final.xlsx file", e);

            throw e;
        }finally{
         
                try {
                    excelFileToRead.close();
                } catch (IOException e) {
                    LOGGER.error("Error closing Currency_Support_and_Override_Currency_Final.xlsx file", e);
                }
          
        }
		
		LOGGER.info("Currency_Support_and_Override_Currency_Final.xlsx file loaded successfully");
	}


	private static void processWorkbookData(Map<String, String> supportedCurrencyMapAirportBasedTemp,
			XSSFWorkbook workbook) {
		Row row;
		XSSFSheet sheet = workbook.getSheetAt (0);
		Iterator<Row> rowIterator = sheet.iterator ();

		// fetch the number of supported carrier code from excel
		final Map<Integer, String> supportedCarrierMap = new HashMap<> ();
		for (int i = 3; i < sheet.getRow (0).getLastCellNum (); i++) {
		    if (sheet.getRow (0) != null && sheet.getRow (0).getCell (i) != null
		            && !StringUtils.isEmpty (sheet.getRow (0).getCell (i).getStringCellValue ())) {
		        final String carrierCode = sheet.getRow (0).getCell (i).getStringCellValue ().substring (0, 2);
		        supportedCarrierMap.put (i, carrierCode);
		    }
		}

		while (rowIterator.hasNext ()) {
		    processRowData(supportedCurrencyMapAirportBasedTemp, rowIterator, supportedCarrierMap);
		}
		supportedCurrencyMapAirportBased = supportedCurrencyMapAirportBasedTemp;
	}


	private static void processRowData(Map<String, String> supportedCurrencyMapAirportBasedTemp,
			Iterator<Row> rowIterator, final Map<Integer, String> supportedCarrierMap) {
		Row row;
		row = rowIterator.next ();
		if (row != null) {
		    processCellData(supportedCurrencyMapAirportBasedTemp, supportedCarrierMap, row);
		}
	}


	private static void processCellData(Map<String, String> supportedCurrencyMapAirportBasedTemp,
			final Map<Integer, String> supportedCarrierMap, Row row) {
		if (getCellValue (row.getCell (0)).trim ().length () == 3) {

		    // from 3rd row of the excel iterate over the
		    // currency code according to carrier
		    for (int i = 3; i < 3 + supportedCarrierMap.size (); i++) {
		        processCellDataForCarrierMap(supportedCurrencyMapAirportBasedTemp, supportedCarrierMap, row, i);
		    }

		}
	}


	private static void processCellDataForCarrierMap(Map<String, String> supportedCurrencyMapAirportBasedTemp,
			final Map<Integer, String> supportedCarrierMap, Row row, int i) {
		String airportCode = null;
		String currencyCode = null;
		if (!StringUtils.isEmpty (getCellValue (row.getCell (0))) && !StringUtils.isEmpty (getCellValue (row.getCell (i)))) {
		    airportCode = getCellValue (row.getCell (0));
		    currencyCode = getCellValue (row.getCell (i));
		    if (airportCode != null) {
		        supportedCurrencyMapAirportBasedTemp
		                .put (new StringBuilder (airportCode).append (supportedCarrierMap.get (i)).toString (), currencyCode);
		    }
		}
	}
	
	/*
	 * reading cell values from spread sheet is tricky as it depends on the value
	 * a cell in the same column can have integer value as well as string value
	 * So this method helps to read values from a spread sheet cell
	 */	
	protected static String getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			return Double.toString(cell.getNumericCellValue());
		
		default:
			return getCellData(cell);
			}
		
	}
	
	/*
	 * reading cell values from spread sheet is tricky as it depends on the value
	 * a cell in the same column can have integer value as well as string value
	 * So this method helps to read values from a spread sheet cell
	 */	
	private static String getCellData(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue().trim();
		
		default:
			return getCellData1(cell);
		}
		
	}
	/*
	 * reading cell values from spread sheet is tricky as it depends on the value
	 * a cell in the same column can have integer value as well as string value
	 * So this method helps to read values from a spread sheet cell
	 */	
	protected static String getCellData1(Cell cell) {
		switch (cell.getCellType()) {
		
		case Cell.CELL_TYPE_BLANK:
			return BLANK;
		case Cell.CELL_TYPE_ERROR:
			return ERROR;
		default:
			return COULD_NOT_READ_DATA;
		}
		
	}
	
	/*
	 * Block multiple instance of this CurrencyTranslator
	 */
	private SupportedCurrencyLookup(){
		
	}
	
	/*
	 * get a singleton instance
	 */
	public static synchronized SupportedCurrencyLookup getInstance(){
		
		if(currencyLookup == null) {
			currencyLookup = new SupportedCurrencyLookup();
	      }
		return currencyLookup;
 
	}
		
	 private static synchronized void updateMapIfRequired () throws IOException {
	        try {
	            long currentTimestamp = System.currentTimeMillis ();
	            
	            // Do the update less frequently. We don't expect the cache to change every minute.
	            if ((currentTimestamp - lastUpdateTimeStamp) > SUPPORTED_CURRENCY_CACHE_UPDATE_FREQUENCY) {
	                
	                final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
	                final Integer cachedVersion = versionConnector.getValue (AIRPORT_SUPPORTED_CURRENCY_MAP_VERSION_KEY);

	                if (supportedCurrencyMapVersion < cachedVersion) {
	                    loadSupportedAndOverridenCurrencyMappingFromCache ();

	                    supportedCurrencyMapVersion = cachedVersion;
	                }

	                lastUpdateTimeStamp = currentTimestamp;
	            }
	        } catch (IOException ex) {
	            LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
	            throw ex;
	        }
	    }
}