/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.util.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

/**
 * CarrierLookup Based on a mapping XML which contains mapping of primary
 * carrier and secondary/subsidiary carrier.
 * 
 * 
 * @author Debabrata.Dey
 *
 */

public final class CarrierLookup {

	private static CarrierLookup carrierLookup;
	private static Map<String, String> carrierMap = new HashMap<>();
	private static Map<String, List<String>> reverseCarrierMap = new HashMap<>();
	private static Map<String, String> airLineNameMap = new HashMap<>();

	private static final String CARRIER_MAPPING_KEY = "CarrierMapping";
	private static final String CARRIER_MAPPING_VERSION_KEY = "CarrierMapping_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(CarrierLookup.class);
	private static final long SIXTY_THOUSAND = 60000;
	private static long carrierCurrencyCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp;    
	private static int supportedCurrencyMapVersion;

	/*
	 * Block multiple instance of this CarrierLookup
	 */
	private CarrierLookup() {

	}
	
	static {
		try {
			final String rcUpdateFr = System.getenv ("CarrierRedisCacheUpdateFrequency");

			LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				carrierCurrencyCacheUpdateFrequency = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug ("CARRIER_CACHE_UPDATE_FREQUENCY value is : " + carrierCurrencyCacheUpdateFrequency);
	}

	private static synchronized void updateMapIfRequired () {
		try {
			long currentTimestamp = System.currentTimeMillis ();
			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > carrierCurrencyCacheUpdateFrequency) {
				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer cachedVersion = versionConnector.getValue (CARRIER_MAPPING_VERSION_KEY);

				if (supportedCurrencyMapVersion < cachedVersion) {
					loadCarrierMapping ();

					supportedCurrencyMapVersion = cachedVersion;
				}

				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.info(ex);
			LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
		}
	}

	/*
	 * Get primary carrier code by secondary carrier code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public String getCarrierCodeBySecondaryCode(String code) {
		updateMapIfRequired ();
		String carrierCode = null;
		if(carrierMap!=null){
			carrierCode = carrierMap.get(code);

		}
		return carrierCode;
	}

	/*
	 * Get primary carrier code by secondary carrier code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public List<String> getSecondaryCarrierCodeByPrimaryCarrierCode(String code) {
		updateMapIfRequired ();
		List<String> carrierMap1 = Collections.emptyList();
		if(reverseCarrierMap!=null){
			carrierMap1 =  reverseCarrierMap.get(code);
		}
		return carrierMap1;
	}

	/*
	 * Get primary airline name by primary carrier code 
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public String getAirLineNameByPrimaryCarrierCode (String code) {
		updateMapIfRequired ();
		String airlineName = null;
		if (airLineNameMap != null) {
			airlineName =  airLineNameMap.get (code);
		}
		return airlineName;
	}

	/*
	 * Load Translation XML
	 */
	/**
	 * 
	 * @throws IOException
	 */
	private static void loadCarrierMapping() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(CARRIER_MAPPING_KEY);
		final InputStream inputStream = new ByteArrayInputStream(fileBytes);
		Map<String, String> carrierMapTemp = new HashMap<>();
		Map<String, List<String>> reverseCarrierMapTemp = new HashMap<>();
		Map<String, String> airLineNameMapTemp = new HashMap<>();
		try {
			processDocument(inputStream, carrierMapTemp, reverseCarrierMapTemp, airLineNameMapTemp);
		} catch (FactoryConfigurationError| ParserConfigurationException| SAXException| IOException e) {
			LOGGER.info(e);

		} finally {
			inputStream.mark(1);
			final int bytesRead = inputStream.read(new byte[1]);
			inputStream.reset();
			if (bytesRead != -1) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					LOGGER.info(e1);
				}
			}
		}
	}

	/**
	 * 
	 * @param inputStream
	 * @param carrierMapTemp
	 * @param reverseCarrierMapTemp
	 * @param airLineNameMapTemp
	 * @throws FactoryConfigurationError
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private static void processDocument(final InputStream inputStream, Map<String, String> carrierMapTemp,
			Map<String, List<String>> reverseCarrierMapTemp, Map<String, String> airLineNameMapTemp)
					throws FactoryConfigurationError, ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setXIncludeAware(false);
		dbFactory.setExpandEntityReferences(false);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		LOGGER.debug(" set load-external-dtd as True.");
		dbFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);

		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document doc = builder.parse(inputStream);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("PrimaryCarrier");

		for (int count = 0; count < nList.getLength(); count++) {

			processNode(carrierMapTemp, reverseCarrierMapTemp, airLineNameMapTemp, nList, count);
		}

		carrierMap.putAll (carrierMapTemp);
		airLineNameMap.putAll (airLineNameMapTemp);
		reverseCarrierMap.putAll (reverseCarrierMapTemp);

		if (inputStream != null) {
			inputStream.close();
		}
	}

	/**
	 * 
	 * @param carrierMapTemp
	 * @param reverseCarrierMapTemp
	 * @param airLineNameMapTemp
	 * @param nList
	 * @param count
	 */
	private static void processNode(Map<String, String> carrierMapTemp, Map<String, List<String>> reverseCarrierMapTemp,
			Map<String, String> airLineNameMapTemp, NodeList nList, int count) {
		Node nNode = nList.item(count);
		List<String> secCxrList = new ArrayList<> ();

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			processElement(carrierMapTemp, reverseCarrierMapTemp, airLineNameMapTemp, nNode, secCxrList);
		}
	}

	/**
	 * 
	 * @param carrierMapTemp
	 * @param reverseCarrierMapTemp
	 * @param airLineNameMapTemp
	 * @param nNode
	 * @param secCxrList
	 */
	private static void processElement(Map<String, String> carrierMapTemp,
			Map<String, List<String>> reverseCarrierMapTemp, Map<String, String> airLineNameMapTemp, Node nNode,
			List<String> secCxrList) {
		Element eElement = (Element) nNode;
		NodeList secList = eElement.getElementsByTagName("SecondaryCarrier");
		for (int secCount = 0; secCount < secList.getLength(); secCount++) {

			processNode(carrierMapTemp, airLineNameMapTemp, secCxrList, eElement, secList, secCount);
		}
		if(!CollectionUtils.isEmpty(secCxrList)) {
			reverseCarrierMapTemp.put(eElement.getAttribute("Code"), secCxrList);
		}
	}

	/**
	 * 
	 * @param carrierMapTemp
	 * @param airLineNameMapTemp
	 * @param secCxrList
	 * @param eElement
	 * @param secList
	 * @param secCount
	 */
	private static void processNode(Map<String, String> carrierMapTemp, Map<String, String> airLineNameMapTemp,
			List<String> secCxrList, Element eElement, NodeList secList, int secCount) {
		Node secNode = secList.item(secCount);
		if (secNode != null && secNode.getNodeType() == Node.ELEMENT_NODE) {
			Element secElement = (Element) secNode;
			carrierMapTemp.put(secElement.getAttribute("Code"), eElement.getAttribute("Code"));
			airLineNameMapTemp.put (secElement.getAttribute("Code"),secElement.getAttribute("Name"));
			secCxrList.add(secElement.getAttribute("Code"));
		}
	}

	

	/*
	 * get a singleton instance
	 */
	/**
	 * 
	 * @return
	 */
	public static synchronized CarrierLookup getInstance() {
		if (carrierLookup == null) {
			carrierLookup = new CarrierLookup();
		}
		return carrierLookup;

	}
}
