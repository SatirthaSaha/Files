/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

/**
 * OriginApplicationLookUp Based on a mapping XML which contains mapping of
 * OriginApplicationID
 * 
 * @author Lalit.Mohan
 *
 */
public class OriginApplicationIDLookup {

    private static OriginApplicationIDLookup originApplicationLookUp ;
    private static final String ORIGIN_APPLICATION_ID_MAPPING_KEY = "OriginApplicationIDMapping";
    private static final String ORIGIN_APPLICATION_ID_MAPPING_VERSION_KEY = "OriginApplicationIDMapping_Version";
    private static List<String> originApplicationIDList  = new ArrayList<> ();
    private static long _ORIGIN_APPID_CACHE_UPDATE_FREQUENCY = 60000; // Update frequency can be modulated.
    private static long lastUpdateTimeStamp ;    
    private static int originAppIDMapVersion ;
    private static final ACSLogger LOGGER = ACSLogger.getLogger(OriginApplicationIDLookup.class);
    
    static {
        try {
            final String rcUpdateFr = System.getenv ("OriginApplicationIDRedisCacheUpdateFrequency");

            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

            if (cacheUpdateFrequency > 0) {
                _ORIGIN_APPID_CACHE_UPDATE_FREQUENCY = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
        }

        LOGGER.debug ("ORIGIN_APPID_CACHE_UPDATE_FREQUENCY value is : " + _ORIGIN_APPID_CACHE_UPDATE_FREQUENCY);
    }

    /*
     * Block multiple instance of this OriginApplicationLookUp
     */
    private OriginApplicationIDLookup () {

    }

    /*
     * is isSmartPointOrTASOriginApplicationId by originApplicationID
     */
    public boolean isSmartPointOrTASOriginApplicationId (String originApplicationID) {
        updateMapIfRequired ();
            return originApplicationIDList.contains (originApplicationID);
    }

    /*
     * Load Translation XML
     */
    private static List<String> retrieveOriginApplicationMapping () throws IOException,ParserConfigurationException,SAXException{
        final List<String> originApplicationIDList = new ArrayList<> ();
        
        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
        
        final byte[] fileBytes = connector.getValue (ORIGIN_APPLICATION_ID_MAPPING_KEY);
        final InputStream inputStream = new ByteArrayInputStream (fileBytes);
        
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance ();
            dbFactory.setXIncludeAware (false);
            dbFactory.setExpandEntityReferences (false);
            dbFactory.setFeature ("http://xml.org/sax/features/external-general-entities", false);
            dbFactory.setFeature ("http://xml.org/sax/features/external-parameter-entities", false);
            LOGGER.debug(" set external-general-entities as False.");
            dbFactory.setFeature ("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbFactory.setFeature ("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
            dbFactory.setFeature (javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);

            DocumentBuilder builder = dbFactory.newDocumentBuilder ();
            Document doc = builder.parse (inputStream);
            doc.getDocumentElement ().normalize ();

            NodeList nList = doc.getElementsByTagName ("OriginApplication");

            for (int count = 0; count < nList.getLength (); count++) {
                Node nNode = nList.item (count);

                if (nNode != null && nNode.getNodeType () == Node.ELEMENT_NODE) {
                    Element element = (Element) nNode;

                    originApplicationIDList.add (element.getAttribute ("OriginApplicationID"));
                }
            }
            inputStream.mark(1);
        	final int bytesRead = inputStream.read(new byte[1]);
        	inputStream.reset();
            if (bytesRead != -1) {
                inputStream.close ();
            }
        } catch (IOException |ParserConfigurationException |SAXException e) {
        	LOGGER.info(e);

        } finally {
        	inputStream.mark(1);
        	LOGGER.debug("Reseing the input stream");
        	inputStream.reset();
           }
        
        return originApplicationIDList;
    }

   
    /*
     * get a singleton instance
     */
    public static synchronized OriginApplicationIDLookup getInstance () {
        if (originApplicationLookUp == null) {
            originApplicationLookUp = new OriginApplicationIDLookup ();
        }
        return originApplicationLookUp;
    }

    
    private static synchronized void updateMapIfRequired () {
        try {
            long currentTimestamp = System.currentTimeMillis ();
            
            // Do the update less frequently. We don't expect the cache to change every minute.
            if ((currentTimestamp - lastUpdateTimeStamp) > _ORIGIN_APPID_CACHE_UPDATE_FREQUENCY) {
                final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
                final Integer cachedVersion = versionConnector.getValue (ORIGIN_APPLICATION_ID_MAPPING_VERSION_KEY);

                if (originAppIDMapVersion < cachedVersion) {
                    
                    List<String> originApplicationIDListTemp = retrieveOriginApplicationMapping ();
                    
                    originApplicationIDList = originApplicationIDListTemp;

                    originAppIDMapVersion = cachedVersion;
                }

                lastUpdateTimeStamp = currentTimestamp;
            }
        } catch (IOException | ParserConfigurationException | SAXException ex) {
            LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
            LOGGER.info(ex);
        }
    }
}
