/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.Currency;

/**
 * Currency Lookup
 * 
 * Based on a mapping sheet which contains Airport Code and corresponding currency related data
 * this lookup class will return currency related to an airport.
 * 
 * this translator will also return currency related data like decimal unit, rounding unit, rounding action based on a currency code.
 * Note that as these values decimal unit, rounding unit, rounding action may differ based on a airport code, so if you lookup by currency code,
 * translator will return the first occurrence as in the mapping sheet. 
 * 
 * @author Debabrata.Dey
 *
 */
public final class CurrencyLookup {

	private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
	private static final String ERROR = "ERROR";
	private static final String BLANK = "";
	private static CurrencyLookup currencyLookup;
	private static Map<String,Currency> currencyMapAirportBased = new HashMap<>();
	private static Map<String,Currency> currencyMapCurrencyBased = new HashMap<>();
	private static Map<String,Currency> deltaCurrencyMapCurrencyBased = new HashMap<>();
	protected static final String CURRENCY_LOOKUP_KEY = "CurrencyLookup";
	private static final String DELTA_CURRENCY_LOOKUP_KEY = "DeltaCurrencyLookup";
	private static final String DELTA_CURRENCY_LOOKUP_VERSION_KEY = "Delta_CurrencyLookup_Version";
	private static final String CURRENCY_LOOKUP_VERSION_KEY = "CurrencyLookup_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(CurrencyLookup.class);
	private static final int TWO=2;
	private static final int THREE=3;
	private static final int FOUR=4;
	private static final int FIVE=5;
	private static final long SIXTY_THOUSAND=60000;
	private static long currencyCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp; 
	private static long lastUpdateTimeStampDl; 
	private static int supportedCurrencyMapVersion;
	private static int supportedCurrencyMapVersionDl;

	/*
	 * Block multiple instance of this CurrencyTranslator
	 */
	private CurrencyLookup(){

	}

	static {
		try {
			final String rcUpdateFr = System.getenv ("CurrencyRedisCacheUpdateFrequency");

			LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				currencyCacheUpdateFrequency = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug ("CURRENCY_CACHE_UPDATE_FREQUENCY value is : " + currencyCacheUpdateFrequency);
	}


	/*
	 * Get currency Data using airport code
	 */
	/**
	 * 
	 * @param airportCode
	 * @return
	 */
	public Currency getCurrencyByAirportCode(String airportCode){
		updateMapIfRequired ();
		Currency currency =null;
		if(currencyMapAirportBased!=null){
			currency = currencyMapAirportBased.get(airportCode);
		} 
		return currency;
	}
	/*	
	 * Get currency related data like decimal unit, rounding unit, rounding action based on a currency code.
	 * Note that as these values decimal unit, rounding unit, rounding action may differ based on a airport code, so if you lookup by currency code,
	 * translator will return the first occurrence as in the mapping sheet. 
	 */
	/**
	 * 
	 * @param currencyCode
	 * @return
	 */
	public Currency getCurrencyByCurencyCode(String currencyCode){
		updateMapIfRequired ();
		Currency currency = null;
		if(currencyMapCurrencyBased!=null){
			currency = currencyMapCurrencyBased.get(currencyCode);

		}
		return currency;
	}



	/*	
	 * Get currency related data like decimal unit, rounding unit, rounding action based on a currency code.
	 * Note that as these values decimal unit, rounding unit, rounding action may differ based on a airport code, so if you lookup by currency code,
	 * translator will return the first occurrence as in the mapping sheet. 
	 */
	/**
	 * 
	 * @param currencyCode
	 * @return
	 */
	public Currency getDeltaCurrencyByCurencyCode(String currencyCode){
		updateDlCurrencyListIfRequired();
		Currency currency =null;
		if(deltaCurrencyMapCurrencyBased!=null){
			currency = deltaCurrencyMapCurrencyBased.get(currencyCode);

		}
		return currency;
	}

	public Map<String,Currency> getAllCurrency(){
		updateMapIfRequired ();

		return currencyMapAirportBased;
	}

	/*
	 * Load Translation Mapping Spread sheet and update the same references as loaded from XML Mapping
	 * This method actually updates, description and category like MEAL etc for each SSR loaded from the XML, based on the spread sheet 
	 */
	/**
	 * 
	 * @throws IOException
	 */
	private static void loadAirportCurrencyMappingFromCache() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		Map<String,Currency> currencyMapAirportBasedTemp = new HashMap<>();
		Map<String,Currency> currencyMapCurrencyBasedTemp = new HashMap<>();

		// Get the workbook instance for XLS file
		XSSFWorkbook workbook = null;
		try {
			workbook = new XSSFWorkbook(excelFileToRead);
			excelFileToRead.mark(1);
			final int bytesRead = excelFileToRead.read(new byte[1]);
			excelFileToRead.reset();
			if (bytesRead != -1) {
				processWorkbookData(currencyMapAirportBasedTemp, currencyMapCurrencyBasedTemp, workbook);
			}
			currencyMapAirportBased.putAll (currencyMapAirportBasedTemp);
			currencyMapCurrencyBased.putAll (currencyMapCurrencyBasedTemp);
		} catch (IOException e1) {
			LOGGER.error("Error reading Airport_Currency_Decimal_list from Redis Cache.", e1);
			throw e1;
		}finally{
			excelFileToRead.mark(1);
			final int bytesRead = excelFileToRead.read(new byte[1]);
			excelFileToRead.reset();
			if (bytesRead != -1){
				try {
					excelFileToRead.close();
				} catch (IOException e) {
					LOGGER.info(e);
				}
			}
		}

	}
	
	/**
	 * 
	 * @param currencyMapAirportBasedTemp
	 * @param currencyMapCurrencyBasedTemp
	 * @param workbook
	 */
	private static void processWorkbookData(Map<String, Currency> currencyMapAirportBasedTemp,
			Map<String, Currency> currencyMapCurrencyBasedTemp, XSSFWorkbook workbook) {
		XSSFSheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowIterator = sheet.iterator();

		while (rowIterator.hasNext()) {
			processRowData(currencyMapAirportBasedTemp, currencyMapCurrencyBasedTemp, rowIterator);
		}
	}
	
	/**
	 * 
	 * @param currencyMapAirportBasedTemp
	 * @param currencyMapCurrencyBasedTemp
	 * @param rowIterator
	 */
	private static void processRowData(Map<String, Currency> currencyMapAirportBasedTemp,
			Map<String, Currency> currencyMapCurrencyBasedTemp, Iterator<Row> rowIterator) {
		Row row = rowIterator.next();
		if (row != null) {
			processCellData(currencyMapAirportBasedTemp, currencyMapCurrencyBasedTemp, row);
		}
	}
	
	/**
	 * 
	 * @param currencyMapAirportBasedTemp
	 * @param currencyMapCurrencyBasedTemp
	 * @param row
	 */
	private static void processCellData(Map<String, Currency> currencyMapAirportBasedTemp,
			Map<String, Currency> currencyMapCurrencyBasedTemp, Row row) {
		if(getCellValue(row.getCell(0)).trim().length()==THREE){
			Currency currency = new Currency();					
			currency.setAirportCode(getCellValue(row.getCell(0)));
			currency.setAirportName(getCellValue(row.getCell(1)));
			currency.setCurrencyCode(getCellValue(row.getCell(TWO)));
			currency.setCurrencyDecimal((int) row.getCell(THREE).getNumericCellValue());
			currency.setCurrencyRoundUnit(row.getCell(FOUR).getNumericCellValue());
			currency.setCurrencyRoundAction(getCellValue(row.getCell(FIVE)));

			if(currency.getAirportCode()!=null && currency.getCurrencyCode() !=null){
				currencyMapAirportBasedTemp.put(currency.getAirportCode(), currency);
				currencyMapCurrencyBasedTemp.put(currency.getCurrencyCode(), currency);
			}
		}
	}

	/*
	 * reading cell values from spread sheet is tricky as it depends on the value
	 * a cell in the same column can have integer value as well as string value
	 * So this method helps to read values from a spread sheet cell
	 */	
	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellValue(Cell cell) {
		if (cell != null) {
			if(cell.getCellType()==Cell.CELL_TYPE_STRING)
				return cell.getStringCellValue().trim();
			return getCellData(cell);
		}
		return COULD_NOT_READ_DATA;

	}

	/*
	 * reading cell values from spread sheet is tricky as it depends on the value
	 * a cell in the same column can have integer value as well as string value
	 * So this method helps to read values from a spread sheet cell
	 */	
	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellData(Cell cell) {

		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BLANK:
			return BLANK;
		case Cell.CELL_TYPE_ERROR:
			return ERROR;
		default:
			return COULD_NOT_READ_DATA;
		}

	}

	

	/*
	 * get a singleton instance
	 */
	public static synchronized CurrencyLookup getInstance(){
		if(currencyLookup == null) {
			currencyLookup = new CurrencyLookup();
		}
		return currencyLookup;

	}

	private static synchronized void updateMapIfRequired () {
		try {
			long currentTimestamp = System.currentTimeMillis ();
			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > currencyCacheUpdateFrequency) {

				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer cachedVersion = versionConnector.getValue (CURRENCY_LOOKUP_VERSION_KEY);

				if (supportedCurrencyMapVersion < cachedVersion) {
					loadAirportCurrencyMappingFromCache ();

					supportedCurrencyMapVersion = cachedVersion;
				}

				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
			LOGGER.info(ex);
		}
	}

	
	private static synchronized void updateDlCurrencyListIfRequired () {
		try {
			long currentTimestamp = System.currentTimeMillis ();
			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStampDl) > currencyCacheUpdateFrequency) {

				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer cachedVersion = versionConnector.getValue (DELTA_CURRENCY_LOOKUP_VERSION_KEY);

				if (supportedCurrencyMapVersionDl < cachedVersion) {
					loadDlSupportedCurrencyFromCache ();

					supportedCurrencyMapVersionDl = cachedVersion;
				}

				lastUpdateTimeStampDl = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
			LOGGER.info(ex);
		}
	}
	
	/**
	 * 
	 * @throws IOException
	 */
	private static void loadDlSupportedCurrencyFromCache() throws IOException {

		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(DELTA_CURRENCY_LOOKUP_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		Map<String,Currency> currencyMapCurrencyBasedTemp = new HashMap<>();

		try {
			processWorkbookData(excelFileToRead, currencyMapCurrencyBasedTemp);
		} catch (IOException e1) {
			LOGGER.error("Error in reading Delta Currency List from Redis Cache.", e1);
			throw e1;
		}finally{
			excelFileToRead.mark(1);
			final int bytesRead = excelFileToRead.read(new byte[1]);
			LOGGER.debug("Executing final block");
			excelFileToRead.reset();
			if (bytesRead != -1) {
				try {
					LOGGER.debug("excelFileToRead as close");
					excelFileToRead.close();
				} catch (IOException e) {
					LOGGER.info(e);
				}
			}
		}



	}
	
	/**
	 * 
	 * @param excelFileToRead
	 * @param currencyMapCurrencyBasedTemp
	 * @throws IOException
	 */
	private static void processWorkbookData(final InputStream excelFileToRead,
			Map<String, Currency> currencyMapCurrencyBasedTemp) throws IOException {
		XSSFWorkbook workbook;
		workbook = new XSSFWorkbook(excelFileToRead);
		excelFileToRead.mark(1);
		final int bytesRead = excelFileToRead.read(new byte[1]);
		excelFileToRead.reset();
		if (bytesRead != -1) {
			processSheetData(currencyMapCurrencyBasedTemp, workbook);
		}
		deltaCurrencyMapCurrencyBased.putAll (currencyMapCurrencyBasedTemp);
	}
	
	/**
	 * 
	 * @param currencyMapCurrencyBasedTemp
	 * @param workbook
	 */
	private static void processSheetData(Map<String, Currency> currencyMapCurrencyBasedTemp, XSSFWorkbook workbook) {
		XSSFSheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowIterator = sheet.iterator();

		while (rowIterator.hasNext()) {
			processRowData(currencyMapCurrencyBasedTemp, rowIterator);
		}
	}
	
	/**
	 * 
	 * @param currencyMapCurrencyBasedTemp
	 * @param rowIterator
	 */
	private static void processRowData(Map<String, Currency> currencyMapCurrencyBasedTemp, Iterator<Row> rowIterator) {
		Row row = rowIterator.next();
		if (row != null) {
			processCellData(currencyMapCurrencyBasedTemp, row);
		}
	}
	
	/**
	 * 
	 * @param currencyMapCurrencyBasedTemp
	 * @param row
	 */
	private static void processCellData(Map<String, Currency> currencyMapCurrencyBasedTemp, Row row) {
		if(getCellValue(row.getCell(0)).trim().length()==THREE){
			Currency currency = new Currency();					
			currency.setCurrencyCode(getCellValue(row.getCell(0)));

			if(currency.getCurrencyCode() !=null){
				currencyMapCurrencyBasedTemp.put(currency.getCurrencyCode(), currency);
			}
		}
	}


}
