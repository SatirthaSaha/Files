/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.ShopModifierData;

/**
 * carrierModifierLookup Based on a CarrierModifierMapping XML which contains
 * mapping of a carrier and ShopModifierData.
 * 
 * 
 * 
 *
 */
public final class CarrierModifierLookup {

	private static CarrierModifierLookup carrierModifierLookup;
	private static final String CARRIER_MODIFIER_LOOKUP_KEY = "ShopAirModifierMapping";
	private static final String CARRIER_MODIFIER_MAPPING_ACTUAL_VERSION = "ShopAirModifierMapping_Version";
	private static Map<String, ShopModifierData> carrierModifierLookupMap = new HashMap<>();
	private static final long SIXTY_THOUSAND=60000;
	private static long shopModifierUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp;
	private static int shopAirModifierMappingVersion;
	private static final ACSLogger LOGGER = ACSLogger.getLogger(CarrierModifierLookup.class);

	static {
		try {
			final String rcUpdateFr = System.getenv("CarrierRedisCacheUpdateFrequency");

			LOGGER.debug("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong(rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				shopModifierUpdateFrequency = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug("ORIGIN_APPID_CACHE_UPDATE_FREQUENCY value is : " + shopModifierUpdateFrequency);
	}
	
	/*
	 * Block multiple instance of this CarrierLookup
	 */
	private CarrierModifierLookup() {

	}
	
	/**
	 * get a singleton instance
	 */
	public static synchronized CarrierModifierLookup getInstance() {
		if (carrierModifierLookup == null) {
			carrierModifierLookup = new CarrierModifierLookup();
		}
		return carrierModifierLookup;
	}


	/**
	 * get Modifier Data using carrier and modifier
	 */
	public ShopModifierData getShopModifierObjectFromCarrierCode(String carrierCode) {
		updateMapIfRequired();
		if (carrierModifierLookupMap != null && carrierCode != null) {
			ShopModifierData shopModifierData = carrierModifierLookupMap.get(carrierCode);
			return shopModifierData;
		}
		return null;
	}

	/**
	 * Load ShopAirModifier XML
	 */
	private static void loadCarrierModifierMapping() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig
				.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(CARRIER_MODIFIER_LOOKUP_KEY);
		final InputStream inputStream = new ByteArrayInputStream(fileBytes);
		Map<String, ShopModifierData> carrierModifierLookupMapTemp = new HashMap<>();
		try {
			processDocument(inputStream, carrierModifierLookupMapTemp);
		} catch (FactoryConfigurationError| ParserConfigurationException| SAXException| IOException e) {
			LOGGER.info(e);

		} finally {
			inputStream.mark(1);
			final int bytesRead = inputStream.read(new byte[1]);
			inputStream.reset();
			if (bytesRead != -1) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					LOGGER.info(e1);
				}
			}
		}
	}

	/**
	 * Processing XML Document Extracted from ShopAirModifierMapping.
	 */
	private static void processDocument(InputStream inputStream,
			Map<String, ShopModifierData> carrierModifierLookupMapTemp)
			throws FactoryConfigurationError, ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setXIncludeAware(false);
		dbFactory.setExpandEntityReferences(false);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		LOGGER.debug(" set load-external-dtd as True.");
		dbFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document doc = builder.parse(inputStream);
		doc.getDocumentElement().normalize();
		NodeList carrierList = doc.getElementsByTagName("Carrier");

		for (int count = 0; count < carrierList.getLength(); count++) {

			processNode(carrierModifierLookupMapTemp, carrierList, carrierList.item(count));
		}

		carrierModifierLookupMap.putAll(carrierModifierLookupMapTemp);

		if (inputStream != null) {
			inputStream.close();
		}
	}

	/**
	 * Processing each Node of XML Document
	 */

	private static void processNode(Map<String, ShopModifierData> carrierModifierLookupMapTemp, NodeList carrierList,
			Node carrierNode) {
		
		if (carrierNode != null && carrierNode.getNodeType() == Node.ELEMENT_NODE) {
			processElement(carrierModifierLookupMapTemp, carrierNode);
		}
	}

	/**
	 * retrieving element of each Node
	 */
	private static void processElement(Map<String, ShopModifierData> carrierModifierLookupMapTemp, Node carrierNode) {
		
		Element carrierElement = (Element) carrierNode;
		String carrier = carrierElement.getAttribute("Code");
		NodeList carrierModifierDataNodeList = carrierElement.getElementsByTagName("ShopModifierData");
		processModifierNode(carrierModifierLookupMapTemp, carrierModifierDataNodeList, carrier);

	}

	/**
	 * Set each attribute of the element in Map
	 */
	private static void processModifierNode(Map<String, ShopModifierData> carrierModifierLookupMapTemp,
			NodeList carrierModifierDataNodeList, String carrier) {
		ShopModifierData shopModifierData = new ShopModifierData();
		Node carrierModifierNode = carrierModifierDataNodeList.item(0);
		if (carrierModifierNode != null && carrierModifierNode.getNodeType() == Node.ELEMENT_NODE) {
			Element carrierModifierElement = (Element) carrierModifierNode;
			shopModifierData.setCarrier(carrier);
			shopModifierData.setNonStopDirect(carrierModifierElement.getAttribute("nonStopDirect"));
			shopModifierData.setStopDirect(carrierModifierElement.getAttribute("stopDirect"));
			shopModifierData.setSingleConnection(carrierModifierElement.getAttribute("singleConnection"));
			shopModifierData.setDoubleConnection(carrierModifierElement.getAttribute("doubleConnection"));
			shopModifierData.setNoAdvancePurchase(carrierModifierElement.getAttribute("noAdvancePurchase"));
			shopModifierData.setNoMinimumStay(carrierModifierElement.getAttribute("noMinimumStay"));
			shopModifierData.setNoMaximumStay(carrierModifierElement.getAttribute("noMaximumStay"));
			shopModifierData.setNoPenalty(carrierModifierElement.getAttribute("noPenalty"));
			shopModifierData.setEquivalentCurrency(carrierModifierElement.getAttribute("equivalentCurrency"));
			shopModifierData.setPublicFares(carrierModifierElement.getAttribute("publicFares"));
			shopModifierData.setPrivateFares(carrierModifierElement.getAttribute("privateFares"));
			shopModifierData.setPublicAndPrivateFares(carrierModifierElement.getAttribute("publicAndPrivateFares"));
			shopModifierData.setNetFares(carrierModifierElement.getAttribute("netFares"));
			shopModifierData.setExcludeGround(carrierModifierElement.getAttribute("excludeGround"));
			shopModifierData
					.setCabinPreferencePermitted(carrierModifierElement.getAttribute("cabinPreferencePermitted"));
			shopModifierData
					.setCabinPreferencePreferred(carrierModifierElement.getAttribute("cabinPreferencePreferred"));
			shopModifierData
					.setAirlinePreferencePermitted(carrierModifierElement.getAttribute("airlinePreferencePermitted"));
			shopModifierData
					.setAirlinePreferenceProhibited(carrierModifierElement.getAttribute("airlinePreferenceProhibited"));
			shopModifierData
					.setAirlinePreferencePreferred(carrierModifierElement.getAttribute("airlinePreferencePreferred"));
			shopModifierData.setPtcType(carrierModifierElement.getAttribute("ptcType"));
			shopModifierData.setProhibitChangeOfAirport(carrierModifierElement.getAttribute("prohibitChangeOfAirport"));
			shopModifierData.setMaxConnectionDuration(carrierModifierElement.getAttribute("maxConnectionDuration"));
			shopModifierData.setMaxOvernightDuration(carrierModifierElement.getAttribute("maxOvernightDuration"));
			shopModifierData
					.setExcludeInterlineConnections(carrierModifierElement.getAttribute("excludeInterlineConnections"));
			shopModifierData.setAccountCode(carrierModifierElement.getAttribute("accountCode"));
			
		}
		carrierModifierLookupMapTemp.put(carrier, shopModifierData);
	}




	private static synchronized void updateMapIfRequired() {
		try {
			long currentTimestamp = System.currentTimeMillis();

			// Do the update less frequently. We don't expect the cache to change every
			// minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > shopModifierUpdateFrequency) {
				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig
						.prepareIntegerRedisCacheConnector();
				final Integer cachedVersion = versionConnector.getValue(CARRIER_MODIFIER_MAPPING_ACTUAL_VERSION);
				if (shopAirModifierMappingVersion < cachedVersion) {
					loadCarrierModifierMapping();
					shopAirModifierMappingVersion = cachedVersion;
				}
				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.error("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage());
			LOGGER.info(ex);
		}
	}
}
