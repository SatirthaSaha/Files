/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.ODTInvocationBuilder;

/**
 * AtomicCarrierLookup Based on a ShopAtomicMapping XML which contains mapping of primary
 * carrier and ODTInvocationBuilder.
 * 
 * 
 * @author Sandip Panti
 *
 */

public final class AtomicCarrierLookup {

	private static AtomicCarrierLookup atomicCarrierLookup;
	private static Map<String, ODTInvocationBuilder> atomicCarrierMap = new HashMap<>();

	private static final String SHOP_ATOMIC_MAPPING_KEY = "ShopAtomicMapping";
	private static final String SHOP_ATOMIC_MAPPING_ACTUAL_VERSION = "ShopAtomicMapping_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(AtomicCarrierLookup.class);
	private static final long SIXTY_THOUSAND = 60000;
	
	private static long atomicCarrierCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp;    
	private static int supportedMapVersion;

	/*
	 * Block multiple instance of this CarrierLookup
	 */
	private AtomicCarrierLookup() {

	}

	static {
		try {
			final String rcUpdateFr = System.getenv ("CarrierRedisCacheUpdateFrequency");

			LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				atomicCarrierCacheUpdateFrequency = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug ("ATOMIC_CARRIER_CACHE_UPDATE_FREQUENCY value is : " + atomicCarrierCacheUpdateFrequency);
	}

	/**
	 * This method will update atomicCarrierMap if currentTimestamp - lastUpdateTimeStamp) > ATOMIC_CARRIER_CACHE_UPDATE_FREQUENCY and 
	 * supportedMapVersion < cachedVersion
	 */
	private static synchronized void updateMapIfRequired () {
		try {
			long currentTimestamp = System.currentTimeMillis ();
			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > atomicCarrierCacheUpdateFrequency) {
				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer cachedVersion = versionConnector.getValue (SHOP_ATOMIC_MAPPING_ACTUAL_VERSION);

				if (supportedMapVersion < cachedVersion) {
					loadCarrierMapping ();

					supportedMapVersion = cachedVersion;
				}

				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.info(ex);
			LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
		}
	}




	/**
	 * Get ODTInvocationBuilder by Primary carrier code
	 * @param carrierCode
	 * @return ODTInvocationBuilder
	 */
	public ODTInvocationBuilder getODTInvocationByPrimaryCarrier(String carrierCode) {
		updateMapIfRequired ();
		ODTInvocationBuilder odtInvocation = null;
		if(atomicCarrierMap.size() > 0){
			odtInvocation = atomicCarrierMap.get(carrierCode);

		}
		return odtInvocation;
	}



	/**
	 * Get PrimaryCarrierODTInvocationMap
	 * @return Map<String, ODTInvocationBuilder>
	 */
	public Map<String, ODTInvocationBuilder> getPrimaryCarrierODTInvocationMap() {
		updateMapIfRequired();
		if (atomicCarrierMap.size() > 0) {
			return atomicCarrierMap;

		}
		return null;
	}



	/**
	 * Load Translation XML
	 * @throws IOException
	 */
	private static void loadCarrierMapping() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(SHOP_ATOMIC_MAPPING_KEY);
		final InputStream inputStream = new ByteArrayInputStream(fileBytes);
		Map<String, ODTInvocationBuilder> atomicCarrierMapTemp = new HashMap<>();
		try {
			processDocument(inputStream, atomicCarrierMapTemp);
		} catch (FactoryConfigurationError | ParserConfigurationException | SAXException | IOException e) {
			LOGGER.error(e);

		} finally {
			inputStream.mark(1);
			final int bytesRead = inputStream.read(new byte[1]);
			inputStream.reset();
			if (bytesRead != -1) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					LOGGER.error(e1);
				}
			}
		}
	}

	/**
	 * Process Document from ShopAtomicMapping.xml
	 * @param inputStream
	 * @param carrierMapTemp
	 * @throws FactoryConfigurationError
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private static void processDocument(final InputStream inputStream, Map<String, ODTInvocationBuilder> carrierMapTemp)
			throws FactoryConfigurationError, ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setXIncludeAware(false);
		dbFactory.setExpandEntityReferences(false);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		LOGGER.debug(" set load-external-dtd as True.");
		dbFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);

		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document doc = builder.parse(inputStream);
		doc.getDocumentElement().normalize();
		NodeList primaryCarrierList = doc.getElementsByTagName("PrimaryCarrier");

		for (int count = 0; count < primaryCarrierList.getLength(); count++) {

			processPrimaryCarrierNode(carrierMapTemp, primaryCarrierList, count);
		}

		atomicCarrierMap.putAll (carrierMapTemp);

		if (inputStream != null) {
			inputStream.close();
		}
	}

	/**
	 * Process PrimaryCarrier Node from ShopAtomicMapping.xml
	 * @param carrierMapTemp
	 * @param primaryCarrierList
	 * @param count
	 */
	private static void processPrimaryCarrierNode(Map<String, ODTInvocationBuilder> carrierMapTemp, NodeList primaryCarrierList, int count) {
		Node primaryCarrierNode = primaryCarrierList.item(count);

		if (primaryCarrierNode != null && primaryCarrierNode.getNodeType() == Node.ELEMENT_NODE) {
			processODTInvocationBuilderElement(carrierMapTemp, primaryCarrierNode);
		}
	}

	/**
	 * Process processODTInvocation BuilderElement from ShopAtomicMapping.xml
	 * @param carrierMapTemp
	 * @param primaryCarrierNode
	 */
	private static void processODTInvocationBuilderElement(Map<String, ODTInvocationBuilder> carrierMapTemp,  Node primaryCarrierNode) {
		Element primaryCarrierElement = (Element) primaryCarrierNode;
		String primaryCarrier = primaryCarrierElement.getAttribute("Code");

		NodeList odtInvocationBuilderList = primaryCarrierElement.getElementsByTagName("ODTInvocationBuilder");
		for (int secCount = 0; secCount < odtInvocationBuilderList.getLength(); secCount++) {

			processODTInvocationBuilderNode(carrierMapTemp, odtInvocationBuilderList, secCount, primaryCarrier);
		}
	}

	/**
	 * Process ODTInvocationBuilder Node
	 * @param carrierMapTemp
	 * @param odtInvocationBuilderList
	 * @param secCount
	 * @param primaryCarrier
	 */
	private static void processODTInvocationBuilderNode(Map<String, ODTInvocationBuilder> carrierMapTemp, NodeList odtInvocationBuilderList, int secCount, String primaryCarrier) {
		Node odtInvocationBuilderNode = odtInvocationBuilderList.item(secCount);
		if (odtInvocationBuilderNode != null && odtInvocationBuilderNode.getNodeType() == Node.ELEMENT_NODE) {
			Element odtInvocationBuilderElement = (Element) odtInvocationBuilderNode;

			ODTInvocationBuilder odtInvocationBuilder = new ODTInvocationBuilder(odtInvocationBuilderElement.getAttribute("QName"), odtInvocationBuilderElement.getAttribute("LocalName"), odtInvocationBuilderElement.getAttribute("Action"), odtInvocationBuilderElement.getAttribute("SystemId"), odtInvocationBuilderElement.getAttribute("Version"));

			carrierMapTemp.put(primaryCarrier, odtInvocationBuilder);
		}
	}

	

	/*
	 * get a singleton instance
	 */
	public static synchronized AtomicCarrierLookup getInstance() {
		if (atomicCarrierLookup == null) {
			atomicCarrierLookup = new AtomicCarrierLookup();
		}
		return atomicCarrierLookup;

	}
}
