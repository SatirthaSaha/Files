/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.CarrierCurrency;


public final class CarrierCurrencyLookup {

	private static final String JCB = "JC";
	private static final String AMEX = "AX";
	private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
	private static final String ERROR = "ERROR";
	private static final String BLANK = "";
	private static CarrierCurrencyLookup carrierCurrencyLookup;
	private static Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardType = new HashMap<>();
	private static final String CARD_CARRIER_CURRENCY_UNSUPPORTED_KEY = "Card_Carrier_Currency_Unsupported";
	private static final String CARD_CARRIER_CURRENCY_UNSUPPORTED_VERSION = "Card_Carrier_Currency_Unsupported_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(CarrierCurrencyLookup.class);
	private static final long SIXTY_THOUSAND = 60000;
	
	private static long carrierCurrencyCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static final int TWO=2;
    private static long lastUpdateTimeStamp;    
    private static int supportedCurrencyMapVersion;
    
    /**
     * 
     */
    private CarrierCurrencyLookup() {

	}
    
    static {
        try {
            final String rcUpdateFr = System.getenv ("CarrierCurrencyRedisCacheUpdateFrequency");

            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

            if (cacheUpdateFrequency > 0) {
                carrierCurrencyCacheUpdateFrequency = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
        }

        LOGGER.debug ("CARRIER_CURRENCY_CACHE_UPDATE_FREQUENCY value is : " + carrierCurrencyCacheUpdateFrequency);
    }

    private static synchronized void updateMapIfRequired () {
        try {
            long currentTimestamp = System.currentTimeMillis ();
            // Do the update less frequently. We don't expect the cache to change every minute.
            if ((currentTimestamp - lastUpdateTimeStamp) > carrierCurrencyCacheUpdateFrequency) {
                final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
                final Integer cachedVersion = versionConnector.getValue (CARD_CARRIER_CURRENCY_UNSUPPORTED_VERSION);

                if (supportedCurrencyMapVersion < cachedVersion) {
                    loadCarrierCurrencyMappingFromCache ();

                    supportedCurrencyMapVersion = cachedVersion;
                }

                lastUpdateTimeStamp = currentTimestamp;
            }
        } catch (IOException ex) {
        	LOGGER.info(ex);
            LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
        }
    }
	
    /**
     * 
     * @param cardType
     * @return
     */
	public List<CarrierCurrency> getCarrierCurrencyPerCardType(String cardType) {
	    updateMapIfRequired ();
	    List<CarrierCurrency> carrierCurrencyList = Collections.emptyList();
		if(carrierCurrencyMapPerCardType!=null){
			carrierCurrencyList = carrierCurrencyMapPerCardType.get(cardType.toUpperCase(Locale.ENGLISH));
			
		}
		return carrierCurrencyList;
	}

	/**
	 * 
	 * @throws IOException
	 */
	private static void loadCarrierCurrencyMappingFromCache() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(CARD_CARRIER_CURRENCY_UNSUPPORTED_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		final List<CarrierCurrency> carrierCurrencyAXList = new ArrayList<>();
		final List<CarrierCurrency> carrierCurrencyJCList = new ArrayList<>();
		Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp = new HashMap<>();

		try {
			processWorkbookData(excelFileToRead, carrierCurrencyAXList, carrierCurrencyJCList,
					carrierCurrencyMapPerCardTypeTemp);
		} catch (IOException e1) {
            LOGGER.error("Error reading InputStream Retrieved From Redis Cache.", e1);
        }finally{
        	excelFileToRead.mark(1);
        	final int bytesRead = excelFileToRead.read(new byte[1]);
        	excelFileToRead.reset();
            if (bytesRead != -1) {
                try {
                    excelFileToRead.close();
                } catch (IOException e) {
                	LOGGER.info(e);
                }
            }
        }
	}

	/**
	 * 
	 * @param excelFileToRead
	 * @param carrierCurrencyAXList
	 * @param carrierCurrencyJCList
	 * @param carrierCurrencyMapPerCardTypeTemp
	 * @throws IOException
	 */
	private static void processWorkbookData(final InputStream excelFileToRead,
			final List<CarrierCurrency> carrierCurrencyAXList, final List<CarrierCurrency> carrierCurrencyJCList,
			Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp) throws IOException {
		XSSFWorkbook workbook;
		workbook = new XSSFWorkbook(excelFileToRead);
		//Since excelFileToRead creates workbook - null check for it
		excelFileToRead.mark(1);
    	final int bytesRead = excelFileToRead.read(new byte[1]);
    	excelFileToRead.reset();
		if (bytesRead != -1) {
			processSheetData(carrierCurrencyAXList, carrierCurrencyJCList, carrierCurrencyMapPerCardTypeTemp, workbook);
		}
	}

	/**
	 * 
	 * @param carrierCurrencyAXList
	 * @param carrierCurrencyJCList
	 * @param carrierCurrencyMapPerCardTypeTemp
	 * @param workbook
	 */
	private static void processSheetData(final List<CarrierCurrency> carrierCurrencyAXList,
			final List<CarrierCurrency> carrierCurrencyJCList,
			Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp, XSSFWorkbook workbook) {
		XSSFSheet sheet = workbook.getSheetAt(0);
   
		Iterator<Row> rowIterator = sheet.iterator();
   
		while (rowIterator.hasNext()) {
			processRowData(carrierCurrencyAXList, carrierCurrencyJCList, carrierCurrencyMapPerCardTypeTemp,
					rowIterator);
		}
		carrierCurrencyMapPerCardType.putAll (carrierCurrencyMapPerCardTypeTemp);
	}

	/**
	 * 
	 * @param carrierCurrencyAXList
	 * @param carrierCurrencyJCList
	 * @param carrierCurrencyMapPerCardTypeTemp
	 * @param rowIterator
	 */
	private static void processRowData(final List<CarrierCurrency> carrierCurrencyAXList,
			final List<CarrierCurrency> carrierCurrencyJCList,
			Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp, Iterator<Row> rowIterator) {
		Row row = rowIterator.next();
		if (row != null) {
			processCellData(carrierCurrencyAXList, carrierCurrencyJCList, carrierCurrencyMapPerCardTypeTemp, row);
		}
	}

	/**
	 * 
	 * @param carrierCurrencyAXList
	 * @param carrierCurrencyJCList
	 * @param carrierCurrencyMapPerCardTypeTemp
	 * @param row
	 */
	private static void processCellData(final List<CarrierCurrency> carrierCurrencyAXList,
			final List<CarrierCurrency> carrierCurrencyJCList,
			Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp, Row row) {
		if (getCellValue(row.getCell(0)).trim().length() == TWO) {
			CarrierCurrency carrierCurrency = new CarrierCurrency();
			carrierCurrency.setCardType(getCellValue(row.getCell(0)));
			carrierCurrency.setCarrier(getCellValue(row.getCell(1)));
			carrierCurrency.setCurrency(getCellValue(row.getCell(TWO)));
			if (StringUtils.isNotBlank(carrierCurrency.getCardType())
					&& StringUtils.isNotBlank(carrierCurrency.getCarrier())
					&& StringUtils.isNotBlank(carrierCurrency.getCurrency())) {
   
				populateCarrierCurrencyMap(carrierCurrency, carrierCurrencyAXList, carrierCurrencyJCList,carrierCurrencyMapPerCardTypeTemp);
   
			}
		}
	}

	/**
	 * 
	 * @param carrierCurrency
	 * @param carrierCurrencyAXList
	 * @param carrierCurrencyJCList
	 * @param carrierCurrencyMapPerCardTypeTemp
	 */
    protected static void populateCarrierCurrencyMap (CarrierCurrency carrierCurrency, List<CarrierCurrency> carrierCurrencyAXList,
            List<CarrierCurrency> carrierCurrencyJCList, Map<String, List<CarrierCurrency>> carrierCurrencyMapPerCardTypeTemp) {

		switch (carrierCurrency.getCardType()) {
		case AMEX:
			carrierCurrencyAXList.add(carrierCurrency);
			carrierCurrencyMapPerCardTypeTemp.put(carrierCurrency.getCardType().toUpperCase(Locale.ENGLISH), carrierCurrencyAXList);
			break;

		case JCB:
			carrierCurrencyJCList.add(carrierCurrency);
			carrierCurrencyMapPerCardTypeTemp.put(carrierCurrency.getCardType().toUpperCase(Locale.ENGLISH), carrierCurrencyJCList);
			break;
		default:
			LOGGER.debug("Getting default value..");
			break;
		}

	}

	/*
	 * reading cell values from spread sheet is tricky as it depends on the
	 * value a cell in the same column can have integer value as well as string
	 * value So this method helps to read values from a spread sheet cell
	 */
	protected static String getCellValue(Cell cell) {
		
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			LOGGER.debug("Getting boolean cell value..");
			return Boolean.toString(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			LOGGER.debug("Getting numeric cell value..");
			return Double.toString(cell.getNumericCellValue());
		default:
			return getCellData(cell);
		}
	
	}
	
	/*
	 * reading cell values from spread sheet is tricky as it depends on the
	 * value a cell in the same column can have integer value as well as string
	 * value So this method helps to read values from a spread sheet cell
	 */
	protected static String getCellData(Cell cell) {
		
		if(cell.getCellType()==Cell.CELL_TYPE_STRING){
			LOGGER.debug("Getting string cell value..");
			return cell.getStringCellValue().trim();
		}
		LOGGER.debug("Getting the cell data....");
		return getCellData1(cell);
	}
	
	/*
	 * reading cell values from spread sheet is tricky as it depends on the
	 * value a cell in the same column can have integer value as well as string
	 * value So this method helps to read values from a spread sheet cell
	 */
	protected static String getCellData1(Cell cell) {
		switch (cell.getCellType()) {

		case Cell.CELL_TYPE_BLANK:
			LOGGER.debug("Getting blank cell value..");
			return BLANK;
		case Cell.CELL_TYPE_ERROR:
			LOGGER.error("Cell type error");
			return ERROR;
		default:
			LOGGER.error("Could not read the data.");
			return COULD_NOT_READ_DATA;
		}
	}

	

	/**
	 * 
	 * @return
	 */
	public static synchronized CarrierCurrencyLookup getInstance() {
		if (carrierCurrencyLookup == null) {
			carrierCurrencyLookup = new CarrierCurrencyLookup();
		}
		return carrierCurrencyLookup;
	}
	
}
