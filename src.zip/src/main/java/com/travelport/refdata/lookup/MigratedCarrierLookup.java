/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.StringUtils;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

public final class MigratedCarrierLookup {

    private static final String MIGRATED_CARRIERS = "MC";
    private static final String NON_MIGRATED_CARRIERS = "NMC";
    private static final String NDC_CARRIERS = "NDC";
    private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
    private static final String ERROR = "ERROR";
    private static final String BLANK = "";
    protected static final String MIGRATED_CARRIER_MAP_KEY = "MigratedCarriersMapping";
    private static final String MIGRATED_CARRIER_MAP_VERSION_KEY = "MigratedCarriersMap_Version";
    private static volatile Map<String, List<String>> migratedNonMigratedNDCCarrierMap;  // Only a single map for all threads should work fine. 
    private static long lastUpdateTimeStamp; 
    private static final int TWO=2;
    private static final int SIXTY_THOUSAND=60000;
    private static long migratedCarrierMapCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
    private static int migratedCarriersMapVersion;
    private static final ACSLogger LOGGER = ACSLogger.getLogger (MigratedCarrierLookup.class);

    private MigratedCarrierLookup () {
    }
    
    static {
        try {
            final String rcUpdateFr = System.getenv ("MigratedCarrierRedisCacheUpdateFrequency");

            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

            if (cacheUpdateFrequency > 0) {
                migratedCarrierMapCacheUpdateFrequency = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
        }

        LOGGER.debug ("MIGRATED_CARRIER_MAP_CACHE_UPDATE_FREQUENCY value is : " + migratedCarrierMapCacheUpdateFrequency);
    }
    
    /**
     * 
     * @return
     */
    public static List<String> getMigratedCarriers () {
        updateMapIfRequired ();
        
        return migratedNonMigratedNDCCarrierMap.get (MIGRATED_CARRIERS);
    }

    /**
     * 
     * @return
     */
    public static List<String> getNonMigratedCarriers () {
        updateMapIfRequired ();

        return migratedNonMigratedNDCCarrierMap.get (NON_MIGRATED_CARRIERS);
    }
    
    /**
     * 
     * @return
     */
    public static List<String> getNDCCarriers () {
        updateMapIfRequired ();

        return migratedNonMigratedNDCCarrierMap.get (NDC_CARRIERS);
    }

    private static void loadCarriersFromCache () {
        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
        final byte[] fileBytes = connector.getValue (MIGRATED_CARRIER_MAP_KEY);
        final InputStream excelFileToRead = new ByteArrayInputStream (fileBytes);
        final List<String> migratedCarriers = new ArrayList<> ();
        final List<String> nonMigratedCarriers = new ArrayList<> ();
        final List<String> ndcCarriers = new ArrayList<> ();
        
        try {
            processWorkbookData(excelFileToRead, migratedCarriers, nonMigratedCarriers, ndcCarriers);
        } catch (IOException e) {
            LOGGER.error ("Error while reading Excel file", e);
            LOGGER.info(e);
        } finally {
            closeExcelFile (excelFileToRead);
        }
    }

    /**
     * 
     * @param excelFileToRead
     * @param migratedCarriers
     * @param nonMigratedCarriers
     * @param ndcCarriers
     * @throws IOException
     */
	private static void processWorkbookData(final InputStream excelFileToRead, final List<String> migratedCarriers,
			final List<String> nonMigratedCarriers, List<String> ndcCarriers) throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook (excelFileToRead);
		excelFileToRead.mark(1);
    	final int bytesRead = excelFileToRead.read(new byte[1]);
    	excelFileToRead.reset();
		if (bytesRead != -1) {
		    XSSFSheet sheet = workbook.getSheetAt (0);
		    Iterator<Row> rowIterator = sheet.iterator ();
		    rowIterator.next ();
		    
		    while (rowIterator.hasNext ()) {
		        processRowData(migratedCarriers, nonMigratedCarriers, ndcCarriers , rowIterator);
		    }

		    Map<String, List<String>> localMigratedNonMigratedNDCCarrierMap = new HashMap<> ();
		    
		    localMigratedNonMigratedNDCCarrierMap.put (MIGRATED_CARRIERS, migratedCarriers);
		    localMigratedNonMigratedNDCCarrierMap.put (NON_MIGRATED_CARRIERS, nonMigratedCarriers);
		    localMigratedNonMigratedNDCCarrierMap.put (NDC_CARRIERS, ndcCarriers);
		    
		    migratedNonMigratedNDCCarrierMap = localMigratedNonMigratedNDCCarrierMap;
		}
	}

	/**
	 * 
	 * @param migratedCarriers
	 * @param nonMigratedCarriers
	 * @param ndcCarriers
	 * @param rowIterator
	 */
	private static void processRowData(final List<String> migratedCarriers, final List<String> nonMigratedCarriers, List<String> ndcCarriers,
			Iterator<Row> rowIterator) {
		Row row = rowIterator.next ();

		if (row != null) {
		    processCellData(migratedCarriers, nonMigratedCarriers, ndcCarriers, row);
		}
	}

	/**
	 * 
	 * @param migratedCarriers
	 * @param nonMigratedCarriers
	 * @param ndcCarriers
	 * @param row
	 */
	private static void processCellData(final List<String> migratedCarriers, final List<String> nonMigratedCarriers, List<String> ndcCarriers,
			Row row) {
		if (row.getCell (0) != null && !StringUtils.isEmpty (getCellValue (row.getCell (0)).toUpperCase (Locale.ENGLISH))) {
		    migratedCarriers.add (getCellValue (row.getCell (0)).toUpperCase (Locale.ENGLISH));
		}

		if (row.getCell (1) != null && !StringUtils.isEmpty (getCellValue (row.getCell (1)).toUpperCase (Locale.ENGLISH))) {
		    nonMigratedCarriers.add (getCellValue (row.getCell (1)).toUpperCase (Locale.ENGLISH));
		}
		
		if (row.getCell (TWO) != null && !StringUtils.isEmpty (getCellValue (row.getCell (TWO)).toUpperCase (Locale.ENGLISH))) {
			ndcCarriers.add (getCellValue (row.getCell (TWO)).toUpperCase (Locale.ENGLISH));
		}
	}
	/**
	 * 
	 * @param excelFileToRead
	 */
    private static void closeExcelFile (InputStream excelFileToRead) {
    	LOGGER.debug("Closing the file..");
        if (excelFileToRead != null) {
            try {
                excelFileToRead.close ();
            } catch (IOException e) {
                LOGGER.error ("Error in reading file", e);
                LOGGER.info(e);
            }
        }
    }
    /**
     * 
     * @param cell
     * @return
     */
    protected static String getCellValue (Cell cell) {
    	LOGGER.debug("Getting the Boolean cell value ");
        switch (cell.getCellType ()) {
            case Cell.CELL_TYPE_BOOLEAN:
                return Boolean.toString (cell.getBooleanCellValue ());
            case Cell.CELL_TYPE_NUMERIC:
                return Double.toString (cell.getNumericCellValue ());
            
             default:
            	 LOGGER.debug("Processing cell data...");
            	 return getCellData(cell);
        }
    }
    
    /**
     * 
     * @param cell
     * @return
     */
    private static String getCellData (Cell cell) {
    	LOGGER.debug("Getting the String cell value");
    	if(cell.getCellType ()==Cell.CELL_TYPE_STRING)
    		return cell.getStringCellValue ().trim ();
         LOGGER.debug("Processing cell data...");
         return getCellData1(cell);       
    }
    
    /**
     * 
     * @param cell
     * @return
     */
    protected static String getCellData1 (Cell cell) {
    	LOGGER.debug("Getting the Blank cell value");
        switch (cell.getCellType ()) {
            case Cell.CELL_TYPE_BLANK:
                return BLANK;
            case Cell.CELL_TYPE_ERROR:
                return ERROR;
             default:
            	 LOGGER.debug("Could not read cell data...");
            	 return COULD_NOT_READ_DATA;
        }
        
    }

    

    private static synchronized void updateMapIfRequired () {
        try {
            long currentTimestamp = System.currentTimeMillis ();

            // Do the update less frequently. We don't expect the cache to change every minute.
            if ((currentTimestamp - lastUpdateTimeStamp) > migratedCarrierMapCacheUpdateFrequency) {
                final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
                final Integer cachedVersion = versionConnector.getValue (MIGRATED_CARRIER_MAP_VERSION_KEY);

                if (migratedCarriersMapVersion < cachedVersion) {
                    loadCarriersFromCache ();

                    migratedCarriersMapVersion = cachedVersion;
                }

                lastUpdateTimeStamp = currentTimestamp;
            }
        } catch (Exception ex) {
            LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
            LOGGER.info(ex);
        }
    }
}
