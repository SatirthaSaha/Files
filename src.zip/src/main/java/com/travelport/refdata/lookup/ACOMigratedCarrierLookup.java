/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.refdata.lookup;
 
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.StringUtils;
 
import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
 
public final class ACOMigratedCarrierLookup {
 
    private static final String MIGRATED_CARRIERS = "MC";
    private static final String NON_MIGRATED_CARRIERS = "NMC";
    private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
    private static final String BLANK = "";
    private static final String ACO_MIGRATED_CARRIER_MAP_KEY = "ACOMigratedCarriersMapping";
    private static final String ACO_MIGRATED_CARRIER_MAP_VERSION_KEY = "ACOMigratedCarriersMap_Version";
	private static final long SIXTY_THOUSAND = 60000;
    private static volatile Map<String, List<String>> migratedNonMigratedCarrierMap;  // Only a single map for all threads should work fine. 
    private static long lastUpdateTimeStamp;  
    
    private static long migratedCarrierMapCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
    private static int migratedCarriersMapVersion ;
    private static final ACSLogger LOGGER = ACSLogger.getLogger (ACOMigratedCarrierLookup.class);
 
    
    private ACOMigratedCarrierLookup(){
    	/*Constructor to clear
    	 * SONAR Issues*/
    }
    static {
        try {
        	LOGGER.debug("Loading environments");
            final String rcUpdateFr = System.getenv ("MigratedCarrierRedisCacheUpdateFrequency");
 
            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);
 
            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);
            //checking the cache update frequency
            if (cacheUpdateFrequency > 0) {
                migratedCarrierMapCacheUpdateFrequency = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
            LOGGER.info(nfe);
        }
 
        LOGGER.debug ("MIGRATED_CARRIER_MAP_CACHE_UPDATE_FREQUENCY value is : " + migratedCarrierMapCacheUpdateFrequency);
    }
    
    
    /**
     * getMigratedCarriers
     * @param
     * @return
     */
    public static List<String> getMigratedCarriers () {
    	LOGGER.debug("Update the map if required");
        updateMapIfRequired ();
        
        return migratedNonMigratedCarrierMap.get (MIGRATED_CARRIERS);
    }
 
    /**getNonMigratedCarriers
     * @param
     * @return
     */
    public static List<String> getNonMigratedCarriers () {
    	LOGGER.debug("Update the map if required");
    	updateMapIfRequired ();
 
        return migratedNonMigratedCarrierMap.get (NON_MIGRATED_CARRIERS);
    }
 
    /**
     * loadCarriersFromCache
     * @param
     * @return
     * @throws  
     */
    private static void loadCarriersFromCache ()   {
        final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector ();
        final byte[] fileBytes = connector.getValue (ACO_MIGRATED_CARRIER_MAP_KEY);
        final InputStream excelFileToRead = new ByteArrayInputStream (fileBytes);
        final List<String> migratedCarriers = new ArrayList<> ();
        final List<String> nonMigratedCarriers = new ArrayList<> ();
        
        try {
            XSSFWorkbook workbook = new XSSFWorkbook (excelFileToRead);
            excelFileToRead.mark(1);
        	final int bytesRead = excelFileToRead.read(new byte[1]);
        	excelFileToRead.reset();
            if (bytesRead != -1) {
                processWorkbookData(migratedCarriers, nonMigratedCarriers, workbook);
            }
        } catch (IOException e) {
            LOGGER.error ("Error while reading Excel file", e);
            LOGGER.info(e);
        } finally {
            closeExcelFile (excelFileToRead);
        }
    }

	/**
	 * processWorkbookData
	 * @param migratedCarriers
	 * @param nonMigratedCarriers
	 * @param workbook
	 * @return
	 * @throws
	 */
	private static void processWorkbookData(final List<String> migratedCarriers, final List<String> nonMigratedCarriers,
			XSSFWorkbook workbook) {
		LOGGER.debug("Processing Workbook data");
		XSSFSheet sheet = workbook.getSheetAt (0);
		Iterator<Row> rowIterator = sheet.iterator ();
		rowIterator.next ();
		LOGGER.debug("Processing the sheet from the workbook..");
		while (rowIterator.hasNext ()) {
		    processRowData(migratedCarriers, nonMigratedCarriers, rowIterator);
		}

		Map<String, List<String>> localMigratedNonMigratedCarrierMap = new HashMap<> ();
		
		//Putting values in map as required
		localMigratedNonMigratedCarrierMap.put (MIGRATED_CARRIERS, migratedCarriers);
		localMigratedNonMigratedCarrierMap.put (NON_MIGRATED_CARRIERS, nonMigratedCarriers);
		LOGGER.debug("Assigning maps from local sysytem..");
		migratedNonMigratedCarrierMap = localMigratedNonMigratedCarrierMap;
	}
	
	/**
	 * processRowData
	 * @param migratedCarriers
	 * @param nonMigratedCarriers
	 * @param rowIterator
	 * @return
	 * @throws
	 */
	private static void processRowData(final List<String> migratedCarriers, final List<String> nonMigratedCarriers,
			Iterator<Row> rowIterator) {
		LOGGER.debug("Processing row data for each data in the workbook");
		Row row = rowIterator.next ();

		if (row != null) {
			LOGGER.debug("Processing cell data for each row");
		    processCellData(migratedCarriers, nonMigratedCarriers, row);
		}
	}

	/**
	 * processCellData
	 * @param migratedCarriers
	 * @param nonMigratedCarriers
	 * @param row
	 * @return
	 * @throws
	 */
	private static void processCellData(final List<String> migratedCarriers, final List<String> nonMigratedCarriers,
			Row row) {
		LOGGER.debug("Processsing cell 1....");
		if (row.getCell (0) != null && !StringUtils.isEmpty (getCellValue (row.getCell (0)).toUpperCase (Locale.ENGLISH))) {
		    migratedCarriers.add (getCellValue (row.getCell (0)).toUpperCase (Locale.ENGLISH));
		}
		LOGGER.debug("Processsing cell 2....");
		if (row.getCell (1) != null && !StringUtils.isEmpty (getCellValue (row.getCell (1)).toUpperCase (Locale.ENGLISH))) {
		    nonMigratedCarriers.add (getCellValue (row.getCell (1)).toUpperCase (Locale.ENGLISH));
		}
	}

    /**
     * closeExcelFile
     * @param excelFileToRead
     * @return
     * @throws
     */
    private static void closeExcelFile (InputStream excelFileToRead) {
        if (excelFileToRead != null) {
            try {
            	LOGGER.debug("Closing the excel file");
                excelFileToRead.close ();
            } catch (IOException e) {
                LOGGER.error ("Error in reading file", e);
            }
        }
    }
    /**
     * getCellValue
     * @param cell
     * @return
     */
    protected static String getCellValue (Cell cell) {
        switch (cell.getCellType ()) {
            case Cell.CELL_TYPE_STRING:
                return cell.getStringCellValue ().trim ();
            case Cell.CELL_TYPE_BLANK:
                return BLANK;
               default:
            	   return COULD_NOT_READ_DATA;
        }
        
    }
   
 
    /**
     * updateMapIfRequired
     * @param
     * @return
     * @throws
     */
    private static synchronized void updateMapIfRequired () {
     
            long currentTimestamp = System.currentTimeMillis ();
 
            // Do the update less frequently. We don't expect the cache to change every minute.
            if ((currentTimestamp - lastUpdateTimeStamp) > migratedCarrierMapCacheUpdateFrequency) {
                final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
                final Integer cachedVersion = versionConnector.getValue (ACO_MIGRATED_CARRIER_MAP_VERSION_KEY);
 
                if (migratedCarriersMapVersion < cachedVersion) {
                    loadCarriersFromCache ();
 
                    migratedCarriersMapVersion = cachedVersion;
                }
 
                lastUpdateTimeStamp = currentTimestamp;
            }
     
    }
}
