/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.CollectionUtils;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.AirportGeoHierarchy;


public final class GeographyHierarchyUtil {

	private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
	private static final String ERROR = "ERROR";
	private static final String BLANK = "";
	private static GeographyHierarchyUtil geoHierarchyUtil;
	protected static Map<String, List<String>> cityAirportMap = new HashMap<>();
	protected static Map<String, AirportGeoHierarchy> airportGeoHierarchyMap = new HashMap<>();
	private static final String AIRPORT_GEO_HIERARCHY_KEY = "Airport_Geo_Hierarchy";
	private static final String AIRPORT_GEO_HIERARCHY_VERSION = "Airport_Geo_Hierarchy_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(GeographyHierarchyUtil.class);
	private static final int THREE=3;
	private static final int TWO=2;
	private static final int SIXTY_THOUSAND=60000;
	private static final int FIVE = 5;
	private static final int FOUR = 4;
	private static long geoHierarchyCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp;    
	private static int supportedCurrencyMapVersion;

	private GeographyHierarchyUtil() {

	}

	static {
		try {
			final String rcUpdateFr = System.getenv ("GeographyHierarchyRedisCacheUpdateFrequency");

			LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				geoHierarchyCacheUpdateFrequency = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug ("GEO_HIERARCHY_CACHE_UPDATE_FREQUENCY value is : " + geoHierarchyCacheUpdateFrequency);
	}


	/**
	 * 
	 * @throws IOException
	 */
	private static void loadAirportCityMapping() throws IOException  {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(AIRPORT_GEO_HIERARCHY_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		Map<String, List<String>> cityAirportMapTemp = new HashMap<>();
		Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp = new HashMap<>();
		excelFileToRead.mark(1);
		final int bytesRead = excelFileToRead.read(new byte[1]);
		excelFileToRead.reset();
		if (bytesRead != -1) {
			try {
				processWorkbookData(excelFileToRead, cityAirportMapTemp, airportGeoHierarchyMapTemp);

			} catch (IOException e) {
				LOGGER.error("Error while reading Excel file", e);
				throw e;
			} finally {
				closeExcelFile(excelFileToRead);
			}
		}
	}

	/**
	 * 
	 * @param excelFileToRead
	 * @param cityAirportMapTemp
	 * @param airportGeoHierarchyMapTemp
	 * @throws IOException
	 */
	private static void processWorkbookData(final InputStream excelFileToRead,
			Map<String, List<String>> cityAirportMapTemp, Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp)
					throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook(excelFileToRead);
		excelFileToRead.mark(1);
		final int bytesRead = excelFileToRead.read(new byte[1]);
		excelFileToRead.reset();
		if (bytesRead != -1) {
			processSheetData(cityAirportMapTemp, airportGeoHierarchyMapTemp, workbook);
		}
		cityAirportMap.putAll (cityAirportMapTemp);
		airportGeoHierarchyMap.putAll (airportGeoHierarchyMapTemp);
	}

	/**
	 * 
	 * @param cityAirportMapTemp
	 * @param airportGeoHierarchyMapTemp
	 * @param workbook
	 */
	private static void processSheetData(Map<String, List<String>> cityAirportMapTemp,
			Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp, XSSFWorkbook workbook) {
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) {
			processRowData(cityAirportMapTemp, airportGeoHierarchyMapTemp, rowIterator);
		}
	}

	/**
	 * 
	 * @param cityAirportMapTemp
	 * @param airportGeoHierarchyMapTemp
	 * @param rowIterator
	 */
	private static void processRowData(Map<String, List<String>> cityAirportMapTemp,
			Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp, Iterator<Row> rowIterator) {
		Row row = rowIterator.next();
		if (row != null && row.getCell(0) != null && getCellValue(row.getCell(0)).trim().length() == THREE) {
			processCellData(cityAirportMapTemp, airportGeoHierarchyMapTemp, row);
		}
	}

	/**
	 * 
	 * @param cityAirportMapTemp
	 * @param airportGeoHierarchyMapTemp
	 * @param row
	 */
	protected static void processCellData(Map<String, List<String>> cityAirportMapTemp,
			Map<String, AirportGeoHierarchy> airportGeoHierarchyMapTemp, Row row) {
		AirportGeoHierarchy geoHierarchy = populateAirportGeoHierarchy(row);
		if (StringUtils.isNotEmpty(geoHierarchy.getCityCode()) && StringUtils.isNotEmpty(geoHierarchy.getAirportCode())) {
			List<String> airportList = cityAirportMapTemp.get(geoHierarchy.getCityCode());
			if (airportList == null) {
				airportList = new ArrayList<>();
			}
			airportList.add(geoHierarchy.getAirportCode());
			cityAirportMapTemp.put(geoHierarchy.getCityCode(), airportList);
			airportGeoHierarchyMapTemp.put(geoHierarchy.getAirportCode(), geoHierarchy);
		}
	}

	/*
	 * scenario 1: fetch airport list using city code. In this case input in city code.
	 */
	/**
	 * 
	 * @param cityCode
	 * @return
	 */
	public List<String> getAirportsByCityCode(String cityCode){
		updateMapIfRequired ();

		if(cityAirportMap != null && !CollectionUtils.isEmpty(cityAirportMap.get(StringUtils.trimToEmpty(cityCode)))) {
			final List<String> cities = cityAirportMap.get(cityCode);
			return cities;
		}
		return Collections.emptyList();
	}

	/*
	 * scenario 2: fetch city code using  airport code.  In this case input in airport code.
	 */
	/**
	 * 
	 * @param airportCode
	 * @return
	 */
	public AirportGeoHierarchy getCityCodeByAirport(String airportCode){
		updateMapIfRequired ();
		AirportGeoHierarchy airportGeoHierarchy =null;
		if(airportGeoHierarchyMap != null){
			airportGeoHierarchy = airportGeoHierarchyMap.get(airportCode);
		}
		return airportGeoHierarchy;
	}

	/*
	 * scenario 3: check whether input is city code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public Boolean isCityCode(String code){
		updateMapIfRequired ();
		return cityAirportMap != null && !CollectionUtils.isEmpty(cityAirportMap.keySet()) &&
				cityAirportMap.keySet().contains(code.trim().toUpperCase(Locale.ENGLISH));
	}

	/*
	 * scenario 4: check whether input is airport code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public Boolean isAirportCode(String code){
		updateMapIfRequired ();
		return airportGeoHierarchyMap != null && !CollectionUtils.isEmpty(airportGeoHierarchyMap.keySet()) &&
				airportGeoHierarchyMap.keySet().contains(code.trim().toUpperCase(Locale.ENGLISH));
	}

	/**
	 * 
	 * @param airport
	 * @return
	 */
	public AirportGeoHierarchy getGeoDataByAirport(String airport) {
		updateMapIfRequired ();
		AirportGeoHierarchy airportGeoHierarchy = null;
		if(!StringUtils.isEmpty(StringUtils.trimToEmpty(airport)) && airportGeoHierarchyMap != null 
				&& !CollectionUtils.isEmpty(airportGeoHierarchyMap.keySet())) {
			airportGeoHierarchy = airportGeoHierarchyMap.get(airport.trim());
		}
		return airportGeoHierarchy;
	}

	/**
	 * 
	 * @param row
	 * @return
	 */
	private static AirportGeoHierarchy populateAirportGeoHierarchy(Row row) {
		AirportGeoHierarchy geoHierarchy = new AirportGeoHierarchy();
		geoHierarchy.setAirportCode(getCellValue(row.getCell(0)).toUpperCase(Locale.ENGLISH));
		geoHierarchy.setCityCode(getCellValue(row.getCell(1)).toUpperCase(Locale.ENGLISH));
		geoHierarchy.setStateCode(getCellValue(row.getCell(TWO)).toUpperCase(Locale.ENGLISH));
		geoHierarchy.setCountryCode(getCellValue(row.getCell(THREE)).toUpperCase(Locale.ENGLISH));
		geoHierarchy.setZoneId(getCellValue(row.getCell(FOUR)));
		geoHierarchy.setAreaCode(getCellValue(row.getCell(FIVE)).toUpperCase(Locale.ENGLISH));
		return geoHierarchy;
	}

	/**
	 * 
	 * @param excelFileToRead
	 */
	private static void closeExcelFile(InputStream excelFileToRead) {
		if (excelFileToRead != null){
			try {
				excelFileToRead.close();
			} catch (IOException e) {
				LOGGER.error("Error in reading file", e);
			}
		}
	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			int i = (int)cell.getNumericCellValue(); 
			return String.valueOf(i); 
		default:
			return getCellData(cell);
		}

	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellData(Cell cell) {
		if(cell.getCellType()==Cell.CELL_TYPE_STRING) {
			return cell.getStringCellValue().trim();
		}
		return getCellData1(cell);

	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellData1(Cell cell) {

		switch (cell.getCellType()) {

		case Cell.CELL_TYPE_BLANK:
			return BLANK;
		case Cell.CELL_TYPE_ERROR:
			return ERROR;
		default:
			return COULD_NOT_READ_DATA;
		}

	}

	

	/*
	 * get a singleton instance
	 */
	/**
	 * 
	 * @return
	 */
	public static synchronized GeographyHierarchyUtil getInstance() {

		if (geoHierarchyUtil == null) {
			geoHierarchyUtil = new GeographyHierarchyUtil();
		}
		return geoHierarchyUtil;

	}

	private static synchronized void updateMapIfRequired () {
		try {
			long currentTimestamp = System.currentTimeMillis ();

			// Do the update less frequently. We don't expect the cache to change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > geoHierarchyCacheUpdateFrequency) {

				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
				final Integer cachedVersion = versionConnector.getValue (AIRPORT_GEO_HIERARCHY_VERSION);

				if (supportedCurrencyMapVersion < cachedVersion) {
					loadAirportCityMapping ();

					supportedCurrencyMapVersion = cachedVersion;
				}

				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex);
		}
	}
}
