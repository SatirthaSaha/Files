/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.util.HashMap;
import java.util.Map;

public class PaymentTypeLookUp {

    private static PaymentTypeLookUp paymentTypeLookUp = null;

    private static final Map<String, String> paymentTypeMap = new HashMap<> ();
  //this needs to be moved to Redis cache in future
    static {
        paymentTypeMap.put("1 ","Cash");       
        paymentTypeMap.put("2 ","Direct bill");
        paymentTypeMap.put("3 ","Voucher");
        paymentTypeMap.put("4 ","Pre-pay");
        paymentTypeMap.put("5 ","Credit card");
        paymentTypeMap.put("6 ","Debit card");
        paymentTypeMap.put("7 ","Check");
        paymentTypeMap.put("8 ","Deposit");
        paymentTypeMap.put("9 ","Business account");
        paymentTypeMap.put("10","Central bill");
        paymentTypeMap.put("11","Coupon");
        paymentTypeMap.put("12","Business check");
        paymentTypeMap.put("13","Personal check");
        paymentTypeMap.put("14","Money order");
        paymentTypeMap.put("15","Redemption");
        paymentTypeMap.put("16","Barter");
        paymentTypeMap.put("17","Miscellaneous charge order");
        paymentTypeMap.put("18","Travel agency name/address");
        paymentTypeMap.put("19","Travel agency IATA number");
        paymentTypeMap.put("20","Certified check");
        paymentTypeMap.put("21","Club membership ID");
        paymentTypeMap.put("22","Frequent guest number");
        paymentTypeMap.put("23","Frequent traveler number");
        paymentTypeMap.put("24","Guest name/address");
        paymentTypeMap.put("25","Special industry program");
        paymentTypeMap.put("26","Tour order");
        paymentTypeMap.put("27","Traveler's check");
        paymentTypeMap.put("28","Wire payment");
        paymentTypeMap.put("29","Company name/address");
        paymentTypeMap.put("30","Corporate ID/CD number");
        paymentTypeMap.put("31","Guarantee");
        paymentTypeMap.put("32","Other information");
        paymentTypeMap.put("33","Override guarantee information");
        paymentTypeMap.put("34","Corporate");
        paymentTypeMap.put("35","Airline payment card");
        paymentTypeMap.put("36","Air travel card");
        paymentTypeMap.put("99","BSP Payment");
    }

    public String getpaymentTypevalue (String pmntCode) {
        return paymentTypeMap.get (pmntCode);
    }

    private PaymentTypeLookUp () {

    }

    public static synchronized PaymentTypeLookUp getInstance () {
        if (null == paymentTypeLookUp) {
            paymentTypeLookUp = new PaymentTypeLookUp ();
        }
        return paymentTypeLookUp;
    }
}
