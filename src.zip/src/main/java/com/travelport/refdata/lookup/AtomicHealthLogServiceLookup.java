/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

import java.util.Collections;


/**
 * AtomicHealthServiceLookup Based on a ref_data_atomic_health_log_service.xml
 * which contains supported operation and supported carrier for atomic-health-log-service
 * @author 743372
 *
 */
public final class AtomicHealthLogServiceLookup {

	private static AtomicHealthLogServiceLookup atomicHealthLogServiceLookupInstance;
	private static Map<String, List<String>> refDataAtomicHealthService = new HashMap<>();
	
	public static final String REF_DATA_MAPPING_KEY = "AtomicHealthLogServiceReferenceData";
	public static final String REF_DATA_ACTUAL_VERSION = "AtomicHealthLogServiceReferenceData_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(AtomicHealthLogServiceLookup.class);
	private static final long SIXTY_THOUSAND = 60000;
	private static long atomicHealthLogServiceCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
    private static long lastUpdateTimeStamp;    
    private static int refDataVersion;
    
    /*
	 * Block multiple instance of this AtomicHealthServiceLookup
	 */
	private AtomicHealthLogServiceLookup() {

	}
	
    static {
        try {
            final String rcUpdateFr = System.getenv ("AtomicHealthLogServiceRedisCacheUpdateFrequency");

            LOGGER.debug ("AtomicHealthLogServiceRedisCacheUpdateFrequency value is : " + rcUpdateFr);

            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

            if (cacheUpdateFrequency > 0) {
                atomicHealthLogServiceCacheUpdateFrequency = cacheUpdateFrequency;
            }
        } catch (NumberFormatException nfe) {
            LOGGER.warn ("Error while parsing AtomicHealthLogServiceRedisCacheUpdateFrequency env. Continuing with default value " + nfe);
        }

        LOGGER.debug ("ATOMIC_HEALTH_SERVICE_CACHE_UPDATE_FREQUENCY value is : " + atomicHealthLogServiceCacheUpdateFrequency);
    }
    
	/**
	 * This method will update refDataAtomicHealthService if currentTimestamp -
	 * lastUpdateTimeStamp) > ATOMIC_HEALTH_SERVICE_CACHE_UPDATE_FREQUENCY and
	 * refDataVersion < cachedVersion
	 */
	private static synchronized void updateMapIfRequired() {
		try {
			long currentTimestamp = System.currentTimeMillis();
			// Do the update less frequently. We don't expect the cache to
			// change every minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > atomicHealthLogServiceCacheUpdateFrequency) {
				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig
						.prepareIntegerRedisCacheConnector();
				final Integer cachedVersion = versionConnector.getValue(REF_DATA_ACTUAL_VERSION);
				if (refDataVersion < cachedVersion) {
					loadReferenceData();
					refDataVersion = cachedVersion;
				}
				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.info(ex);
			LOGGER.error("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage());
		}
	}

	
	/**
	 * @return
	 */
	public List<String> getSupportedOperationList() {
		updateMapIfRequired();
		return Collections.unmodifiableList(refDataAtomicHealthService.get("SUPPORTED_OPERATION"));
	}

	/**
	 * @return
	 */
	public List<String> getSupportedCarrierList() {
		updateMapIfRequired();
		return Collections.unmodifiableList(refDataAtomicHealthService.get("SUPPORTED_CARRIER"));
	}

	/**
	 * Load ReferenceData XML
	 * @throws IOException
	 */
	private static void loadReferenceData() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(REF_DATA_MAPPING_KEY);
		final InputStream inputStream = new ByteArrayInputStream(fileBytes);
		try {
			processDocument(inputStream);
		} catch (FactoryConfigurationError | ParserConfigurationException | SAXException | IOException e) {
			LOGGER.error(e);

		} finally {
			inputStream.mark(1);
			final int bytesRead = inputStream.read(new byte[1]);
			inputStream.reset();
			if (bytesRead != -1) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					LOGGER.error(e1);
				}
			}
		}
	}

	
	/**
	 * @param inputStream
	 * @throws FactoryConfigurationError
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private static void processDocument(final InputStream inputStream)
			throws FactoryConfigurationError, ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setXIncludeAware(false);
		dbFactory.setExpandEntityReferences(false);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		LOGGER.debug(" set load-external-dtd as True.");
		dbFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);

		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document doc = builder.parse(inputStream);
		doc.getDocumentElement().normalize();

		NodeList supportedCarrierNodeList = doc.getElementsByTagName("SupportedCarrier");
		List<String> supportedCarrierList = new ArrayList<>();

		for (int count = 0; count < supportedCarrierNodeList.getLength(); count++) {
			processSupportedCarrierNode(supportedCarrierList, supportedCarrierNodeList, count);
		}
		refDataAtomicHealthService.put("SUPPORTED_CARRIER", supportedCarrierList);
		NodeList supportedOperationNodeList = doc.getElementsByTagName("SupportedOperation");
		List<String> supportedOperationList = new ArrayList<>();

		for (int count = 0; count < supportedOperationNodeList.getLength(); count++) {
			processSupportedOperationNode(supportedOperationList, supportedOperationNodeList, count);
		}
		refDataAtomicHealthService.put("SUPPORTED_OPERATION", supportedOperationList);
		if (inputStream != null) {
			inputStream.close();
		}
	}
	
	/** Process SupportedCarrier Node from ref_data_atomic_health_log_service.xml
	 * @param supportedCarrierList
	 * @param supportedCarrierNodeList
	 * @param count
	 */
	private static void processSupportedCarrierNode(List<String> supportedCarrierList,
			NodeList supportedCarrierNodeList, int count) {
		//Node supportedCarrierNode = supportedCarrierNodeList.item(count);
		//Element supportedCarrierElement = (Element) supportedCarrierNode;
		Element supportedCarrierElement =processSupportedOperationOrCarrierNode(supportedCarrierNodeList,count);
		String primaryCarrier = supportedCarrierElement.getAttribute("Code");
		supportedCarrierList.add(primaryCarrier);
	}

	/**
	 * Process SupportedOperation Node from ref_data_atomic_health_log_service.xml
	 * 
	 * @param supportedOperationList
	 * @param supportedOperationNodeList
	 * @param count
	 */
	private static void processSupportedOperationNode(List<String> supportedOperationList,
			NodeList supportedOperationNodeList, int count) {
		//Node supportedOperationNode = supportedOperationNodeList.item(count);
		//Element supportedOperationElement = (Element) supportedOperationNode;
		Element supportedOperationElement =processSupportedOperationOrCarrierNode(supportedOperationNodeList,count);
		String supportedOperation = supportedOperationElement.getAttribute("Name");
		supportedOperationList.add(supportedOperation);
	}

	private static Element processSupportedOperationOrCarrierNode(NodeList supportedOperationOrCarrierNodeList,int count) {
		Node supportedCarrierOrOperationNode = supportedOperationOrCarrierNodeList.item(count);
		Element supportedCarrierOrOperationElement = (Element) supportedCarrierOrOperationNode;
		return supportedCarrierOrOperationElement;
	}
	

	/*
	 * get a singleton instance
	 */
	/**
	 * 
	 * @return
	 */
	public static synchronized AtomicHealthLogServiceLookup getInstance() {
		if (atomicHealthLogServiceLookupInstance == null) {
			atomicHealthLogServiceLookupInstance = new AtomicHealthLogServiceLookup();
		}
		return atomicHealthLogServiceLookupInstance;

	}
}
