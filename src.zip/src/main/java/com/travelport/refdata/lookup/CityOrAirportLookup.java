/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.CollectionUtils;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;
import com.travelport.refdata.models.CityOrAirport;


public final class CityOrAirportLookup {

	private static final String COULD_NOT_READ_DATA = "COULD NOT READ DATA";
	private static final String ERROR = "ERROR";
	private static final String BLANK = "";
	private static CityOrAirportLookup cityLookup;
	private static Map<String, List<CityOrAirport>> cityMap = new HashMap<>();
	private static Map<String, CityOrAirport> airportMap = new HashMap<>();
	private static final String AIRPORT_GEO_HIERARCHY_KEY = "Airport_Geo_Hierarchy";
	private static final String AIRPORT_GEO_HIERARCHY_VERSION = "Airport_Geo_Hierarchy_Version";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(CityOrAirportLookup.class);
	private static final long SIXTY_THOUSAND=60000;
	private static final int THREE=3;
	private static long cityOrAirportCacheUpdateFrequency = SIXTY_THOUSAND; // Update frequency can be modulated.
    private static long lastUpdateTimeStamp;    
    private static int supportedCurrencyMapVersion;
	
    private CityOrAirportLookup() {

	}
    
	 static {
	        try {
	            final String rcUpdateFr = System.getenv ("CityOrAirportRedisCacheUpdateFrequency");

	            LOGGER.debug ("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

	            long cacheUpdateFrequency = Long.parseLong (rcUpdateFr);

	            if (cacheUpdateFrequency > 0) {
	                cityOrAirportCacheUpdateFrequency = cacheUpdateFrequency;
	            }
	        } catch (NumberFormatException nfe) {
	            LOGGER.warn ("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
	        }

	        LOGGER.debug ("CITY_OR_AIRPORT_CACHE_UPDATE_FREQUENCY value is : " + cityOrAirportCacheUpdateFrequency);
	    }
	
	
	
	 private static synchronized void updateMapIfRequired () {
         try {
             long currentTimestamp = System.currentTimeMillis ();
             // Do the update less frequently. We don't expect the cache to change every minute.
             if ((currentTimestamp - lastUpdateTimeStamp) > cityOrAirportCacheUpdateFrequency) {
                 final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig.prepareIntegerRedisCacheConnector ();
                 final Integer cachedVersion = versionConnector.getValue (AIRPORT_GEO_HIERARCHY_VERSION);

                 if (supportedCurrencyMapVersion < cachedVersion) {
                     loadAirportCityMapping ();

                     supportedCurrencyMapVersion = cachedVersion;
                 }

                 lastUpdateTimeStamp = currentTimestamp;
             }
         } catch (Exception ex) {
        	 LOGGER.info(ex);
             LOGGER.error ("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage ());
         }
     }
	
	
	
	private static void loadAirportCityMapping() {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(AIRPORT_GEO_HIERARCHY_KEY);
		final InputStream excelFileToRead = new ByteArrayInputStream(fileBytes);
		Map<String, List<CityOrAirport>> cityMapTemp = new HashMap<>();
	    Map<String, CityOrAirport> airportMapTemp = new HashMap<>();
		try{
			processWorkbookData(excelFileToRead, cityMapTemp, airportMapTemp);
			
		} catch (IOException e) {
			LOGGER.error("Error while reading Excel file", e);
			LOGGER.info(e);
		} finally {
			closeExcelFile(excelFileToRead);
		}
	}


	/**
	 * 
	 * @param excelFileToRead
	 * @param cityMapTemp
	 * @param airportMapTemp
	 * @throws IOException
	 */
	private static void processWorkbookData(final InputStream excelFileToRead,
			Map<String, List<CityOrAirport>> cityMapTemp, Map<String, CityOrAirport> airportMapTemp)
			throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook(excelFileToRead);
		excelFileToRead.mark(1);
    	final int bytesRead = excelFileToRead.read(new byte[1]);
    	excelFileToRead.reset();
		if (bytesRead != -1) {
			processSheetData(cityMapTemp, airportMapTemp, workbook);
		}
		cityMap.putAll (cityMapTemp);
		airportMap.putAll (airportMapTemp);
	}


	/**
	 * 
	 * @param cityMapTemp
	 * @param airportMapTemp
	 * @param workbook
	 */
	private static void processSheetData(Map<String, List<CityOrAirport>> cityMapTemp,
			Map<String, CityOrAirport> airportMapTemp, XSSFWorkbook workbook) {
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) {
			processRowData(cityMapTemp, airportMapTemp, rowIterator);
		}
	}


	/**
	 * 
	 * @param cityMapTemp
	 * @param airportMapTemp
	 * @param rowIterator
	 */
	private static void processRowData(Map<String, List<CityOrAirport>> cityMapTemp,
			Map<String, CityOrAirport> airportMapTemp, Iterator<Row> rowIterator) {
		Row row = rowIterator.next();
		if(row != null && row.getCell(0)!= null && getCellValue(row.getCell(0)).trim().length() == THREE){
			processCellData(cityMapTemp, airportMapTemp, row);
		}
	}


	/**
	 * 
	 * @param cityMapTemp
	 * @param airportMapTemp
	 * @param row
	 */
	private static void processCellData(Map<String, List<CityOrAirport>> cityMapTemp,
			Map<String, CityOrAirport> airportMapTemp, Row row) {
		CityOrAirport cityCd = getCityCodeAirportCode(row);
		if( StringUtils.isNotEmpty(cityCd.getCityCode()) 
				&& StringUtils.isNotEmpty(cityCd.getAirportCode())) {
			List<CityOrAirport> cityAirportList = cityMapTemp.get(cityCd.getCityCode());
			if(cityAirportList == null){
				cityAirportList = new ArrayList<>(); 
			}
			cityAirportList.add(cityCd);
			cityMapTemp.put(cityCd.getCityCode(), cityAirportList);
			airportMapTemp.put(cityCd.getAirportCode(), cityCd);
		}
	}

	/*
	 * scenario 1: fetch airport list using city code. In this case input in city code.
	 */
	/**
	 * 
	 * @param cityCode
	 * @return
	 */
	public List<CityOrAirport> getAirportsByCityCode(String cityCode){

	    updateMapIfRequired();
	    
		if(cityMap != null){
			final List<CityOrAirport> cityList = cityMap.get(cityCode);
			return cityList;
		}
		return Collections.emptyList();
	}

	/*
	 * scenario 2: fetch city code using  airport code.  In this case input in airport code.
	 */
	/**
	 * 
	 * @param airportCode
	 * @return
	 */
	public CityOrAirport getCityCodeByAirport(String airportCode){

	    updateMapIfRequired();
	     CityOrAirport cityOrAirport =null;
	    if(airportMap != null){
			cityOrAirport = airportMap.get(airportCode);
			
		}
	    return cityOrAirport;
	}

	/*
	 * scenario 3: check whether input is city code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public Boolean isCityCode(String code){

	    updateMapIfRequired();
	   return cityMap != null && !CollectionUtils.isEmpty(cityMap.keySet()) &&
				cityMap.keySet().contains(code.trim().toUpperCase(Locale.ENGLISH));
	}

	/*
	 * scenario 4: check whether input is airport code
	 */
	/**
	 * 
	 * @param code
	 * @return
	 */
	public Boolean isAirportCode(String code){
	    
	    updateMapIfRequired();
	   return airportMap != null && !CollectionUtils.isEmpty(airportMap.keySet()) &&
				airportMap.keySet().contains(code.trim().toUpperCase(Locale.ENGLISH));
	}

	/**
	 * 
	 * @param row
	 * @return
	 */
	private static CityOrAirport getCityCodeAirportCode(Row row) {
		CityOrAirport cityCd = new CityOrAirport();	
		cityCd.setAirportCode(getCellValue(row.getCell(0)).toUpperCase(Locale.ENGLISH));
		cityCd.setCityCode(getCellValue(row.getCell(1)).toUpperCase(Locale.ENGLISH));
		cityCd.setCountryCode(getCellValue(row.getCell(THREE)).toUpperCase(Locale.ENGLISH));
		return cityCd;
	}

	/**
	 * 
	 * @param excelFileToRead
	 */
	private static void closeExcelFile(InputStream excelFileToRead) {
		if (excelFileToRead != null){
			try {
				excelFileToRead.close();
			} catch (IOException e) {
				LOGGER.error("Error in reading file", e);
			}
		}
	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellValue(Cell cell) {
		
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			return Double.toString(cell.getNumericCellValue());
		
		default:
			
			return getCellData(cell);
		}
	
	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellData(Cell cell) {
		LOGGER.debug("Retrieving cell value");
		if(cell.getCellType()==Cell.CELL_TYPE_STRING)
			return cell.getStringCellValue().trim();
		return getCellData1(cell);

	}
	
	/**
	 * 
	 * @param cell
	 * @return
	 */
	protected static String getCellData1(Cell cell) {
		
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BLANK:
			return BLANK;
		case Cell.CELL_TYPE_ERROR:
			return ERROR;
		default:
			return COULD_NOT_READ_DATA;
		}

	}
	

	/*
	 * get a singleton instance
	 */
	/**
	 * 
	 * @return
	 */
	public static synchronized CityOrAirportLookup getInstance() {
		if (cityLookup == null) {
			cityLookup = new CityOrAirportLookup();
		}
		return cityLookup;

	}
	
}
