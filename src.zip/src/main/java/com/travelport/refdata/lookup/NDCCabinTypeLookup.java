/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.util.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.redis.connector.InputStreamRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.IntegerRedisCacheConnectorImpl;
import com.travelport.acs.redis.connector.utils.RedisConnectorConfig;

/**
 * NDCCabinTypeLookup Based on a mapping XML which contains mapping of
 * Carrier and Cabin Type
 * 
 * @author Indranil.Ghosh
 *
 */
public class NDCCabinTypeLookup {

	private static NDCCabinTypeLookup ndcCabinTypeLookup;
	private static final String NDC_CABIN_TYPE_MAPPING_KEY = "NDCCabinTypeMapping";
	private static final String NDC_CABIN_TYPE_MAPPING_VERSION_KEY = "NDCCabinTypeMapping_Version";
	private static Map<String, Map<String, String>> ndcCarrierMap = new HashMap<>();
	private static long _NDC_CABIN_TYPE_CACHE_UPDATE_FREQUENCY = 60000; // Update frequency can be modulated.
	private static long lastUpdateTimeStamp;
	private static int ndcCabinTypeMappingVersion = 0;
	private static final ACSLogger LOGGER = ACSLogger.getLogger(NDCCabinTypeLookup.class);

	static {
		try {
			final String rcUpdateFr = System.getenv("NDCCabinTypeRedisCacheUpdateFrequency");

			LOGGER.debug("RedisCacheUpdateFrequency value is : " + rcUpdateFr);

			long cacheUpdateFrequency = Long.parseLong(rcUpdateFr);

			if (cacheUpdateFrequency > 0) {
				_NDC_CABIN_TYPE_CACHE_UPDATE_FREQUENCY = cacheUpdateFrequency;
			}
		} catch (NumberFormatException nfe) {
			LOGGER.warn("Error while parsing RedisCacheUpdateFrequency env. Continuing with default value " + nfe);
		}

		LOGGER.debug("ORIGIN_APPID_CACHE_UPDATE_FREQUENCY value is : " + _NDC_CABIN_TYPE_CACHE_UPDATE_FREQUENCY);
	}

	/**
	 * Block multiple instance of this NDCCabinTypeLookUp
	 */
	private NDCCabinTypeLookup() {

	}

	/**
	 * get cabin Code from Cabin code from cabin type for a specific carrier
	 */
	public String getCabinCodeFromCabinType(String carrierCode, String cabinType) {
		String cabinCode = null;
		updateMapIfRequired();
		Map<String, String> cabinCodeTypeMap = Collections.emptyMap();
		if (ndcCarrierMap != null) {
			cabinCodeTypeMap = ndcCarrierMap.get(carrierCode);
			cabinCode = cabinCodeTypeMap.get(cabinType);
		}
		return cabinCode;
	}
	
	
	/**
	 * get All cabin Code for a specific carrier
	 * 
	 * 
	 * @param carrierCode
	 * @return
	 */
	public List<String> getAllCabinCodeFromCarrierCode(String carrierCode) {
        List<String> cabinCodeList = null;
        updateMapIfRequired();
        Map<String, String> cabinCodeTypeMap = Collections.emptyMap();
        if (ndcCarrierMap != null) {
            cabinCodeTypeMap = ndcCarrierMap.get(carrierCode);
            cabinCodeList = cabinCodeTypeMap.values ().stream ().collect (Collectors.toList ());
        }
        return cabinCodeList;
    }

	/**
	 * Load Translation XML
	 */
	private static void loadCarrierMapping() throws IOException {
		final InputStreamRedisCacheConnectorImpl connector = RedisConnectorConfig
				.prepareInputStreamRedisCacheConnector();
		final byte[] fileBytes = connector.getValue(NDC_CABIN_TYPE_MAPPING_KEY);
		final InputStream inputStream = new ByteArrayInputStream(fileBytes);
		Map<String, Map<String, String>> ndcCarrierMapTemp = new HashMap<>();
		try {
			processDocument(inputStream, ndcCarrierMapTemp);
		} catch (Exception e) {
			LOGGER.info(e);

		} finally {
			inputStream.mark(1);
			final int bytesRead = inputStream.read(new byte[1]);
			inputStream.reset();
			if (bytesRead != -1) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					LOGGER.info(e1);
				}
			}
		}
	}
	
	/**
	 * Processing XML Document Extracted from CabinTypeMapping.xml file
	 */
	private static void processDocument(InputStream inputStream, Map<String, Map<String, String>> ndcCarrierMapTemp)
			throws FactoryConfigurationError, ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setXIncludeAware(false);
		dbFactory.setExpandEntityReferences(false);
		dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		LOGGER.debug(" set load-external-dtd as True.");
		dbFactory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);

		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document doc = builder.parse(inputStream);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("PrimaryCarrier");

		for (int count = 0; count < nList.getLength(); count++) {

			processNode(ndcCarrierMapTemp, nList, count);
		}

		ndcCarrierMap.putAll(ndcCarrierMapTemp);

		if (inputStream != null) {
			inputStream.close();
		}
	}
	/**
	 * Processing each Node of XML Document 
	 */

	private static void processNode(Map<String, Map<String, String>> ndcCarrierMapTemp, NodeList nList, int count) {
		// TODO Auto-generated method stub
		Node nNode = nList.item(count);
		Map<String, String> cabinTypeCabinCodeMap = new HashMap<>();

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			processElement(ndcCarrierMapTemp, nNode, cabinTypeCabinCodeMap);
		}
	}

	/**
	 * retrieving element of each Node
	 */
	private static void processElement(Map<String, Map<String, String>> ndcCarrierMapTemp, Node nNode,
			Map<String, String> cabinTypeCabinCodeMap) {
		// TODO Auto-generated method stub
		Element eElement = (Element) nNode;
		NodeList secList = eElement.getElementsByTagName("TranslationData");
		for (int secCount = 0; secCount < secList.getLength(); secCount++) {

			processCabinNode(cabinTypeCabinCodeMap, secList, secCount);
		}
		if (!CollectionUtils.isEmpty(cabinTypeCabinCodeMap)) {
			ndcCarrierMapTemp.put(eElement.getAttribute("Code"), cabinTypeCabinCodeMap);
		}
	}

	/**
	 * Set each attribute of the element in Map
	 */
	private static void processCabinNode(Map<String, String> cabinTypeCabinCodeMap, NodeList secList, int secCount) {
		// TODO Auto-generated method stub
		Node secNode = secList.item(secCount);
		if (secNode != null && secNode.getNodeType() == Node.ELEMENT_NODE) {
			Element secElement = (Element) secNode;
			cabinTypeCabinCodeMap.put(secElement.getAttribute("CabinType"), secElement.getAttribute("CabinCode"));
		}
	}

	/**
	 * get a singleton instance
	 */
	public static synchronized NDCCabinTypeLookup getInstance() {
		if (ndcCabinTypeLookup == null) {
			ndcCabinTypeLookup = new NDCCabinTypeLookup();
		}
		return ndcCabinTypeLookup;
	}

	private static synchronized void updateMapIfRequired() {
		try {
			long currentTimestamp = System.currentTimeMillis();

			// Do the update less frequently. We don't expect the cache to change every
			// minute.
			if ((currentTimestamp - lastUpdateTimeStamp) > _NDC_CABIN_TYPE_CACHE_UPDATE_FREQUENCY) {
				final IntegerRedisCacheConnectorImpl versionConnector = RedisConnectorConfig
						.prepareIntegerRedisCacheConnector();
				final Integer cachedVersion = versionConnector.getValue(NDC_CABIN_TYPE_MAPPING_VERSION_KEY);

				if (ndcCabinTypeMappingVersion < cachedVersion) {
					loadCarrierMapping();

					ndcCabinTypeMappingVersion = cachedVersion;
				}

				lastUpdateTimeStamp = currentTimestamp;
			}
		} catch (IOException ex) {
			LOGGER.error("Redis connectivity error. Continuing with previous cached value. : " + ex.getMessage());
			LOGGER.info(ex);
		}
	}
}
