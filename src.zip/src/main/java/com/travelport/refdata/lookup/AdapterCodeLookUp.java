/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.lookup;

import java.util.HashMap;
import java.util.Map;

public final class AdapterCodeLookUp {

    protected static AdapterCodeLookUp adapterCodeLookUp;

    private static final Map<String, String> carrierAdaptorCodeMap = new HashMap<> ();
    
    private AdapterCodeLookUp () {

    }
    
    //this needs to be moved to Redis cache in future
    static {
        carrierAdaptorCodeMap.put ("6E", "NNS6E");
        carrierAdaptorCodeMap.put ("AA", "FLXAA");
        carrierAdaptorCodeMap.put ("DC", "FLDAC");
        carrierAdaptorCodeMap.put ("AC", "FLPAC");
        carrierAdaptorCodeMap.put ("AK", "NNSAK");
        carrierAdaptorCodeMap.put ("DL", "DALDL");
        carrierAdaptorCodeMap.put ("EI", "CCHEI");
        carrierAdaptorCodeMap.put ("FR", "NNSFR");
        carrierAdaptorCodeMap.put ("HV", "NNSHV");
        carrierAdaptorCodeMap.put ("JQ", "NNSJQ");
        carrierAdaptorCodeMap.put ("JM", "NNSJX");
        carrierAdaptorCodeMap.put ("LS", "JETLS");
        carrierAdaptorCodeMap.put ("TO", "NNSTO");
        carrierAdaptorCodeMap.put ("U2", "ERSU2");
        carrierAdaptorCodeMap.put ("UA", "UALUA");
        carrierAdaptorCodeMap.put ("WN", "SGSWN");
        carrierAdaptorCodeMap.put ("WS", "FLXWS");
    }

    /**
     * 
     * @param carrierCode
     * @return
     */
    public String getAdaptorCodeByCarrierCode (String carrierCode) {
        return carrierAdaptorCodeMap.get (carrierCode);
    }

    
    /**
     * 
     * @return
     */
    public static synchronized AdapterCodeLookUp getInstance () {
        if (null == adapterCodeLookUp) {
            adapterCodeLookUp = new AdapterCodeLookUp ();
        }
        
        return adapterCodeLookUp;
    }
}
