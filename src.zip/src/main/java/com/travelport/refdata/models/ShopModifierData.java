/* Copyright (c) 2017 Travelport. All rights reserved. */
package com.travelport.refdata.models;

import java.io.Serializable;

/**
 * This is a pojo class to hold value for all the applicable modifiers. The
 * string value can be T1,T2,T3 or T4. This class is required during Modifier
 * lookup.
 * 
 *
 */
@SuppressWarnings("serial")
public class ShopModifierData implements Serializable {

	private String nonStopDirect;
	private String stopDirect;
	private String singleConnection;
	private String doubleConnection;
	private String noAdvancePurchase;
	private String noMinimumStay;
	private String noMaximumStay;
	private String noPenalty;
	private String equivalentCurrency;
	private String publicFares;
	private String privateFares;
	private String  publicAndPrivateFares;
	private String netFares;
	private String excludeGround;
	private String cabinPreferencePermitted;
	private String cabinPreferencePreferred;
	private String airlinePreferencePermitted;
	private String airlinePreferenceProhibited;
	private String airlinePreferencePreferred;
	private String ptcType;
	private String prohibitChangeOfAirport;
	private String maxConnectionDuration;
	private String maxOvernightDuration;
	private String excludeInterlineConnections;
	private String accountCode;
	private String carrier;
	
	
	public String getCarrier() {
		return carrier;
	}
	
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getNonStopDirect() {
		return nonStopDirect;
	}

	public void setNonStopDirect(String nonStopDirect) {
		this.nonStopDirect = nonStopDirect;
	}

	public String getStopDirect() {
		return stopDirect;
	}

	public void setStopDirect(String stopDirect) {
		this.stopDirect = stopDirect;
	}

	public String getSingleConnection() {
		return singleConnection;
	}

	public void setSingleConnection(String singleConnection) {
		this.singleConnection = singleConnection;
	}

	public String getDoubleConnection() {
		return doubleConnection;
	}

	public void setDoubleConnection(String doubleConnection) {
		this.doubleConnection = doubleConnection;
	}

	public String getNoAdvancePurchase() {
		return noAdvancePurchase;
	}

	public void setNoAdvancePurchase(String noAdvancePurchase) {
		this.noAdvancePurchase = noAdvancePurchase;
	}

	public String getNoMinimumStay() {
		return noMinimumStay;
	}

	public void setNoMinimumStay(String noMinimumStay) {
		this.noMinimumStay = noMinimumStay;
	}

	public String getNoMaximumStay() {
		return noMaximumStay;
	}

	public void setNoMaximumStay(String noMaximumStay) {
		this.noMaximumStay = noMaximumStay;
	}

	public String getNoPenalty() {
		return noPenalty;
	}

	public void setNoPenalty(String noPenalty) {
		this.noPenalty = noPenalty;
	}

	public String getEquivalentCurrency() {
		return equivalentCurrency;
	}

	public void setEquivalentCurrency(String equivalentCurrency) {
		this.equivalentCurrency = equivalentCurrency;
	}

	public String getPublicFares() {
		return publicFares;
	}

	public void setPublicFares(String publicFares) {
		this.publicFares = publicFares;
	}

	public String getPrivateFares() {
		return privateFares;
	}

	public void setPrivateFares(String privateFares) {
		this.privateFares = privateFares;
	}

	public String getNetFares() {
		return netFares;
	}

	public void setNetFares(String netFares) {
		this.netFares = netFares;
	}

	public String getExcludeGround() {
		return excludeGround;
	}

	public void setExcludeGround(String excludeGround) {
		this.excludeGround = excludeGround;
	}

	public String getCabinPreferencePermitted() {
		return cabinPreferencePermitted;
	}

	public void setCabinPreferencePermitted(String cabinPreferencePermitted) {
		this.cabinPreferencePermitted = cabinPreferencePermitted;
	}

	public String getCabinPreferencePreferred() {
		return cabinPreferencePreferred;
	}

	public void setCabinPreferencePreferred(String cabinPreferencePreferred) {
		this.cabinPreferencePreferred = cabinPreferencePreferred;
	}

	public String getAirlinePreferencePermitted() {
		return airlinePreferencePermitted;
	}

	public void setAirlinePreferencePermitted(String airlinePreferencePermitted) {
		this.airlinePreferencePermitted = airlinePreferencePermitted;
	}

	public String getAirlinePreferenceProhibited() {
		return airlinePreferenceProhibited;
	}

	public void setAirlinePreferenceProhibited(String airlinePreferenceProhibited) {
		this.airlinePreferenceProhibited = airlinePreferenceProhibited;
	}

	public String getAirlinePreferencePreferred() {
		return airlinePreferencePreferred;
	}

	public void setAirlinePreferencePreferred(String airlinePreferencePreferred) {
		this.airlinePreferencePreferred = airlinePreferencePreferred;
	}

	public String getPtcType() {
		return ptcType;
	}

	public void setPtcType(String ptcType) {
		this.ptcType = ptcType;
	}

	public String getProhibitChangeOfAirport() {
		return prohibitChangeOfAirport;
	}

	public void setProhibitChangeOfAirport(String prohibitChangeOfAirport) {
		this.prohibitChangeOfAirport = prohibitChangeOfAirport;
	}

	public String getMaxConnectionDuration() {
		return maxConnectionDuration;
	}

	public void setMaxConnectionDuration(String maxConnectionDuration) {
		this.maxConnectionDuration = maxConnectionDuration;
	}

	public String getMaxOvernightDuration() {
		return maxOvernightDuration;
	}

	public void setMaxOvernightDuration(String maxOvernightDuration) {
		this.maxOvernightDuration = maxOvernightDuration;
	}

	public String getExcludeInterlineConnections() {
		return excludeInterlineConnections;
	}

	public void setExcludeInterlineConnections(String excludeInterlineConnections) {
		this.excludeInterlineConnections = excludeInterlineConnections;
	}

	public String getAccountCode() {
		return accountCode;
	}

	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	public String getPublicAndPrivateFares() {
		return publicAndPrivateFares;
	}

	public void setPublicAndPrivateFares(String publicAndPrivateFares) {
		this.publicAndPrivateFares = publicAndPrivateFares;
	}
}
