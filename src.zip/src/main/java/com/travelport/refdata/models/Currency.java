/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.models;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Currency implements Serializable{
	
	private String airportCode;
	private String airportName;
	private String currencyCode;
	
	public Currency(){
		/*Constructor to clear sonar issues*/
	}
	
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	private int currencyDecimal;
	private double currencyRoundUnit;
	private String currencyRoundAction;
	
	public String getAirportCode() {
		return airportCode;
	}
	public void setAirportCode(String airportCode) {
		this.airportCode = airportCode;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	
	public int getCurrencyDecimal() {
		return currencyDecimal;
	}
	public void setCurrencyDecimal(int currencyDecimal) {
		this.currencyDecimal = currencyDecimal;
	}
	public double getCurrencyRoundUnit() {
		return currencyRoundUnit;
	}
	public void setCurrencyRoundUnit(double currencyRoundUnit) {
		this.currencyRoundUnit = currencyRoundUnit;
	}
	public String getCurrencyRoundAction() {
		return currencyRoundAction;
	}
	public void setCurrencyRoundAction(String currencyRoundAction) {
		this.currencyRoundAction = currencyRoundAction;
	}	

}
