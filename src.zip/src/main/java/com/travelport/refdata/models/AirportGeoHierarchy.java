/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.models;

import java.io.Serializable;

public class AirportGeoHierarchy implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 529325430415273814L;
	private String airportCode;
	private String cityCode;
	private String stateCode;
	private String countryCode;
	private String zoneId;
	private String areaCode;
	
	public String getAirportCode() {
		return airportCode;
	}
	public void setAirportCode(String airportCode) {
		this.airportCode = airportCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getZoneId() {
		return zoneId;
	}
	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

}