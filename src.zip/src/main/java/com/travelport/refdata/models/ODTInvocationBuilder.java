/* Copyright (c) 2017 Travelport. All rights reserved. */
package com.travelport.refdata.models;

/**
 * This is a pojo class 
 * to hold value for qName, localName, action, systemId, version
 * @author sandip panti
 *
 */
public class ODTInvocationBuilder {
	private String qName;
	private String localName;
	private String action;
	private String systemId;
	private String version;

	public ODTInvocationBuilder(String qName, String localName, String action, String systemId, String version){
		this.qName = qName;
		this.localName = localName;
		this.action = action;
		this.systemId = systemId;
		this.version = version;
	}
	
	/**
	 * getqName
	 * @return qName
	 */
	public String getqName() {
		return qName;
	}

	/**
	 * setqName
	 * @param qName
	 */
	public void setqName(String qName) {
		this.qName = qName;
	}

	/**
	 * @return localName
	 */
	public String getLocalName() {
		return localName;
	}

	/**
	 * @param localName
	 */
	public void setLocalName(String localName) {
		this.localName = localName;
	}

	/**
	 * @return action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return systemId
	 */
	public String getSystemId() {
		return systemId;
	}


	/**
	 * @param systemId
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}


	/**
	 * @return version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version
	 */
	public void setVersion(String version) {
		this.version = version;
	}
}
