/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.models;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CityOrAirport implements Serializable{
	
	private String airportCode;
	private String cityCode;
	private String countryCode;
	
	public String getAirportCode() {
		return airportCode;
	}
	public void setAirportCode(String airportCode) {
		this.airportCode = airportCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

}
