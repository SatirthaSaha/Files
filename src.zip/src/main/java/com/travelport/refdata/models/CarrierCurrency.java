/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.refdata.models;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CarrierCurrency implements Serializable {

	private String cardType;
	private String carrier;
	private String currency;
	
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
}
