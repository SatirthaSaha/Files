/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.resman.atomic.error;

import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.model.common.Result;
import com.travelport.model.common.Error;
import com.travelport.model.common.Warning;
import com.travelport.odt.atf.DataFormatType;
import com.travelport.odt.atf.TransformationException;
import com.travelport.odt.atf.binding.model.Identifier;
import com.travelport.odt.atf.util.KLRUtil;
/**
 * 
 * @author Priyasmita.Gupta
 *
 */
public class KLRErrorHandler {
	
	private static final Integer START_INDEX_SESSION_ERROR_CODE = 14;
	private static final Integer START_INDEX_PROCEDURE_ERROR_CODE = 4;
	private static final String ERROR_BLOCK_2031 = "2031";
	private static final String ERROR_BLOCK_2157 = "2157";
	private static final Integer ETO2_MESSAGE_START_INDEX = 22;
	private static final Integer CCEV_MESSAGE_START_INDEX = 16;
	private static final Identifier ERR_IDENTIFIER_ET_ETO1 = new Identifier("ETO1", "09", DataFormatType.KLR);
	private static final Identifier ERR_IDENTIFIER_ET_ETO2 = new Identifier("ETO2", "09", DataFormatType.KLR);
	private static final Identifier ERR_IDENTIFIER_CCEV = new Identifier("CCEV", "01", DataFormatType.KLR);
	private static final Integer INDICATOR_POSITION_ETO1 = 32;
	private static final Integer FIRST_ELEMENT = 0;
	private static final Character WARNING_INDICATOR = 'W';
	private static final Character ERROR_INDICATOR = 'E';
	private static final ACSLogger LOGGER = ACSLogger.getLogger(KLRErrorHandler.class);
	private static final String CCEV_ERROR_INDICATOR = "MANDATORY";
	private static final String CCEV_WARNING_INDICATOR = "WARNING";
	
	private KLRErrorHandler() {
		
	}
	
	/**
	 * 
	 * @param klr
	 * @param errorString
	 * @param startIndex
	 * @return
	 */
	private static Integer getStatusCode(String klr,String errorString,int startIndex){
		String errorBody = klr.split(errorString)[1];
		return Integer.parseInt(errorBody.substring(startIndex));		
	}
	
	/**
	 * 
	 * @param klrString
	 * @return
	 */
	public static Result handleKLRErrors(final String klrString) {
	    Result result = null;
		if(klrString.contains("SER01")){	
			Error err = new Error();
			err.setMessage("Static GTID Session route failed. No Desktop session found. Cannot Proceed.");
			err.setStatusCode(getStatusCode(klrString, "SER01", START_INDEX_SESSION_ERROR_CODE));
			result = addErrorToResult (err);
		}else if(klrString.contains("SAB01")){
			Error err = new Error();
			err.setMessage("Session aborted. No Desktop session found. Cannot Proceed.");
			err.setStatusCode(getStatusCode(klrString, "SAB01", START_INDEX_SESSION_ERROR_CODE));
			result = addErrorToResult (err);
		}else if((klrString.contains("SAD01"))){
			Error err = new Error();
			err.setMessage("Session aborted. No Desktop session found. Cannot Proceed.");
			err.setStatusCode(getStatusCode(klrString, "SAD01", START_INDEX_SESSION_ERROR_CODE));
			result = addErrorToResult (err);
		}else if(klrString.contains("PER01")){
			Error err = new Error();
			err.setMessage("Procedure can not be executed - timed out.");
			err.setStatusCode(getStatusCode(klrString, "PER01", START_INDEX_PROCEDURE_ERROR_CODE));
			result = addErrorToResult (err);
		}else if(klrString.contains("XER01")){
			Error err = new Error();
			err.setMessage("Procedure level error.Can not proceed");
			err.setStatusCode(getStatusCode(klrString, "XER01", START_INDEX_PROCEDURE_ERROR_CODE));
			result = addErrorToResult (err);
		}
		return result;
	}

    private static Result addErrorToResult (Error err) {
        Result result = new Result();
        result.getError().add(err);
        return result;
    }
	/**
	 * 
	 * @param klrString
	 * @return
	 */
	public static Result handle2031BlockErrorWarning(final String klrString) {
		Result result = null;
		String message = null;
		Map<Identifier, List<String>> klrs = null;
		char indicator = 0;
		// Check if klr contains 2031 block
		if (klrString.contains(ERROR_BLOCK_2031)) { 
			try {
				//Separates a composite KLR into its sub KLRs
				klrs = KLRUtil.extractKLRsFromRecord(klrString); 
			} catch (TransformationException e) {
				LOGGER.info("Transformation from KLR to OTM failed!");
				LOGGER.error(e);
			}
			if(!CollectionUtils.isEmpty(klrs)){
				final List<String> eTO1KLRList = klrs.get(ERR_IDENTIFIER_ET_ETO1);
	
				if (!CollectionUtils.isEmpty(eTO1KLRList)) {
					//get ETO1 klr
					final String eTO1 = eTO1KLRList.get(FIRST_ELEMENT); 
					//get error or warning indicator
					indicator = eTO1.charAt(INDICATOR_POSITION_ETO1); 
					message=errorWarningIndicator(message, indicator, klrs);
				}
				//populate error / warning based on indicator
				result = addErrorWarningToResult(indicator, message, ERROR_BLOCK_2031); 
			}
		}
		return result;
	}
	private static String errorWarningIndicator(String message,char indicator,Map<Identifier, List<String>> klrs) {
		// TODO Auto-generated method stub
		if (indicator == WARNING_INDICATOR || indicator == ERROR_INDICATOR) {
			//get ETO2 klr
			final List<String> eTO2KLRList = klrs.get(ERR_IDENTIFIER_ET_ETO2); 

			if (!CollectionUtils.isEmpty(eTO2KLRList)) {
				final String eTO2 = eTO2KLRList.get(FIRST_ELEMENT);
				message = eTO2.substring(ETO2_MESSAGE_START_INDEX, eTO2.length());
			}
		}
		return message;
	}

	/**
	 * 
	 * @param klrString
	 * @return
	 */
	public static Result handle2157BlockErrorWarning(final String klrString) {
		Result result = null;
		String message = null;
		Map<Identifier, List<String>> klrs = null;
		String indicator = null;
	//check if klr contains 2157 block
		if (klrString.contains(ERROR_BLOCK_2157)) {
			try {
				//Separates a composite KLR into its sub KLRs
				klrs = KLRUtil.extractKLRsFromRecord(klrString);
			} catch (TransformationException e) {
				LOGGER.info("Transformation from KLR to OTM failed!");
				LOGGER.error(e);
			}
			if(!CollectionUtils.isEmpty(klrs)){
				
				List<String> cCEVKLRList = klrs.get(ERR_IDENTIFIER_CCEV);
			
				if ((!CollectionUtils.isEmpty(cCEVKLRList))&&(cCEVKLRList.size()==1)){
					//if klr contains 1 CCEV
						final String cCEV = cCEVKLRList.get(FIRST_ELEMENT);
						indicator = getCCEVKLRIndicator(cCEV);
						message = getCCEVKLRMessage(cCEV);
				}else if((!CollectionUtils.isEmpty(cCEVKLRList))&&(cCEVKLRList.size()>1)){ //if klr contains more than one CCEV
						final String cCEV_First = cCEVKLRList.get(FIRST_ELEMENT);
						indicator = getCCEVKLRIndicator(cCEV_First);
						message = getAllCCEVMessages(cCEVKLRList);						
				}
				
				//populate error / warning based on indicator
				result = addCCEVErrorWarningToResult(indicator, message, ERROR_BLOCK_2157);
			}
		}
		return result;
	}
	private static String getAllCCEVMessages(List<String> cCEVKLRList) {
		StringBuilder message = new StringBuilder();
		for(String cCEVKLR : cCEVKLRList){
			final String ccevMessage = getCCEVKLRMessage(cCEVKLR);
			message = message.append("\n").append(ccevMessage);
		}
		return message.toString();
	}

	/**
	 * 
	 * @param CCEVKlr
	 * @return
	 */
	 private static String getCCEVKLRMessage(String cCEVKlr){
		 return cCEVKlr.substring(CCEV_MESSAGE_START_INDEX, cCEVKlr.length());
	 }
	 /**
	  * 
	  * @param CCEVKlr
	  * @return
	  */
	 private static String getCCEVKLRIndicator(String cCEVKlr){
		 return cCEVKlr.substring(cCEVKlr.lastIndexOf(' ')+1);
	 }
	/**
	 * 
	 * @param indicator
	 * @param message
	 * @param errorBlock
	 * @return
	 */
	 private static Result addErrorWarningToResult(char indicator,
			String message, String errorBlock) {
		 Result result = new Result();
		if(indicator == ERROR_INDICATOR){
			Error err = new Error();
			err.setMessage(message);
			err.setStatusCode(Integer.parseInt(errorBlock));
			result.getError().add(err);
		}else if(indicator == WARNING_INDICATOR){
			Warning warning = new Warning();
			warning.setMessage(message);
			warning.setStatusCode(Integer.parseInt(errorBlock));
			result.getWarning().add(warning);
		}
		return result;
	}
	 /**
		 * 
		 * @param indicator
		 * @param message
		 * @param errorBlock
		 * @return
		 */
		 private static Result addCCEVErrorWarningToResult(String indicator,
				String message, String errorBlock) {
			 Result result = new Result();
			if(indicator.equalsIgnoreCase(CCEV_ERROR_INDICATOR)){
				Error err = new Error();
				err.setMessage(message);
				err.setStatusCode(Integer.parseInt(errorBlock));
				result.getError().add(err);
			}else if(indicator.equalsIgnoreCase(CCEV_WARNING_INDICATOR)){
				Warning warning = new Warning();
				warning.setMessage(message);
				warning.setStatusCode(Integer.parseInt(errorBlock));
				result.getWarning().add(warning);
			}
			return result;
		}

}
