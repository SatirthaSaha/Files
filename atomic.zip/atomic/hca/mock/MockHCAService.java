/* Copyright (c) 2017 Travelport. All rights reserved. */
  
package com.travelport.resman.atomic.hca.mock;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang3.StringUtils;
import org.junit.rules.TestName;
import org.springframework.util.CollectionUtils;
import org.xmlsoap.schemas.soap.envelope.Envelope;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.resman.atomic.hca.HostConnector;
import com.travelport.resman.atomic.hca.dto.HCACredentialInfo;
import com.travelport.resman.atomic.hca.util.CustomRuntimeException;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRQ;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRS;
import com.travelport.schemas.hca.v0.SessionContextHCA;

/**
 * Mock Interceptor for the HCA service.
 */
public class MockHCAService implements HostConnector<CommandRQ, CommandRS> {
	
	private static final String JAXB_CONTEXT_PATH =
			"com.travelport.otm.builtins.tp.message.v1_0_0:com.travelport.otm.builtins.tp.msgcommon.v1_0_0:" +
			"com.travelport.sandbox.hca.schemas.hca.v1:com.travelport.schemas.hca.v0:org.opentravel.otm.common.v0:" +
			"org.xmlsoap.schemas.soap.envelope";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(MockHCAService.class);
	
	private static JAXBContext jaxbContext;
	
	private static final String MOCK_HCA_TOKEN = "MockHCASessionToken";
	
	
	private static ThreadLocal<String> testClassName = new ThreadLocal<>();
	private static ThreadLocal<String> testMethodName = new ThreadLocal<>();
	
	private Map<String, List<File>> mockResponseFiles = new HashMap<>();
	
	public static void setTestName(Class<?> testClass, TestName junitTestName) {
		MockHCAService.testClassName.set( testClass.getSimpleName() );
		MockHCAService.testMethodName.set( junitTestName.getMethodName() );
	}
	
	/**
	 * Assigns a thread-local name of the JUnit test that is currently running.
	 * This could be used where we need to Mock multiple Air Asia Services.
	 * 
	 * @param testClass  the class that contains the test method being executed
	 * @param cannedResponseFolderName  the name of folder location where the canned response kept
	 */
	public static void setTestName(Class<?> testClass, String cannedResponseFolderName) {
		MockHCAService.testClassName.set( testClass.getSimpleName() );
		MockHCAService.testMethodName.set( cannedResponseFolderName );
	}
		
	/**
	 * Initializes the JAXB context.
	 */
	static {
		try {
			jaxbContext = JAXBContext.newInstance( JAXB_CONTEXT_PATH );
			
		} catch (JAXBException t) {
			throw new ExceptionInInitializerError( t );
		}
	}

	@Override
	public String getSessionToken(String arg0) throws CustomRuntimeException {
		return MOCK_HCA_TOKEN;
	}

	@Override
	public CommandRS invokeService(CommandRQ arg0, String arg1, HCACredentialInfo arg2) throws CustomRuntimeException {
		File responseFile = null;
		try {
			responseFile = nextResponseFile();
			Envelope soapEnvelope = readMockResponse( responseFile);
			List<Object> bodyObjs = soapEnvelope.getBody().getAny();
			CommandRS bodyPayload = null;
			
			if (!bodyObjs.isEmpty()) {
				bodyPayload = (CommandRS) ((JAXBElement<?>) bodyObjs.get( 0 )).getValue();
				//This is for DIR to set 1P session key in HCACredentialInfo
				if(hasSoapHeadePayLoad(soapEnvelope, bodyPayload)
						&& soapEnvelope.getHeader().getAny().get(0) instanceof JAXBElement
						&& ((JAXBElement<?>)soapEnvelope.getHeader().getAny().get(0)).getValue() instanceof SessionContextHCA) {
					String dirSessionKey = ((SessionContextHCA)((JAXBElement<?>)soapEnvelope.getHeader().getAny().get(0)).getValue()).getExternalSessionToken();
					arg2.setSessionToken(dirSessionKey);
				}
			}
			return bodyPayload;
			
		} catch (FileNotFoundException t) {
			throw new CustomRuntimeException("Error parsing recorded HCA response.", t);
		}
	}

	private boolean hasSoapHeadePayLoad(Envelope soapEnvelope, CommandRS bodyPayload) {
		return hasBodyPayLoad(bodyPayload)
				&& soapEnvelope.getHeader() != null && !CollectionUtils.isEmpty(soapEnvelope.getHeader().getAny());
	}

	private boolean hasBodyPayLoad(CommandRS bodyPayload) {
		return extractBodyPayLoad(bodyPayload)
				&& bodyPayload.getHCAResponse().getHCAAData() != null
				&& bodyPayload.getHCAResponse().getHCAAData().getHCAAPayload() != null
				&& !StringUtils.isEmpty(bodyPayload.getHCAResponse().getHCAAData().getHCAAPayload().getHCAADIR());
	}

	private static boolean extractBodyPayLoad(CommandRS bodyPayload) {
		return bodyPayload != null && bodyPayload.getHCAResponse() != null;
	}
	
	protected Envelope readMockResponse(File mockResponseFile) throws CustomRuntimeException {
		Unmarshaller u = null;
		try {
			u = jaxbContext.createUnmarshaller();
		} catch (JAXBException e) {
			throw new CustomRuntimeException("JAXBe", e);
		}
		JAXBElement<Envelope> mockResponse = null;
		try {
			mockResponse = (JAXBElement<Envelope>) u.unmarshal( mockResponseFile );
		} catch (JAXBException e) {
			throw new CustomRuntimeException("JAXBe", e);
		}
		
		return mockResponse.getValue();
	}
	
	protected synchronized File nextResponseFile() throws FileNotFoundException {
		File mockResponseFolder = getMockResponseFolder();
		String folderPath = mockResponseFolder.getAbsolutePath();
		List<File> fileList = mockResponseFiles.get(folderPath);
		File mockFile;

		if (fileList == null) {
			if (mockResponseFolder.exists() && mockResponseFolder.isDirectory()) {
				String[] files = mockResponseFolder.list();

				Arrays.sort(files);
				fileList = new ArrayList<>();

				hasFileData(mockResponseFolder, fileList, files);
				mockResponseFiles.put(folderPath, fileList);
				
			} else {
				throw new FileNotFoundException("Folder location does not exist or is not a directory: " + folderPath);
			}
		}
		hasFileList(folderPath, fileList);
		mockFile = fileList.remove(0);

		LOGGER.debug("Returning mocked response from file: " + mockFile.getName());

		return mockFile;
	}

	private static void hasFileData(File mockResponseFolder, List<File> fileList, String[] files) {
		for (String filename : files) {
			File file = new File(mockResponseFolder, filename);

			if (file.isFile() && file.getName().toLowerCase(Locale.ENGLISH).startsWith("hca")) {
				fileList.add(file);
			}
		}
	}

	private static void hasFileList(String folderPath, List<File> fileList) throws FileNotFoundException {
		if (fileList.size() == 0) {
			throw new FileNotFoundException("No remaining mock responses available in folder: " + folderPath);
		}
	}
	
	public File getMockResponseFolder() {
		return new File( System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
				+ File.separator + "resources"
				+ File.separator + "mock-data"
				+ File.separator 
				+ testClassName.get() + File.separator + testMethodName.get() );
	}

	@Override
	public String createSessionToken() throws CustomRuntimeException {
		return MOCK_HCA_TOKEN;
	}

	@Override
	public CommandRS invokeService(CommandRQ request, String sessionToken, String interactionId) throws CustomRuntimeException {
		File responseFile = null;
		Envelope soapEnvelope;
		try {
			responseFile = nextResponseFile();
			soapEnvelope = readMockResponse( responseFile );
		} catch (IOException e) {
			throw new CustomRuntimeException("IO", e);
		}
		List<Object> bodyObjs = soapEnvelope.getBody().getAny();
		CommandRS bodyPayload = null;
		
		if (!bodyObjs.isEmpty()) {
			bodyPayload = (CommandRS) ((JAXBElement<?>) bodyObjs.get( 0 )).getValue();
		}
		return bodyPayload;
	}

	@Override
	public String createSessionToken(HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException {
		return MOCK_HCA_TOKEN;
	}
}
