/* Copyright (c) 2017 Travelport. All rights reserved. */

package com.travelport.resman.atomic.hca.dto;

import java.util.ArrayList;
import java.util.List;

import com.travelport.sandbox.hca.schemas.hca.v1.CommandRS;

/**
 * HCA Supports to call one data blocks at a time; This Wrapper call hold all the Responses for different data blocks so that it can be processed at a same place
 * @author Sandipan.Das
 *
 */
public class HCAResponseWrapper {
	
	protected List<CommandRS> hcaResponses;
	
	public List<CommandRS> getHcaResponses() {
		if(hcaResponses==null){
			hcaResponses = new ArrayList<>();
		}
		return hcaResponses;
	}

}
