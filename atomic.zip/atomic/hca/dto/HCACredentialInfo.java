/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca.dto;

import com.travelport.acs.interaction.SessionContext;

public class HCACredentialInfo {
	
	private String originApplication = "ACS";
	private String userName;
	private String password;
	private SessionContext sessionContextInfo;
	// Adding this property to store 1P session token as it is returned in
	// header and cannot be accessible from the CommndRS
	// This will be saved in interaction manager during 1P segment sell
	// The value of this property will not be used to do subsequent call, rather
	// any subsequent call/operation should pull it from interaction manager
	
	
	private String sessionToken;
	private String leid;
	private boolean startSessionFlag;
	private boolean endSessionFlag;
	
	private HCACredentialInfo(){
		
	}
	
	public boolean isStartSessionFlag() {
		return startSessionFlag;
	}
	public void setStartSessionFlag(boolean startSessionFlag) {
		this.startSessionFlag = startSessionFlag;
	}
	public boolean isEndSessionFlag() {
		return endSessionFlag;
	}
	public void setEndSessionFlag(boolean endSessionFlag) {
		this.endSessionFlag = endSessionFlag;
	}
	public String getLeid() {
		return leid;
	}
	public void setLeid(String leid) {
		this.leid = leid;
	}
	public String getOriginApplication() {
		return originApplication;
	}
	public void setOriginApplication(String originApplication) {
		this.originApplication = originApplication;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public SessionContext getSessionContextInfo() {
		return sessionContextInfo;
	}

	public void setSessionContextInfo(SessionContext sessionContextInfo) {
		this.sessionContextInfo = sessionContextInfo;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}
	
}
