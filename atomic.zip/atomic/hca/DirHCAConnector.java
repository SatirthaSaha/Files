/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca;

import java.io.IOException;
import java.util.Locale;
import java.util.UUID;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.ws.Holder;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;
import org.xmlsoap.schemas.soap.envelope.Body;
import org.xmlsoap.schemas.soap.envelope.Envelope;
import org.xmlsoap.schemas.soap.envelope.Header;

import com.travelport.acs.cache.impl.CacheManager;
import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.logger.impl.ACSLogger.LOGSYSTEM;
import com.travelport.resman.atomic.hca.dto.HCACredentialInfo;
import com.travelport.resman.atomic.hca.util.CustomRuntimeException;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandFault;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRQ;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRS;
import com.travelport.sandbox.hca.schemas.hca.v1.ELoggingEnum;
import com.travelport.sandbox.hca.schemas.hca.v1.HCACommandPortType;
import com.travelport.sandbox.hca.schemas.hca.v1.PayloadTypeEnum;
import com.travelport.schemas.hca.v0.SessionContextHCA;

public class DirHCAConnector implements HostConnector<CommandRQ, CommandRS> {

	private static final ACSLogger LOGGER = ACSLogger.getLogger(DirHCAConnector.class);
	private static final int FOUR = 4;
	private static com.travelport.sandbox.hca.schemas.hca.v1.ObjectFactory hcaObjectFactory = new com.travelport.sandbox.hca.schemas.hca.v1.ObjectFactory();
	private static com.travelport.schemas.hca.v0.ObjectFactory scObjectFactory = new com.travelport.schemas.hca.v0.ObjectFactory(); 
	private static int pCC_LENGTH=FOUR;
	private static final String SESSION_TOKEN = "SessionToken";
	private static final String CORE_1P = "1P";
	/**
	 * Invoke HCA with CommandRQ and Existing Session Token
	 * 
	 * @param request
	 *            CommandRQ payload
	 * @param sessionToken
	 *            Existing sessionToken
	 * @return CommandRS
	 * @throws CommandFault 
	 * @throws IOException 
	 * @throws JAXBException 
	 * @throws Exception
	 * 
	 */
	public CommandRS invokeService(CommandRQ request, String workbenchId, HCACredentialInfo hcaCredentialInfo) {
		
		LOGGER.debug("DirHCAConnector : In invokeService()");
		
		hasHCAInformation(request);
		
		LOGGER.info("hcaCredentialInfo ==> " + hcaCredentialInfo);
		
		if (extractHCACredInfo(hcaCredentialInfo)
				&& hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile() != null
				&& !StringUtils.isEmpty(
								hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())) {
					
			SessionContextBuilder builder = hasHCACred( hcaCredentialInfo,request);
			
			SessionContextHCA sessionContext = builder.build();
			LOGGER.debug("DirHCAConnector : Got session context : " + sessionContext);
			
			// This gets the delegate needed to execute your request. The file hca-config.xml is in hca-connector.jar as part of the class path. You
            // don't need to have a copy of it in your jar or application. This will send and receive via JCP Manager within a CXF conduit. Alternatively,
			HCACommandPortType hcaService = HCAConnectorFactory.getInstance("hca-config.xml").getHCAService("JCPManager");
			
			LOGGER.debug("DirHCAConnector : got hcaservice - " + hcaService);
			Holder<SessionContextHCA> contextHolder = new Holder<>(sessionContext);
			LOGGER.logRequestResponse("Worldspan(1P) HCA Request", HCAConnector.prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRQ(request)), LOGSYSTEM.HCA);
			CommandRS response;
			try {
				response = hcaService.command(contextHolder, request);
			} catch (CommandFault e) {
				throw new CustomRuntimeException("CommandFault", e);
			}
			LOGGER.logRequestResponse("Worldspan(1P) HCA Request", HCAConnector.prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRQ(request)), LOGSYSTEM.HCA);
			
			SessionContextHCA sessionContextRsp = contextHolder.value;
			
            isSessionFlag(hcaCredentialInfo, sessionContextRsp,workbenchId);
			
			isHCAResponse(response);
			
			return response;
			
		}
		
		return null;
	}
	
	
	
	private static void hasHCACredInfo(CommandRQ request, HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException {
		if (hcaCredentialInfo.getSessionContextInfo().getPointOfSale() != null
				&& !CollectionUtils
						.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID())
				&& !StringUtils.isEmpty(
						hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID().get(0))) {
			 hasGTIDRoute(request, hcaCredentialInfo);
		}//return externalSessionToken;
	}

	private static void hasGTIDRoute(CommandRQ request, HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException {
		LOGGER.debug("HCA Connector : Static GTID Route Enabled");
		request.getHCARequest().getSysMgmtRQ().getHCASysMgmtSessPropSysMgmtCmd().setGTIDLEIDOvrd(
				hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID().get(0));
		hcaCredentialInfo.setStartSessionFlag(false);
		hcaCredentialInfo.setEndSessionFlag(false);
		hcaCredentialInfo.setSessionToken(null);		
	}
	

	private static SessionContextBuilder hasHCACred( HCACredentialInfo hcaCredentialInfo,CommandRQ reqest) {
		LOGGER.debug("DirHCAConnector : Got credential");
		hasHCACredInfo(reqest,hcaCredentialInfo);
		SessionContextBuilder builder = new SessionContextBuilder().setE2eTrackingId(UUID.randomUUID().toString())
				.setOriginApplication(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication())
				.setCustomerProfileID(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())
				.setPseudoCityCode(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode())
				.setExternalSessionToken(hcaCredentialInfo.getSessionToken()).setStartSession(hcaCredentialInfo.isStartSessionFlag()).setEndSession(hcaCredentialInfo.isEndSessionFlag());
		return builder;
	}

	private static void hasHCAInformation(CommandRQ request) {
		if (hasHCADetails(request) && request.getHCARequest().getHCAAData().getHCAAPayload() != null
				&& request.getHCARequest().getHCAAData().getHCAAPayload().getHCAADIR() != null) {

			LOGGER.info("DIR Request ==> " + request.getHCARequest().getHCAAData().getHCAAPayload().getHCAADIR());

		}
	}
	
	private static boolean hasHCADetails(CommandRQ request) {
		return request != null && request.getHCARequest() != null && request.getHCARequest().getHCAAData() != null;
	}

	private static void isHCAResponse(CommandRS response) {
		if(response != null && response.getHCAResponse() != null && response.getHCAResponse().getHCAAData() != null
				&& response.getHCAResponse().getHCAAData().getHCAAPayload() != null) {
			if(response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAADIR() != null) {
				LOGGER.info("DIR Response ==> " + response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAADIR());
			}
		} else {
			LOGGER.error("DirHCAConnector : Response from HCA is Empty!!");
		}
	}

	private static void isSessionFlag(HCACredentialInfo hcaCredentialInfo,
			SessionContextHCA sessionContextRsp,String workbenchId) {
		if(hcaCredentialInfo.isStartSessionFlag() && sessionContextRsp.getExternalSessionToken() != null){
			hcaCredentialInfo.setSessionToken(sessionContextRsp.getExternalSessionToken());
			saveSessionToken(workbenchId,CORE_1P,sessionContextRsp.getExternalSessionToken());
		}
	}

	private static boolean extractHCACredInfo(HCACredentialInfo hcaCredentialInfo) {
		return hcaCredentialInfo != null && hcaCredentialInfo.getSessionContextInfo() != null
				&& hcaCredentialInfo.getSessionContextInfo().getPointOfSale() != null
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication());
	}



	/**
	 * Get Session Token using Interaction Id; 
	 * It will try to retrieve existing sessionToken from Interaction Manager 
	 * 
	 * @param interactionId
	 *            Interaction ID
	 * @return SessionToken
	 * @throws Exception
	 */
	public String getSessionToken(String workbenchId) {
		return CacheManager.getInstance ().get(workbenchId, SESSION_TOKEN+CORE_1P);
	}

	@Override
	public String createSessionToken()  {
		return null;
	}

	@Override
	public CommandRS invokeService(CommandRQ request, String sessionToken, String interactionId)	{
		return null;
	}

	@Override
	public String createSessionToken(HCACredentialInfo hcaCredentialInfo) {
		return open1PSession(hcaCredentialInfo);
	}

	private static String open1PSession(HCACredentialInfo hcaCredentialInfo)  {

		LOGGER.info("In open1PSession");

		if (extractHCA1PCredInfo(hcaCredentialInfo)
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode())
				&& hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile() != null
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())) {
			SessionContextHCA sessionContext = new SessionContextBuilder()
					.setE2eTrackingId(UUID.randomUUID().toString())
					.setOriginApplication(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication())
					.setCustomerProfileID(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ()).setStartSession(true)
					.setEndSession(false).build();

			HCACommandPortType hcaService = HCAConnectorFactory.getInstance("hca-config.xml")
					.getHCAService("JCPManager");
			Holder<SessionContextHCA> contextHolder = new Holder<>(sessionContext);
			
			CommandRQ commandRQ=null;

			if (StringUtils.isNotBlank(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode())
					&& hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode().length() == pCC_LENGTH) {
				commandRQ = new HCARequestBuilder().setEndpoint(CORE_1P).setHostServiceId("STHA")
						.setDiagnosticsEnabled(true).addDiagnosticCommandItem(DiagnosticItemType.HCARqstEntry)
						.addDiagnosticCommandItem(DiagnosticItemType.HCARqstExit).seteLogValue(ELoggingEnum.NONE)
						.setPayloadType(PayloadTypeEnum.DIR_1_1)
						.setPayload(new StructuredDataRecord("TSV01SIGNON", "5650", 1, 0, null,
								"0041GSON000F0001Z" + hcaCredentialInfo.getSessionContextInfo().getPointOfSale()
										.getPseudoCityCode().toUpperCase(Locale.ENGLISH)))
						.build();
				LOGGER.info("Built 1G HCA Request = " + commandRQ.toString());
			} else {
				commandRQ = new HCARequestBuilder().setEndpoint(CORE_1P).setHostServiceId("STHA")
						.setDiagnosticsEnabled(true).addDiagnosticCommandItem(DiagnosticItemType.HCARqstEntry)
						.addDiagnosticCommandItem(DiagnosticItemType.HCARqstExit).seteLogValue(ELoggingEnum.NONE)
						.setPayloadType(PayloadTypeEnum.DIR_1_1)
						.setPayload(new StructuredDataRecord("TSV01SIGNON", "5650", 1, 0, null,
								"0041GSON000F0001Z" + hcaCredentialInfo.getSessionContextInfo().getPointOfSale()
										.getPseudoCityCode().toUpperCase(Locale.ENGLISH)))
						.build();
                LOGGER.info("Built Default 1P HCA Request = " + commandRQ.toString());
			}
			
			LOGGER.logRequestResponse("Worldspan(1P) HCA Open Session Request", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRQ(commandRQ)), LOGSYSTEM.HCA);
			CommandRS response;
			try {
				response = hcaService.command(contextHolder, commandRQ);
			} catch (CommandFault e) {
				throw new CustomRuntimeException("CommandFault", e);
			}
			LOGGER.logRequestResponse("Worldspan(1P) HCA Open Session Response", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRS(response)), LOGSYSTEM.HCA);

			LOGGER.info("HCA Response = " + response.toString());

			SessionContextHCA responseContext = contextHolder.value;

			if (responseContext != null && responseContext.getExternalSessionToken() != null) {

				return responseContext.getExternalSessionToken();

			}

		}

		return null;
	}
	
	public static Envelope prepareRequest(SessionContextHCA messageHeader, JAXBElement<?> messageBody) {
		try{
			if (messageHeader!=null && messageBody != null) {
				final Envelope soapEnvelope = new Envelope();
				final Header soapHeader = new Header();
				final Body soapBody = new Body();
	
				soapHeader.getAny().add(scObjectFactory.createSessionContextHCA(messageHeader));
				soapBody.getAny().add(messageBody);
				soapEnvelope.setHeader(soapHeader);
				soapEnvelope.setBody(soapBody);
				return soapEnvelope;
			}
		}catch(NullPointerException e){
			LOGGER.error("Cannot Create SOAP Body of HCA Request/Response.", e);
		}
		return new Envelope();
	}
	
	private static boolean extractHCA1PCredInfo(HCACredentialInfo hcaCredentialInfo) {
		return hcaCredentialInfo != null
				&& hcaCredentialInfo.getSessionContextInfo() != null
				&& hcaCredentialInfo.getSessionContextInfo().getPointOfSale() != null
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication());
	}

	private static void saveSessionToken(String cacheId, String provider, String sessionToken){
		CacheManager.getInstance ().save(cacheId,  SESSION_TOKEN+provider, sessionToken);		
	}
}
