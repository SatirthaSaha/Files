/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import com.travelport.resman.atomic.hca.dto.HCACredentialInfo;
import com.travelport.resman.atomic.hca.util.CustomRuntimeException;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandFault;

/**
 * Interface for HCA Connectivity
 * @author Sandipan.Das
 * @param <T> Request Payload Type
 * @param <S> Response Payload Type
 */
public interface HostConnector<T, S>  {
	
	/**
	 * Get existing sessionToken using Interaction Id
	 * @param interactionId Interaction Id
	 * @return SessionToken
	 * @throws Exception
	 */
	String getSessionToken (String interactionId) throws CustomRuntimeException;
	
	/**
	 * create and return new sessionToken 
	 * @return SessionToken
	 * @throws Exception
	 */
	String createSessionToken () throws CustomRuntimeException;
	
	/**
	 * create and return new sessionToken
	 * @param hcaCredentialInfo 
	 * @return SessionToken
	 * @throws CommandFault 
	 * @throws IOException 
	 * @throws JAXBException 
	 * @throws Exception
	 */
	String createSessionToken (HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException;
	
	/**
	 * Invoke HCA Service using Payload and existing SessionToken
	 * @param request Request Payload
	 * @param sessionToken Existing sessionToken
	 * @return Response from HCA
	 * @throws Exception
	 */
	S invokeService (T request, String sessionToken, String interactionId) throws CustomRuntimeException;
	
	/**
	 * Invoke HCA Service using Payload and existing SessionToken
	 * @param request Request Payload
	 * @param sessionToken Existing sessionToken
	 * @param hcaCredentialInfo 
	 * @return Response from HCA
	 * @throws CommandFault 
	 * @throws IOException 
	 * @throws JAXBException 
	 * @throws Exception
	 */
	S invokeService(T request, String sessionToken, HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException;
	
}
