/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca.util;

import java.io.UnsupportedEncodingException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

/**
 * Static utility methods for marshalling and unmarshalling JSON data objects.
 */
public class JsonUtils {
	
	private static Gson gson = new GsonBuilder().setPrettyPrinting().create();
	
	private JsonUtils() {
		
	}
	
	/**
	 * Converts the given JSON data into an object of the specified type.
	 * 
	 * @param jsonBytes  the raw JSON content to convert
	 * @param objClass  the type of object to which the content applies
	 * @return T
	 */
	public static <T> T fromJson(byte[] jsonBytes, Class<T> objClass) {
		T obj;
		try {
			obj = gson.fromJson( new String( jsonBytes, "UTF-8" ), objClass );
			
		} catch (UnsupportedEncodingException e) {
			throw new CustomRuntimeException("exceptiomx", e);
		}
		return obj;
	}
	
	/**
	 * Converts the given object to JSON content that can be used as the data
	 * for a ZooKeeper z-node.
	 * 
	 * @param obj  the object to be serialized
	 * @return byte[]
	 */
	public static byte[] toJson(Object obj) {
		return gson.toJson( obj ).getBytes();
	}
	
	/**
	 * Formats the given string as pretty-printed JSON.
	 * 
	 * @param unformattedJson  the unformatted JSON string
	 * @return String
	 */
	public static String formatJson(String unformattedJson) {
		return new String( toJson( fromJson( unformattedJson.getBytes(), JsonObject.class ) ) );
	}
	
}
