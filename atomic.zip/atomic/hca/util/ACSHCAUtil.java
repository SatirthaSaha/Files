/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca.util;

import org.apache.commons.lang.StringUtils;

import com.travelport.sandbox.hca.schemas.hca.v1.HCAAPayload;

/**
 * Utility Class for HCA related Transactions
 * @author Sandipan.Das
 *
 */
public class ACSHCAUtil {
	
	private ACSHCAUtil() {
		
	}
	/**
	 * Extract HCA Response String from HCA Payload; HCA Payload can contain either KLR or DIR String (In Case of NWB interaction); This method will extract either KLR or NWB
	 * response from HCAAPayload
	 * @param hcaaPayload HCAAPayload
	 * @return Actual response of either KLR or NWB (as DIR String for now)
	 */
	public static String getHostResponseString(HCAAPayload hcaaPayload) {
		String hostResponseString = "";
		if (hcaaPayload != null) {
			if (StringUtils.isNotEmpty(hcaaPayload.getHCAAKLR())) {
				hostResponseString = hcaaPayload.getHCAAKLR();
			} else if (StringUtils.isNotEmpty(hcaaPayload.getHCAADIR())) {
				hostResponseString = hcaaPayload.getHCAADIR();
			}else if (StringUtils.isNotEmpty(hcaaPayload.getHCAANWB())) {
				hostResponseString = hcaaPayload.getHCAANWB();
			}
		}
		return hostResponseString;
	}

}
