/* Copyright (c) 2017 Travelport. All rights reserved. */ 
package com.travelport.resman.atomic.hca.util;

/**
 * Custom Exception class
 *
 */
public class CustomRuntimeException extends RuntimeException {

	/**
	*  serial version ID 
	*/
	private static final long serialVersionUID = 1L;


	/**
	 * @param message
	 * 				String message
	 */
	public CustomRuntimeException(String message) {
		super(message);
	}
	
	/**
	 * parameterized constructor
	 * 
	 * @param message 
	 * 				String message
	 * @param ex
	 * 			Object of actual exceptions
	 */
	public CustomRuntimeException(String message, Exception ex) {
		super(message,ex);
	}
	
	/**
	 * parameterized constructor
	 * 
	 * @param message 
	 * 				String message
	 * @param ex
	 * 			Object of actual exceptions
	 */
	public CustomRuntimeException(Exception ex) {
		super(ex);
	}
}
