/* Copyright (c) 2017 Travelport. All rights reserved. */
 
package com.travelport.resman.atomic.hca;

import java.io.IOException;
import java.util.Locale;
import java.util.UUID;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.ws.Holder;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;
import org.xmlsoap.schemas.soap.envelope.Body;
import org.xmlsoap.schemas.soap.envelope.Envelope;
import org.xmlsoap.schemas.soap.envelope.Header;

import com.travelport.acs.logger.impl.ACSLogger;
import com.travelport.acs.logger.impl.ACSLogger.LOGSYSTEM;
import com.travelport.interaction.InteractionManager;
import com.travelport.resman.atomic.hca.dto.HCACredentialInfo;
import com.travelport.resman.atomic.hca.util.CustomRuntimeException;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandFault;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRQ;
import com.travelport.sandbox.hca.schemas.hca.v1.CommandRS;
import com.travelport.sandbox.hca.schemas.hca.v1.ELoggingEnum;
import com.travelport.sandbox.hca.schemas.hca.v1.HCACommandPortType;
import com.travelport.sandbox.hca.schemas.hca.v1.PayloadTypeEnum;
import com.travelport.schemas.hca.v0.SessionContextHCA;
import com.travelport.soa.lib.common.technical.interactionmanager.interaction.model.CoreSession;

/**
 * Class to Invoke Host Connectivity Adapter (HCA)
 * 
 * @author Sandipan.Das
 *
 */
public class HCAConnector implements HostConnector<CommandRQ, CommandRS> {

	private static com.travelport.schemas.hca.v0.ObjectFactory scObjectFactory = new com.travelport.schemas.hca.v0.ObjectFactory(); 
	private static com.travelport.sandbox.hca.schemas.hca.v1.ObjectFactory hcaObjectFactory = new com.travelport.sandbox.hca.schemas.hca.v1.ObjectFactory();
	private static final String CORE_1G = "1G";
	private static final ACSLogger LOGGER = ACSLogger.getLogger(HCAConnector.class);
	private static final int FOUR =4;

	/**
	 * Invoke HCA with CommandRQ and Existing Session Token
	 * 
	 * @param request
	 *            CommandRQ payload
	 * @param sessionToken
	 *            Existing sessionToken
	 * @return CommandRS
	 * @throws Exception
	 * 
	 */
	public CommandRS invokeService(CommandRQ request, String sessionToken, HCACredentialInfo hcaCredentialInfo)
			throws CustomRuntimeException {

		LOGGER.debug("HCA Connector : In invokeService()");

		isHCAReqst(request);

		LOGGER.info("hcaCredentialInfo ==> " + hcaCredentialInfo);

		if (hcaCredentialInfo != null && hcaCredentialInfo.getSessionContextInfo() != null) {
			SessionContextBuilder builder = null;
			LOGGER.debug("HCA Connector : Got credential");
			String externalSessionToken = sessionToken;
			try {
				externalSessionToken = hasHCACredInfo(request, hcaCredentialInfo, externalSessionToken);
			} catch (CustomRuntimeException e) {
				throw new CustomRuntimeException("exceptiomx", e);
			}
			builder = hasHCACredInfo(hcaCredentialInfo, builder, externalSessionToken);
			LOGGER.debug("HCA Connector : Got sessionConextBuilder - " + builder);
		if( builder !=null ){
			SessionContextHCA sessionContext = builder.build();
			
			try {
				LOGGER.debug("HCA Connector : Got session context : " + sessionContext);
			} catch(Exception e) {
				throw new CustomRuntimeException("exceptiomx", e);
			}
		
			HCACommandPortType hcaService = HCAConnectorFactory.getInstance("hca-config.xml")
					.getHCAService("JCPManager");
			LOGGER.debug("HCA Connector : got hcaservice - " + hcaService);
			Holder<SessionContextHCA> contextHolder = new Holder<>(sessionContext);
			LOGGER.logRequestResponse("Galileo(1G) HCA Request", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRQ(request)), LOGSYSTEM.HCA);
			CommandRS response;
			try {
				response = hcaService.command(contextHolder, request);
			} catch (CommandFault e) {
				throw new CustomRuntimeException("CommandFault", e);
			}
			LOGGER.logRequestResponse("Galileo(1G) HCA Response", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRS(response)), LOGSYSTEM.HCA);

			hasHCARespnse(response);

			return response;

		}
		}

		return null;
	}

	private void hasHCARespnse(CommandRS response) {
		if (response != null && response.getHCAResponse() != null && response.getHCAResponse().getHCAAData() != null
				&& response.getHCAResponse().getHCAAData().getHCAAPayload() != null) {
			hasHCAReqData(response);

		} else {
			LOGGER.error("HCA Connector : Response from HCA is Empty!!");
		}
	}

	private SessionContextBuilder hasHCACredInfo(HCACredentialInfo hcaCredentialInfo, SessionContextBuilder builder,
			String externalSessionToken) {
		if (!StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication())	
		        && null != hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile()
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())) {
			builder = hasSessionContext(hcaCredentialInfo, externalSessionToken);
		} else {
			LOGGER.error("Didn't find valid HCACredentialInfo");
		}
		return builder;
	}

	private void isHCAReqst(CommandRQ request) {
		if (request != null && request.getHCARequest() != null && request.getHCARequest().getHCAAData() != null
				&& request.getHCARequest().getHCAAData().getHCAAPayload() != null) {
			hasHCAReqData(request);
		}
	}

	private String hasHCACredInfo(CommandRQ request, HCACredentialInfo hcaCredentialInfo, String externalSessionToken) throws CustomRuntimeException {
		if (hcaCredentialInfo.getSessionContextInfo().getPointOfSale() != null
				&& !CollectionUtils
						.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID())
				&& !StringUtils.isEmpty(
						hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID().get(0))) {
			externalSessionToken = hasGTIDRoute(request, hcaCredentialInfo);
		}
		return externalSessionToken;
	}

	private static String hasGTIDRoute(CommandRQ request, HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException {
		String externalSessionToken;
		LOGGER.debug("HCA Connector : Static GTID Route Enabled");
		request.getHCARequest().getSysMgmtRQ().getHCASysMgmtSessPropSysMgmtCmd().setGTIDLEIDOvrd(
				hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getTerminalID().get(0));
		externalSessionToken = "";
		return externalSessionToken;
	}

	private SessionContextBuilder hasSessionContext(HCACredentialInfo hcaCredentialInfo, String externalSessionToken) {
		SessionContextBuilder builder;
		builder = new SessionContextBuilder().setE2eTrackingId(UUID.randomUUID().toString())
				.setOriginApplication(
						hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication())
				.setCustomerProfileID(
				        hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())
				.setExternalSessionToken(externalSessionToken).setStartSession(false).setEndSession(false);
		return builder;
	}

	private static void hasHCAReqData(CommandRS response) {
		if (response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAAKLR() != null) {
			LOGGER.info("KLR Response ==> "
					+ response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAAKLR());
		}
		if (response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAANWB() != null) {
			LOGGER.info("NWB Response ==> "
					+ response.getHCAResponse().getHCAAData().getHCAAPayload().getHCAANWB());
		}
	}

	private static void hasHCAReqData(CommandRQ request) {
		if (request.getHCARequest().getHCAAData().getHCAAPayload().getHCAAKLR() != null) {
			LOGGER.info("KLR Request ==> " + request.getHCARequest().getHCAAData().getHCAAPayload().getHCAAKLR());
		}
		if (request.getHCARequest().getHCAAData().getHCAAPayload().getHCAANWB() != null) {
			LOGGER.info("NWB Request ==> " + request.getHCARequest().getHCAAData().getHCAAPayload().getHCAANWB());
		}
	}

	/**
	 * Get Session Token using Interaction Id; It will try to retrieve existing
	 * sessionToken from Interaction Manager if not found it will Open a Session
	 * Using HCA
	 * 
	 * @param interactionId
	 *            Interaction ID
	 * @return SessionToken
	 * @throws CommandFault 
	 * @throws IOException 
	 * @throws JAXBException 
	 * @throws Exception
	 */
	public String createSessionToken(HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException {
		String sessionToken = null;
		sessionToken = open1GSession(hcaCredentialInfo);
		return sessionToken;
	}

	/**
	 * Opens A Session in 1G and Returns the External Session Token
	 * 
	 * @param interactionId
	 *            Interaction Id
	 * @return External Session Token
	 * @throws IOException 
	 * @throws JAXBException 
	 * @throws CommandFault 
	 * @throws Exception
	 */
	private String open1GSession(HCACredentialInfo hcaCredentialInfo) throws CustomRuntimeException  {

		LOGGER.info("In open1GSession");

		if (extractHCA1GCredInfo(hcaCredentialInfo)
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode())
				&& hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile() != null
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ())) {
			SessionContextHCA sessionContext = new SessionContextBuilder()
					.setE2eTrackingId(UUID.randomUUID().toString())
					.setOriginApplication(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication())
					.setCustomerProfileID(hcaCredentialInfo.getSessionContextInfo().getHostAccessProfile().getAccessProfileName ()).setStartSession(true)
					.setEndSession(false).build();

			HCACommandPortType hcaService = HCAConnectorFactory.getInstance("hca-config.xml")
					.getHCAService("JCPManager");
			Holder<SessionContextHCA> contextHolder = new Holder<>(sessionContext);
			
			CommandRQ commandRQ=null;

			if (StringUtils.isNotBlank(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode())
					&& hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getPseudoCityCode().length() == FOUR) {
				commandRQ = new HCARequestBuilder().setEndpoint(CORE_1G).setHostServiceId("STHA")
						.setDiagnosticsEnabled(true).addDiagnosticCommandItem(DiagnosticItemType.HCARqstEntry)
						.addDiagnosticCommandItem(DiagnosticItemType.HCARqstExit).seteLogValue(ELoggingEnum.NONE)
						.setPayloadType(PayloadTypeEnum.KLR_1_1)
						.setPayload(new StructuredDataRecord("TSV01SIGNON", "5650", 1, 0, null,
								"0041GSON000F0001Z" + hcaCredentialInfo.getSessionContextInfo().getPointOfSale()
										.getPseudoCityCode().toUpperCase(Locale.ENGLISH) + "/GWS                ",
								DataFormatEnum.KLR))
						.build();
				LOGGER.info("Built 1G HCA Request = " + commandRQ.toString());
			} else {
				commandRQ = new HCARequestBuilder().setEndpoint(CORE_1G).setHostServiceId("STHA")
						.setDiagnosticsEnabled(true).addDiagnosticCommandItem(DiagnosticItemType.HCARqstEntry)
						.addDiagnosticCommandItem(DiagnosticItemType.HCARqstExit).seteLogValue(ELoggingEnum.NONE)
						.setPayloadType(PayloadTypeEnum.KLR_1_1)
						.setPayload(new StructuredDataRecord("TSV01SIGNON", "5650", 1, 0, null,
								"0041GSON000F0001Z" + hcaCredentialInfo.getSessionContextInfo().getPointOfSale()
										.getPseudoCityCode().toUpperCase(Locale.ENGLISH) + "GWS                  ",
								DataFormatEnum.KLR))
						.build();
                LOGGER.info("Built Default 1G HCA Request = " + commandRQ.toString());
			}
			
			LOGGER.logRequestResponse("Galileo(1G) HCA Open Session Request", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRQ(commandRQ)), LOGSYSTEM.HCA);
			CommandRS response;
			try {
				response = hcaService.command(contextHolder, commandRQ);
			} catch (CommandFault e) {
				throw new CustomRuntimeException("CommandFault", e);
			}
			LOGGER.logRequestResponse("Galileo(1G) HCA Open Session Response", prepareRequest(contextHolder.value, hcaObjectFactory.createCommandRS(response)), LOGSYSTEM.HCA);

			LOGGER.info("HCA Response = " + response.toString());

			SessionContextHCA responseContext = contextHolder.value;

			if (responseContext != null && responseContext.getExternalSessionToken() != null) {

				return responseContext.getExternalSessionToken();

			}

		}

		return null;
	}

	private static boolean extractHCA1GCredInfo(HCACredentialInfo hcaCredentialInfo) {
		return hcaCredentialInfo != null
				&& hcaCredentialInfo.getSessionContextInfo() != null
				&& hcaCredentialInfo.getSessionContextInfo().getPointOfSale() != null
				&& !StringUtils.isEmpty(hcaCredentialInfo.getSessionContextInfo().getPointOfSale().getOriginApplication());
	}

	/**
	 * Saves the External Session Token in the Interaction Manager
	 * 
	 * @param interactionId
	 *            Interaction Id
	 * @param sessionToken
	 *            Opened External Session Token
	 */
	public void setSessionToken(String interactionId, String sessionToken) {
		CoreSession coresession = new CoreSession();
		coresession.setInteractionID(interactionId);
		coresession.setCore(CORE_1G);
		coresession.setSessionLocator(sessionToken);
		InteractionManager interactionManager = InteractionManager.getInstance();
		interactionManager.createCoreSession(interactionId, coresession);
	}

	@Override
	public String getSessionToken(String interactionId) throws CustomRuntimeException {
		return returnNull();
	}

	@Override
	public CommandRS invokeService(CommandRQ request, String sessionToken, String interactionId) throws CustomRuntimeException {
		return null;
	}

	@Override
	public String createSessionToken() throws CustomRuntimeException {
		return returnNull();
	}
	
	private String returnNull() {
		return null;
	}
	
	public static Envelope prepareRequest(SessionContextHCA messageHeader, JAXBElement<?> messageBody) throws CustomRuntimeException {
		try{
			if (messageHeader!=null && messageBody != null) {
				final Envelope soapEnvelope = new Envelope();
				final Header soapHeader = new Header();
				final Body soapBody = new Body();
	
				soapHeader.getAny().add(scObjectFactory.createSessionContextHCA(messageHeader));
				soapBody.getAny().add(messageBody);
				soapEnvelope.setHeader(soapHeader);
				soapEnvelope.setBody(soapBody);
				return soapEnvelope;
			}
		}catch(Exception e){
			LOGGER.error("Cannot Create SOAP Body of HCA Request/Response.", e);
		}
		return new Envelope();
	}
}
